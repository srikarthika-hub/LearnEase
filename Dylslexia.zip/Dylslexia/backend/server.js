require('dotenv').config();
const express = require("express");
const cors = require("cors");
const { connectDB, isDbConnected } = require("./config/db");
const { saveScreeningResult } = require("./routes/screening");

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS and JSON body parsing
app.use(cors());
app.use(express.json());

// Initialize MongoDB connection safely (non-blocking, will not crash if offline)
connectDB();

// Category display mapping
const CATEGORY_NAMES = {
  phonological: "Phonological Awareness",
  rhyming: "Rhyming",
  letterRecognition: "Letter Recognition",
  letter_recognition: "Letter Recognition",
  sequencing: "Sequencing",
  workingMemory: "Working Memory",
  memory: "Working Memory",
  reading: "Reading Patterns",
  rapidNaming: "Rapid Naming",
  rapid_naming: "Rapid Naming"
};

// Activity recommendations per category
const CATEGORY_ACTIVITIES = {
  phonological: ["Sound Match", "Rhyming Practice"],
  rhyming: ["Rhyming Practice", "Sound Match"],
  letterRecognition: ["Letter Hunt", "Word Builder"],
  letter_recognition: ["Letter Hunt", "Word Builder"],
  sequencing: ["Sequence Challenge", "Word Builder"],
  workingMemory: ["Memory Match", "Sequence Challenge"],
  memory: ["Memory Match", "Sequence Challenge"],
  reading: ["Word Builder", "Letter Hunt"],
  rapidNaming: ["Sound Match", "Letter Hunt"],
  rapid_naming: ["Sound Match", "Letter Hunt"]
};

/**
 * Health check endpoint
 */
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "LearnEase Backend is running!"
  });
});

/**
 * DB Status endpoint
 */
app.get("/api/db-status", (req, res) => {
  res.json({
    success: true,
    dbConnected: isDbConnected(),
    status: isDbConnected() ? "connected" : "disconnected"
  });
});

/**
 * Screening evaluation endpoint
 * Accepts:
 * {
 *   profile: { name, age, grade, language },
 *   answers: [ { category, correct, responseTime }, ... ]
 * }
 * Also backward compatible with { answers: [true, false, ...] }
 */
app.post("/api/screening", (req, res) => {
  try {
    if (!req.body) {
      return res.status(400).json({
        success: false,
        message: "Invalid request body."
      });
    }

    let rawAnswers = req.body.answers;
    if (!rawAnswers && Array.isArray(req.body)) {
      rawAnswers = req.body;
    }

    if (!rawAnswers || !Array.isArray(rawAnswers) || rawAnswers.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid input: answers must be a non-empty array."
      });
    }

    const defaultCategories = [
      "phonological", "rhyming", "letterRecognition", "sequencing",
      "workingMemory", "reading", "rapidNaming", "phonological",
      "rhyming", "letterRecognition", "sequencing", "workingMemory",
      "reading", "rapidNaming", "phonological"
    ];

    // Normalize incoming answer elements
    const normalized = rawAnswers.map((item, idx) => {
      if (typeof item === "boolean") {
        return {
          category: defaultCategories[idx % defaultCategories.length],
          correct: item,
          responseTime: 4.0
        };
      }

      let cat = item.category || defaultCategories[idx % defaultCategories.length];
      if (cat === "letter_recognition") cat = "letterRecognition";
      if (cat === "memory") cat = "workingMemory";
      if (cat === "rapid_naming") cat = "rapidNaming";

      return {
        category: cat,
        correct: Boolean(item.correct),
        responseTime: Number(item.responseTime) || 4.0
      };
    });

    // Aggregate category performance
    const catStats = {};
    let totalCorrect = 0;
    let totalResponseTime = 0;

    normalized.forEach(ans => {
      const c = ans.category;
      if (!catStats[c]) {
        catStats[c] = { correct: 0, total: 0, responseTimeSum: 0 };
      }
      if (ans.correct) {
        catStats[c].correct += 1;
        totalCorrect += 1;
      }
      catStats[c].total += 1;
      catStats[c].responseTimeSum += ans.responseTime;
      totalResponseTime += ans.responseTime;
    });

    const categoryScores = {};
    const strengths = [];
    const supportAreas = [];
    const recommendedActivitiesSet = new Set();

    Object.keys(catStats).forEach(c => {
      const stats = catStats[c];
      const pct = Math.round((stats.correct / stats.total) * 100);
      categoryScores[c] = pct;

      const friendlyName = CATEGORY_NAMES[c] || c;
      if (pct >= 70) {
        strengths.push(friendlyName);
      } else {
        supportAreas.push(friendlyName);
        const acts = CATEGORY_ACTIVITIES[c] || ["Sound Match", "Memory Match"];
        acts.forEach(a => recommendedActivitiesSet.add(a));
      }
    });

    // Overall metrics
    const overallScore = Math.round((totalCorrect / normalized.length) * 100);
    const avgResponseTime = Number((totalResponseTime / normalized.length).toFixed(1));

    // Non-diagnostic support level
    let level = "Some Practice Recommended";
    if (overallScore >= 80) {
      level = "Strong Foundation";
    } else if (overallScore >= 60) {
      level = "Some Practice Recommended";
    } else {
      level = "More Support Recommended";
    }

    if (strengths.length === 0) {
      const sorted = Object.entries(categoryScores).sort((a, b) => b[1] - a[1]);
      if (sorted[0]) strengths.push(CATEGORY_NAMES[sorted[0][0]] || sorted[0][0]);
    }
    if (supportAreas.length === 0) {
      const sorted = Object.entries(categoryScores).sort((a, b) => a[1] - b[1]);
      if (sorted[0] && sorted[0][1] < 100) supportAreas.push(CATEGORY_NAMES[sorted[0][0]] || sorted[0][0]);
    }

    if (recommendedActivitiesSet.size === 0) {
      recommendedActivitiesSet.add("Memory Match");
      recommendedActivitiesSet.add("Sequence Challenge");
    }

    const recommendations = Array.from(recommendedActivitiesSet).slice(0, 3);

    // Save result to MongoDB asynchronously if connected (never crashes if offline)
    if (isDbConnected()) {
      saveScreeningResult({
        childId: req.body.childId || (req.body.profile && req.body.profile.name) || null,
        profile: req.body.profile || null,
        answers: normalized,
        score: overallScore,
        level,
        categoryScores,
        strengths,
        supportAreas,
        recommendations,
        responseTimeAverage: avgResponseTime,
        totalQuestions: normalized.length,
        correctCount: totalCorrect
      }).catch(err => {
        console.warn("[LearnEase DB] Screening save warning:", err.message);
      });
    }

    return res.json({
      success: true,
      score: overallScore,
      level,
      categoryScores,
      strengths,
      supportAreas,
      recommendations,
      responseTimeAverage: avgResponseTime,
      totalQuestions: normalized.length,
      correctCount: totalCorrect,
      profile: req.body.profile || null
    });
  } catch (error) {
    console.error("Screening calculation error:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to process screening results."
    });
  }
});

/**
 * Dedicated Modular REST API Routes
 */
app.use("/api/children", require("./routes/children"));
app.use("/api/activities", require("./routes/activities"));
app.use("/api/teachers", require("./routes/teachers"));
app.use("/api/sessions", require("./routes/sessions"));
app.use("/api/teacher-notes", require("./routes/teacherNotes"));
app.use("/api/ai-insights", require("./routes/aiInsights"));
app.use("/api/ai-assistant", require("./routes/aiAssistant"));

// Final Express error handler returning JSON
app.use((err, req, res, next) => {
  console.error("Unhandled Express error:", err);
  res.status(500).json({
    success: false,
    message: "Unable to process screening results."
  });
});

// Weekly Assessment
app.post('/api/weekly-assessment', async (req, res) => {
  if (!isDbConnected()) return res.status(503).json({ error: 'Database unavailable', offline: true });
  try {
    const assessment = await mongoose.model('WeeklyAssessment', new mongoose.Schema({
      childId: String, date: { type: Date, default: Date.now },
      scores: Object, overallScore: Number, previousScore: Number, improvements: Object
    }, { strict: false })).create(req.body);
    res.json({ success: true, id: assessment._id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/weekly-assessment/:childId', async (req, res) => {
  if (!isDbConnected()) return res.status(503).json({ error: 'Database unavailable', offline: true });
  try {
    const WeeklyAssessment = mongoose.model('WeeklyAssessment');
    const results = await WeeklyAssessment.find({ childId: req.params.childId }).sort({ date: -1 }).limit(12);
    res.json(results);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/parent-report', async (req, res) => {
  if (!isDbConnected()) return res.status(503).json({ error: 'Database unavailable', offline: true });
  try {
    const ParentReport = new mongoose.Schema({ childId: String, weekOf: Date, reportData: Object }, { strict: false });
    const report = await mongoose.model('ParentReport', ParentReport).create(req.body);
    res.json({ success: true, id: report._id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Single server listener on port 5000
const server = app.listen(PORT, "localhost", () => {
  console.log("LearnEase Backend running at http://localhost:" + PORT);
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error("Port " + PORT + " already in use.");
  } else {
    console.error("Server error:", err);
  }
});
