const mongoose = require('mongoose');

const TeacherNoteSchema = new mongoose.Schema({
  childId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Child',
    default: null
  },
  teacherId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Teacher',
    default: null
  },
  teacherName: {
    type: String,
    default: 'Specialist'
  },
  sessionId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Session',
    default: null
  },
  strengths: {
    type: String,
    default: ''
  },
  observations: {
    type: String,
    default: ''
  },
  practiceAreas: {
    type: String,
    default: ''
  },
  homePractice: {
    type: String,
    default: ''
  },
  nextSessionFocus: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.TeacherNote || mongoose.model('TeacherNote', TeacherNoteSchema);
