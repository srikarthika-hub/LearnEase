const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
  childId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Child',
    default: null
  },
  activityName: {
    type: String,
    required: [true, 'Activity name is required'],
    trim: true
  },
  skill: {
    type: String,
    default: 'general'
  },
  difficulty: {
    type: String,
    enum: ['Easy', 'Medium', 'Hard', 'adaptive'],
    default: 'Medium'
  },
  score: {
    type: Number,
    default: 0
  },
  accuracy: {
    type: Number,
    min: 0,
    max: 100,
    default: 100
  },
  attempts: {
    type: Number,
    default: 1
  },
  responseTime: {
    type: Number,
    default: 0
  },
  completedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.Activity || mongoose.model('Activity', ActivitySchema);
