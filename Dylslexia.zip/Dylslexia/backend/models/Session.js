const mongoose = require('mongoose');

const SessionSchema = new mongoose.Schema({
  childId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Child',
    default: null
  },
  childName: {
    type: String,
    trim: true,
    default: 'Learner'
  },
  teacherId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Teacher',
    default: null
  },
  teacherName: {
    type: String,
    trim: true,
    default: 'Learning Specialist'
  },
  date: {
    type: String,
    required: [true, 'Session date is required']
  },
  duration: {
    type: Number,
    default: 30
  },
  language: {
    type: String,
    default: 'en'
  },
  status: {
    type: String,
    enum: ['scheduled', 'completed', 'cancelled'],
    default: 'scheduled'
  },
  activities: [
    { type: String }
  ],
  consentGranted: {
    type: Boolean,
    default: true
  },
  notes: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.Session || mongoose.model('Session', SessionSchema);
