const mongoose = require('mongoose');

const TeacherSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'User',
    default: null
  },
  name: {
    type: String,
    required: [true, 'Teacher name is required'],
    trim: true
  },
  email: {
    type: String,
    trim: true,
    lowercase: true
  },
  qualification: {
    type: String,
    required: [true, 'Qualification is required'],
    trim: true
  },
  institution: {
    type: String,
    default: 'Independent Specialist',
    trim: true
  },
  experience: {
    type: String,
    default: '3+ Years'
  },
  specializations: [
    { type: String }
  ],
  languages: [
    { type: String }
  ],
  availability: {
    type: String,
    default: 'Available for Sessions'
  },
  credentialStatus: {
    type: String,
    enum: ['pending', 'submitted', 'verified'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.Teacher || mongoose.model('Teacher', TeacherSchema);
