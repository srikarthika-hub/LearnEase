const mongoose = require('mongoose');

const ChildSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Child name is required'],
    trim: true
  },
  age: {
    type: Number,
    min: 3,
    max: 18,
    required: [true, 'Age is required']
  },
  grade: {
    type: String,
    trim: true,
    default: 'Kindergarten'
  },
  language: {
    type: String,
    trim: true,
    default: 'en'
  },
  parentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  }
}, {
  timestamps: true
});

module.exports = mongoose.models.Child || mongoose.model('Child', ChildSchema);
