const mongoose = require('mongoose');

const ScreeningSchema = new mongoose.Schema({
  childId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Child',
    default: null
  },
  profile: {
    name: { type: String, default: 'Learner' },
    age: { type: Number, default: 7 },
    grade: { type: String, default: 'Grade 2' },
    language: { type: String, default: 'en' }
  },
  answers: [
    {
      category: { type: String },
      correct: { type: Boolean },
      responseTime: { type: Number }
    }
  ],
  overallScore: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  level: {
    type: String,
    default: 'Some Practice Recommended'
  },
  categoryScores: {
    type: Map,
    of: Number,
    default: {}
  },
  strengths: [
    { type: String }
  ],
  supportAreas: [
    { type: String }
  ],
  recommendations: [
    { type: String }
  ],
  responseTimeAverage: {
    type: Number,
    default: 0
  },
  totalQuestions: {
    type: Number,
    default: 0
  },
  correctCount: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.Screening || mongoose.model('Screening', ScreeningSchema);
