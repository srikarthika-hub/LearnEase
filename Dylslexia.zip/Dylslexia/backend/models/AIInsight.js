const mongoose = require('mongoose');

const AIInsightSchema = new mongoose.Schema({
  childId: {
    type: mongoose.Schema.Types.Mixed,
    ref: 'Child',
    default: null
  },
  source: {
    type: String,
    enum: ['screening', 'activity', 'session', 'assistant'],
    default: 'screening'
  },
  skill: {
    type: String,
    default: 'General Learning'
  },
  insight: {
    type: String,
    required: [true, 'Insight text is required']
  },
  recommendation: {
    type: String,
    default: ''
  },
  confidence: {
    type: Number,
    min: 0,
    max: 1,
    default: 0.85
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.AIInsight || mongoose.model('AIInsight', AIInsightSchema);
