const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const { isDbConnected } = require('../config/db');
const Child = require('../models/Child');

/**
 * POST /api/children
 * Create a new child learner record
 */
router.post('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { name, age, grade, language, parentId } = req.body;
    if (!name || !age) {
      return res.status(400).json({
        success: false,
        message: "Child name and age are required."
      });
    }

    const child = await Child.create({
      name: name.trim(),
      age: Number(age),
      grade: grade || 'Kindergarten',
      language: language || 'en',
      parentId: parentId || null
    });

    res.status(201).json({
      success: true,
      data: child
    });
  } catch (err) {
    console.error('[LearnEase DB] Child creation error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

/**
 * GET /api/children/:id
 * Retrieve child record by ID or name
 */
router.get('/:id', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { id } = req.params;
    let child = null;

    if (mongoose.Types.ObjectId.isValid(id)) {
      child = await Child.findById(id);
    } else {
      child = await Child.findOne({ name: new RegExp('^' + id + '$', 'i') });
    }

    if (!child) {
      return res.status(404).json({
        success: false,
        message: "Child record not found."
      });
    }

    res.json({
      success: true,
      data: child
    });
  } catch (err) {
    console.error('[LearnEase DB] Child retrieval error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
