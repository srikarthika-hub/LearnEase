const express = require('express');
const router = express.Router();
const { isDbConnected } = require('../config/db');
const Teacher = require('../models/Teacher');

/**
 * POST /api/teachers
 * Onboard/register a qualified teacher or specialist
 */
router.post('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { name, email, qualification, institution, experience, specializations, languages, availability, credentialStatus } = req.body;
    if (!name || !qualification) {
      return res.status(400).json({
        success: false,
        message: "Teacher name and qualification are required."
      });
    }

    const teacher = await Teacher.create({
      name: name.trim(),
      email: (email || '').trim().toLowerCase(),
      qualification: qualification.trim(),
      institution: institution || 'Independent Specialist',
      experience: experience || '3+ Years',
      specializations: Array.isArray(specializations) ? specializations : [specializations].filter(Boolean),
      languages: Array.isArray(languages) ? languages : [languages].filter(Boolean),
      availability: availability || 'Available for Sessions',
      credentialStatus: credentialStatus === 'submitted' ? 'submitted' : 'pending' // Default pending, never auto-verified
    });

    res.status(201).json({
      success: true,
      data: teacher
    });
  } catch (err) {
    console.error('[LearnEase DB] Teacher registration error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

/**
 * GET /api/teachers
 * Retrieve list of registered specialists
 */
router.get('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const teachers = await Teacher.find().sort({ createdAt: -1 });
    res.json({
      success: true,
      count: teachers.length,
      data: teachers
    });
  } catch (err) {
    console.error('[LearnEase DB] Teachers fetch error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
