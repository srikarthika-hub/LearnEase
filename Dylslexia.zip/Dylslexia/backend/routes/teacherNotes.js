const express = require('express');
const router = express.Router();
const { isDbConnected } = require('../config/db');
const TeacherNote = require('../models/TeacherNote');

/**
 * POST /api/teacher-notes
 * Record qualitative specialist observations and recommended home practice
 */
router.post('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId, teacherId, teacherName, sessionId, strengths, observations, practiceAreas, homePractice, nextSessionFocus } = req.body;

    const note = await TeacherNote.create({
      childId: childId || null,
      teacherId: teacherId || null,
      teacherName: teacherName || 'Specialist',
      sessionId: sessionId || null,
      strengths: strengths || '',
      observations: observations || '',
      practiceAreas: practiceAreas || '',
      homePractice: homePractice || '',
      nextSessionFocus: nextSessionFocus || ''
    });

    res.status(201).json({
      success: true,
      data: note
    });
  } catch (err) {
    console.error('[LearnEase DB] Teacher note save error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

/**
 * GET /api/teacher-notes/:childId
 * Retrieve session notes for a specific child learner
 */
router.get('/:childId', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId } = req.params;
    const filter = childId === 'all' ? {} : { childId };
    const notes = await TeacherNote.find(filter).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: notes.length,
      data: notes
    });
  } catch (err) {
    console.error('[LearnEase DB] Teacher notes fetch error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
