const express = require('express');
const router = express.Router();
const { isDbConnected } = require('../config/db');
const Activity = require('../models/Activity');

/**
 * POST /api/activities
 * Record an activity or learning game completion
 */
router.post('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId, activityName, skill, difficulty, score, accuracy, attempts, responseTime } = req.body;
    if (!activityName) {
      return res.status(400).json({
        success: false,
        message: "activityName is required."
      });
    }

    const activity = await Activity.create({
      childId: childId || null,
      activityName: activityName.trim(),
      skill: skill || 'general',
      difficulty: difficulty || 'Medium',
      score: Number(score) || 0,
      accuracy: Number(accuracy) || 100,
      attempts: Number(attempts) || 1,
      responseTime: Number(responseTime) || 0
    });

    res.status(201).json({
      success: true,
      data: activity
    });
  } catch (err) {
    console.error('[LearnEase DB] Activity creation error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

/**
 * GET /api/activities/:childId
 * Fetch activity history for a specific child learner
 */
router.get('/:childId', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId } = req.params;
    const filter = childId === 'all' ? {} : { childId };
    const activities = await Activity.find(filter).sort({ completedAt: -1 }).limit(100);

    res.json({
      success: true,
      count: activities.length,
      data: activities
    });
  } catch (err) {
    console.error('[LearnEase DB] Activities fetch error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
