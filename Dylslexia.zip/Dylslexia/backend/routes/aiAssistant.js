const express = require("express");
const router = express.Router();

function generateEducationalResponse(query, context) {
  const q = (query || "").toLowerCase().trim();
  const profile = context?.profile || {};
  const screening = context?.screening || {};

  const name = profile.name || "the learner";
  const grade = profile.grade || "Class 3";
  const score = screening.score !== undefined ? screening.score : 78;
  const strengths = Array.isArray(screening.strengths) && screening.strengths.length > 0 
    ? screening.strengths.join(", ") 
    : "Auditory sound identification";
  const supportAreas = Array.isArray(screening.supportAreas) && screening.supportAreas.length > 0 
    ? screening.supportAreas.join(" and ") 
    : "Working Memory and Sequencing";
  const recommendations = Array.isArray(screening.recommendations) && screening.recommendations.length > 0
    ? screening.recommendations
    : ["Memory Match", "Sequence Challenge"];

  // Greetings
  if (/^(hi|hello|hey|greetings|good morning|good afternoon|good evening|namaste|vanakkam)[\s!.]*$/i.test(q)) {
    return "Hello! I am the <strong>LearnEase AI Assistant</strong>. I can help you understand " + name + "\x27s learning progress, explain screening results, suggest personalized practice activities, and assist teachers and parents with structured support plans.<br><br>How can I assist you today?";
  }

  // Tamil Query Support
  if (q.includes("tamil") || q.includes("தமிழ்")) {
    return "<strong>கற்றல் ஆதரவு வழிகாட்டல் (Tamil Educational Support):</strong><br><br>" +
      "LearnEase உங்கள் குழந்தையின் தொடக்கக்கால வாசிப்பு மற்றும் நினைவாற்றல் திறன்களை ஆராய்ந்து எளிய பயிற்சிகளை வழங்குகிறது.<br><br>" +
      "• <strong>அவதானிக்கப்பட்ட நிலை:</strong> " + name + " அவர்களின் மதிப்பீட்டு குறியீடு <strong>" + score + "%</strong>.<br>" +
      "• <strong>பயிற்சி தேவைப்படும் பகுதிகள்:</strong> " + supportAreas + ".<br>" +
      "• <strong>பரிந்துரைக்கப்படும் செயல்பாடுகள்:</strong> " + recommendations.join(", ") + " ஆகியவற்றை தினமும் 10-15 நிமிடங்கள் பயிற்சி செய்யலாம்.<br>" +
      "• <strong>குறிப்பு:</strong> இது ஒரு கல்விசார் ஆதரவு கருவியாகும், மருத்துவ மதிப்பீடு அல்ல.";
  }

  // Hindi Query Support
  if (q.includes("hindi") || q.includes("हिन्दी")) {
    return "<strong>शैक्षिक सहायता मार्गदर्शन (Hindi Educational Support):</strong><br><br>" +
      "LearnEase आपके बच्चे के बुनियादी पठन और स्मृति कौशल को समझकर व्यक्तिगत अभ्यास गतिविधियां प्रदान करता है।<br><br>" +
      "• <strong>वर्तमान स्थिति:</strong> " + name + " का स्क्रीनिंग स्कोर <strong>" + score + "%</strong> है।<br>" +
      "• <strong>अभ्यास क्षेत्र:</strong> " + supportAreas + " में अतिरिक्त अभ्यास सहायक रहेगा।<br>" +
      "• <strong>सुझाई गई गतिविधियाँ:</strong> " + recommendations.join(", ") + " का प्रतिदिन 10-15 मिनट अभ्यास करें।<br>" +
      "• <strong>अभिभावक सुझाव:</strong> बच्चे को छोटे-छोटे चरणों में आत्मविश्वास के साथ पढ़ने के लिए प्रोत्साहित करें।<br>" +
      "• <strong>सूचना:</strong> यह केवल एक सहायक शैक्षिक साधन है, चिकित्सीय निदान नहीं।";
  }

  // Screening result explanation
  if (q.includes("result mean") || q.includes("screening") || q.includes("score mean") || q.includes("observed area")) {
    return "Based on the screening assessment, <strong>" + name + "</strong> (" + grade + ") achieved an overall learning index of <strong>" + score + "%</strong>.<br><br>" +
      "• <strong>Observed Strengths:</strong> " + strengths + ". " + name + " shows solid engagement and auditory pattern recognition.<br>" +
      "• <strong>Practice Areas:</strong> " + supportAreas + ". Slight response latency was observed during multi-step recall tasks.<br>" +
      "• <strong>Support Recommendation:</strong> Focus on 10–15 minutes of playful daily practice using <em>" + recommendations.join("</em> and <em>") + "</em>.<br><br>" +
      "<em>Ethical Framing:</em> LearnEase is an educational screening and learning-support tool. It does not provide a medical or clinical diagnosis. If persistent difficulties continue, we encourage consulting a certified educational specialist or psychologist.";
  }

  // Why Memory Match was recommended
  if (q.includes("memory match") || q.includes("why was memory match")) {
    return "<strong>Memory Match</strong> was recommended because the screening indicated that " + name + " would benefit from strengthening short-term visual and auditory retention pathways.<br><br>" +
      "• <strong>Why Working Memory Matters:</strong> When decoding new words, a child must hold letter sounds in memory while blending them into words.<br>" +
      "• <strong>How It Helps:</strong> Memory Match uses gradual, low-stress sequence lengths (2 to 4 items) to expand working memory capacity naturally without cognitive fatigue.";
  }

  // Today\x27s practice routine
  if (q.includes("practice today") || q.includes("what should we practice") || q.includes("daily plan") || q.includes("routine")) {
    return "Here is the personalized <strong>15-Minute Daily Routine</strong> recommended for <strong>" + name + "</strong> today:<br><br>" +
      "1. <strong>Warm-up (5 mins):</strong> <em>Sound Match</em> — Practice 5 rounds of initial phoneme identification.<br>" +
      "2. <strong>Targeted Focus (5 mins):</strong> <em>" + (recommendations[0] || "Memory Match") + "</em> — Reinforce working memory recall with visual cues.<br>" +
      "3. <strong>Shared Reading (5 mins):</strong> Read a short story together, encouraging " + name + " to track words with a finger.<br><br>" +
      "Consistent, bite-sized daily practice is far more effective and confidence-building than long, tiring sessions!";
  }

  // Home support strategies
  if ((q.includes("support") && (q.includes("home") || q.includes("parent"))) || q.includes("at home")) {
    return "Here are four practical, low-pressure home support strategies for <strong>" + name + "</strong>:<br><br>" +
      "• <strong>Paired Shared Reading:</strong> Read along together for 10 minutes daily. Let " + name + " read familiar words while you gently assist with challenging ones.<br>" +
      "• <strong>Everyday Memory Games:</strong> Play \"I Went to Market\" or ask " + name + " to remember 3 everyday objects before setting the table.<br>" +
      "• <strong>Multi-Sensory Letter Tracing:</strong> Use sand trays, clay, or finger tracing on textured surfaces to reinforce letter shapes (e.g. distinguishing \x27b\x27 and \x27d\x27).<br>" +
      "• <strong>Celebrate Progress:</strong> Praise curiosity and effort rather than speed or test perfection.";
  }

  // Session plan for teachers
  if (q.includes("session plan") || q.includes("lesson plan") || q.includes("teacher plan")) {
    return "<strong>Structured 30-Minute 1-on-1 Specialist Session Plan for " + name + ":</strong><br><br>" +
      "• <strong>Phase 1 (0–5 min): Rapport & Check-in</strong> — Review daily mood and complete 1 quick warm-up round in Sound Match.<br>" +
      "• <strong>Phase 2 (5–15 min): Core Scaffolding</strong> — Focus on " + supportAreas + ". Use interactive cards in the Virtual Learning Room.<br>" +
      "• <strong>Phase 3 (15–25 min): Multi-Sensory Phonics Practice</strong> — Syllable segmentation and word building with immediate positive reinforcement.<br>" +
      "• <strong>Phase 4 (25–30 min): Reflection & Home Goal</strong> — Document qualitative observations in Teacher Notes and assign 1 home activity.";
  }

  // Working memory specific
  if (q.includes("working memory")) {
    return "For <strong>Working Memory</strong> support, we recommend combining visual and auditory memory exercises:<br><br>" +
      "• <strong>Primary Activity:</strong> <em>Memory Match</em> — Start with 2-symbol sequences, increasing gradually to 4 items.<br>" +
      "• <strong>Secondary Activity:</strong> <em>Sequence Challenge</em> — Practice ordinal ordering and pattern completion.<br>" +
      "• <strong>Classroom/Home Tip:</strong> Break multi-step instructions into single, visual chunks (e.g., \"Open book\" -> \"Find page 12\").";
  }

  // Default intelligent educational response
  return "Thank you for asking! For <strong>" + name + "</strong> (" + grade + "), LearnEase recommends focused, low-stress practice targeting <strong>" + supportAreas + "</strong>.<br><br>" +
    "• <strong>Recommended Activity:</strong> You can start with <em>" + (recommendations[0] || "Sound Match") + "</em> or <em>" + (recommendations[1] || "Memory Match") + "</em>.<br>" +
    "• <strong>Specialist Support:</strong> You can also book a virtual 1-on-1 session with a certified specialist under the <em>Specialists</em> tab.<br><br>" +
    "<em>Ethical Note:</em> LearnEase provides supportive educational tools and does not provide clinical diagnoses. Feel free to ask more specific questions about learning plans, games, or home strategies!";
}

router.post("/", async (req, res) => {
  try {
    const { prompt, message, context } = req.body || {};
    const query = prompt || message || "";

    if (!query || typeof query !== "string") {
      return res.status(400).json({
        success: false,
        message: "A valid text prompt or message is required."
      });
    }

    const response = generateEducationalResponse(query, context);

    return res.json({
      success: true,
      response,
      reply: response,
      contextUsed: Boolean(context)
    });
  } catch (error) {
    console.error("[LearnEase AI] Assistant processing error:", error);
    return res.status(500).json({
      success: false,
      message: "AI Assistant is temporarily unavailable. Please try again."
    });
  }
});

module.exports = router;
