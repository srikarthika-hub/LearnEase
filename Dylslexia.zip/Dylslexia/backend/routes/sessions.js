const express = require("express");
const router = express.Router();
const { isDbConnected } = require("../config/db");
const Session = require("../models/Session");

// Resilient in-memory store for offline/standalone execution
const memorySessions = [];

/**
 * GET /api/sessions
 * Retrieve all scheduled/completed sessions
 */
router.get("/", async (req, res) => {
  if (isDbConnected()) {
    try {
      const sessions = await Session.find({}).sort({ createdAt: -1 });
      return res.json({
        success: true,
        count: sessions.length,
        sessions: sessions,
        data: sessions
      });
    } catch (err) {
      console.error("[LearnEase DB] Sessions list DB error:", err.message);
    }
  }

  // Fallback to memorySessions
  return res.json({
    success: true,
    count: memorySessions.length,
    sessions: memorySessions,
    data: memorySessions,
    offline: !isDbConnected()
  });
});

/**
 * POST /api/sessions
 * Book a virtual 1-on-1 learning session with validation and duplicate checking
 */
router.post("/", async (req, res) => {
  try {
    const { 
      childId, 
      childName, 
      teacherId, 
      teacherName, 
      date, 
      sessionDate,
      time,
      sessionTime,
      duration, 
      language, 
      status, 
      activities, 
      consentGranted, 
      notes 
    } = req.body || {};

    // 1. Validation & Normalization
    const cleanChild = (childName || childId || "").trim();
    const cleanTeacher = (teacherName || teacherId || "").trim();
    const cleanDate = (date || (sessionDate ? `${sessionDate}${sessionTime ? " at " + sessionTime : ""}` : "")).trim();

    const missingFields = [];
    if (!cleanDate) missingFields.push("date");
    if (!cleanChild) missingFields.push("childName");
    if (!cleanTeacher) missingFields.push("teacherName");

    if (missingFields.length > 0) {
      return res.status(400).json({
        success: false,
        message: `Missing required field(s): ${missingFields.join(", ")}`,
        missingFields
      });
    }

    const dur = Number(duration) || 30;
    if (dur < 10 || dur > 180) {
      return res.status(400).json({
        success: false,
        message: "Duration must be between 10 and 180 minutes."
      });
    }

    const validLang = (language || "English").trim();

    // 2. Duplicate Booking Check
    if (isDbConnected()) {
      const duplicate = await Session.findOne({
        $or: [
          { childName: cleanChild, teacherName: cleanTeacher, date: cleanDate },
          { childId: cleanChild, teacherId: cleanTeacher, date: cleanDate },
          { childName: cleanChild, teacherId: cleanTeacher, date: cleanDate }
        ],
        status: { $ne: "cancelled" }
      });

      if (duplicate) {
        return res.status(409).json({
          success: false,
          duplicate: true,
          message: "An active session already exists for this learner and specialist at this time."
        });
      }
    } else {
      const memDup = memorySessions.find(s => 
        (s.childName === cleanChild || s.childId === cleanChild) &&
        (s.teacherName === cleanTeacher || s.teacherId === cleanTeacher) &&
        s.date === cleanDate &&
        s.status !== "cancelled"
      );

      if (memDup) {
        return res.status(409).json({
          success: false,
          duplicate: true,
          message: "An active session already exists for this learner and specialist at this time."
        });
      }
    }

    // 3. Create Session in MongoDB (or in memory fallback)
    const sessionObj = {
      id: "sess_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
      childId: childId || cleanChild,
      childName: cleanChild,
      teacherId: teacherId || cleanTeacher,
      teacherName: cleanTeacher,
      date: cleanDate,
      duration: dur,
      language: validLang,
      status: ["scheduled", "completed", "cancelled"].includes(status) ? status : "scheduled",
      activities: Array.isArray(activities) && activities.length > 0 ? activities : ["Working Memory & Sequencing"],
      consentGranted: consentGranted !== false,
      notes: notes || "",
      createdAt: new Date()
    };

    if (isDbConnected()) {
      const doc = await Session.create(sessionObj);
      return res.status(201).json({
        success: true,
        message: "Session booked successfully",
        sessionId: doc._id.toString(),
        session: doc,
        data: doc
      });
    } else {
      memorySessions.unshift(sessionObj);
      return res.status(201).json({
        success: true,
        message: "Session booked successfully (offline mode)",
        sessionId: sessionObj.id,
        session: sessionObj,
        data: sessionObj,
        offline: true
      });
    }
  } catch (err) {
    console.error("[LearnEase DB] Session scheduling error:", err.message);
    return res.status(500).json({
      success: false,
      message: "Failed to create session booking: " + err.message
    });
  }
});

/**
 * GET /api/sessions/:childId
 * Retrieve sessions for a specific child learner
 */
router.get("/:childId", async (req, res) => {
  const { childId } = req.params;
  const filterVal = (childId || "").trim();

  if (isDbConnected()) {
    try {
      const filter = filterVal === "all" 
        ? {} 
        : { $or: [{ childId: filterVal }, { childName: filterVal }] };

      const sessions = await Session.find(filter).sort({ createdAt: -1 });

      return res.json({
        success: true,
        count: sessions.length,
        sessions,
        data: sessions
      });
    } catch (err) {
      console.error("[LearnEase DB] Sessions fetch error:", err.message);
    }
  }

  // Memory fallback
  const filtered = filterVal === "all"
    ? memorySessions
    : memorySessions.filter(s => s.childId === filterVal || s.childName === filterVal);

  return res.json({
    success: true,
    count: filtered.length,
    sessions: filtered,
    data: filtered,
    offline: !isDbConnected()
  });
});

module.exports = router;
