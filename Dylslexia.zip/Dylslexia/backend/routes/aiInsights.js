const express = require('express');
const router = express.Router();
const { isDbConnected } = require('../config/db');
const AIInsight = require('../models/AIInsight');

/**
 * POST /api/ai-insights
 * Record AI-generated educational suggestions and micro-interventions
 */
router.post('/', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId, source, skill, insight, recommendation, confidence } = req.body;
    if (!insight) {
      return res.status(400).json({
        success: false,
        message: "insight text is required."
      });
    }

    const aiInsight = await AIInsight.create({
      childId: childId || null,
      source: source || 'screening',
      skill: skill || 'General Learning',
      insight,
      recommendation: recommendation || '',
      confidence: typeof confidence === 'number' ? confidence : 0.85
    });

    res.status(201).json({
      success: true,
      data: aiInsight
    });
  } catch (err) {
    console.error('[LearnEase DB] AI insight save error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

/**
 * GET /api/ai-insights/:childId
 * Retrieve AI insights for a specific child learner
 */
router.get('/:childId', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId } = req.params;
    const filter = childId === 'all' ? {} : { childId };
    const insights = await AIInsight.find(filter).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: insights.length,
      data: insights
    });
  } catch (err) {
    console.error('[LearnEase DB] AI insights fetch error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
