const express = require('express');
const router = express.Router();
const { isDbConnected } = require('../config/db');
const Screening = require('../models/Screening');

/**
 * Safe asynchronous helper to persist screening results to MongoDB
 */
async function saveScreeningResult(data) {
  if (!isDbConnected()) return null;
  try {
    const doc = await Screening.create({
      childId: data.childId || (data.profile && data.profile.name) || null,
      profile: data.profile || {},
      answers: data.answers || [],
      overallScore: data.score,
      level: data.level,
      categoryScores: data.categoryScores,
      strengths: data.strengths,
      supportAreas: data.supportAreas,
      recommendations: data.recommendations,
      responseTimeAverage: data.responseTimeAverage || 0,
      totalQuestions: data.totalQuestions || 0,
      correctCount: data.correctCount || 0
    });
    return doc;
  } catch (err) {
    console.error('[LearnEase DB] Screening save warning:', err.message);
    return null;
  }
}

/**
 * GET /api/screening/:childId
 * Retrieve screening records for a child
 */
router.get('/:childId', async (req, res) => {
  if (!isDbConnected()) {
    return res.status(503).json({
      success: false,
      message: "Database operation failed"
    });
  }

  try {
    const { childId } = req.params;
    const filter = childId === 'all' ? {} : { childId };
    const screenings = await Screening.find(filter).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: screenings.length,
      data: screenings
    });
  } catch (err) {
    console.error('[LearnEase DB] Screening fetch error:', err.message);
    res.status(500).json({
      success: false,
      message: "Database operation failed"
    });
  }
});

module.exports = router;
module.exports.saveScreeningResult = saveScreeningResult;
