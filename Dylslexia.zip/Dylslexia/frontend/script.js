/**
 * LearnEase — Professional EdTech Screening & Intervention Engine
 * Core Application Logic (Zero Emojis, Clean Black & Blue Theme)
 */

(function () {
  'use strict';

  // ==========================================================================
  // 1. CONSTANTS & LOCAL STORAGE KEYS
  // ==========================================================================
  const STORAGE_KEYS = {
    PROFILE: 'learnease_profile',
    SCREENING: 'learnease_screening',
    PROGRESS: 'learnease_progress',
    LANGUAGE: 'learnease_language',
    TEACHER_PROFILES: 'learnease_teacher_profiles',
    SESSIONS: 'learnease_sessions',
    SESSION_NOTES: 'learnease_session_notes',
    TEACHER_CONSENT: 'learnease_teacher_consent',
    AI_INSIGHTS: 'learnease_ai_insights',
    // NEW KEYS — Mega Upgrade
    CURRENT_USER: 'learnease_current_user',
    USER_ACCOUNTS: 'learnease_user_accounts',
    ACCESSIBILITY: 'learnease_accessibility',
    WEEKLY_ASSESSMENT: 'learnease_weekly_assessment',
    READINESS: 'learnease_readiness',
    DAILY_PLAN: 'learnease_daily_plan',
    LEARNING_FINGERPRINT: 'learnease_learning_fingerprint'
  };

  const BACKEND_BASE = 'http://localhost:5000/api';
  const API_URL = `${BACKEND_BASE}/screening`;

  // Resilient backend sync helper (gracefully ignores offline / unhandled network states)
  async function syncWithBackend(endpoint, data) {
    try {
      const res = await fetch(`${BACKEND_BASE}/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Graceful offline fallback: local storage already preserves state
    }
    return null;
  }

  // ==========================================================================
  // 2. CLEAN MULTILINGUAL TRANSLATION DICTIONARY (ZERO EMOJIS)
  // ==========================================================================
  const translations = {
    en: {
      disclaimer_short: 'LearnEase is an educational screening and learning-support tool. It does not provide a medical diagnosis.',
      nav_home: 'Home',
      nav_screening: 'Screening',
      nav_learn: 'Learn',
      nav_progress: 'Progress',
      nav_specialists: 'Specialists',
      nav_teacher: 'Teacher Portal',
      nav_about: 'About',
      start_screening_btn: 'Start Screening',
      start_screening_arrow: 'Start Screening',
      explore_learning: 'Explore Learning',
      hero_badge: 'Early Educational Screening & Learning Support',
      hero_subtitle: 'LearnEase helps identify learning needs early and turns them into personalized learning support through accessible screening, adaptive activities, and meaningful progress insights.',
      trust_child_friendly: 'Early Screening',
      trust_multilingual: 'Multilingual Support',
      trust_privacy: 'Privacy-First & Non-Diagnostic',
      trust_pillars_badge: 'Core Architecture',
      trust_pillars_title: 'Empowering Every Learning Journey',
      trust_pillars_desc: 'Four dedicated pillars designed specifically for early childhood education and supportive care.',
      card_screening_title: 'Early Screening',
      card_screening_desc: 'Identify foundational learning areas that may benefit from additional support through structured skill evaluations.',
      card_personalized_title: 'Personalized Learning',
      card_personalized_desc: 'Generate customized learning activities and adaptive exercises matched to each child\'s individual performance profile.',
      card_multilingual_title: 'Multilingual Support',
      card_multilingual_desc: 'Engineered for India\'s diverse linguistic environment with native support for English, Tamil, and Hindi, expandable across regional languages.',
      card_insights_title: 'Parent & Teacher Insights',
      card_insights_desc: 'Track learning progress and access practical, non-clinical recommendations for both home routines and classroom settings.',
      impact_badge: 'The LearnEase Model',
      impact_title: 'From Detection to Intervention',
      impact_desc: 'Bridging the gap between initial concern and everyday learning practice.',
      impact_step1_title: 'Identify',
      impact_step1_desc: 'Screen across key learning skill areas — phonological awareness, rhyming, letter recognition, sequencing, working memory, and reading patterns.',
      impact_step1_tag: 'Non-Invasive Activity',
      impact_step2_title: 'Understand',
      impact_step2_desc: 'Break performance into meaningful skill insights and constructive benchmarks without medical labels or discouraging scoring.',
      impact_step2_tag: 'Objective Analytics',
      impact_step3_title: 'Support',
      impact_step3_desc: 'Turn insights into personalized learning activities, home practice routines, and transparent longitudinal progress tracking.',
      impact_step3_tag: 'Targeted Practice',
      flow_badge: 'Process Framework',
      flow_title: 'How LearnEase Works',
      flow_desc: 'A streamlined, child-centered continuum from initial profile to actionable progress.',
      step_profile: 'Child Profile',
      step_screening: 'Screening',
      step_analysis: 'Skill Analysis',
      step_activities: 'Personalized Activities',
      step_progress: 'Progress',
      step_insights: 'Insights',
      compare_badge: 'Transforming Intervention',
      compare_title: 'From Screening to Support',
      compare_subtitle: 'Why early, accessible, digital screening changes outcomes for children.',
      compare_traditional_tag: 'Traditional Approach',
      compare_traditional_title: 'Often Delayed & Stressful',
      compare_learnease_tag: 'LearnEase Platform',
      compare_learnease_title: 'Early, Engaging & Actionable',
      multi_badge: 'Linguistic Inclusion',
      multi_title: 'Learning Should Speak the Child\'s Language.',
      multi_desc: 'In India, children learn in diverse mother tongues and bilingual home environments. LearnEase provides immediate screening support in English, Tamil, and Hindi, with a modular architecture ready for regional languages across the subcontinent.',
      privacy_title: 'Child-First Privacy & Safety',
      privacy_desc: 'LearnEase stores screening responses and progress strictly on your device using browser local storage. No personally identifiable records, photographs, or contact details are transmitted to public servers or monetized. LearnEase is completely dedicated to educational empowerment.',
      cta_banner_title: 'Ready to Discover Your Child\'s Learning Strengths?',
      cta_banner_text: 'Takes approximately 8 to 10 minutes. A comfortable, structured screening experience for young learners.',
      listen_audio: 'Listen',
      memory_instruction: 'Remember this sequence:',
      memory_memorize: 'Memorize before it disappears...',
      analyzing_title: 'Analysing your learning snapshot...',
      analyzing_desc: 'Our educational engine is evaluating skill responses to prepare personalized support.',
      results_badge: 'Evaluation Completed',
      snapshot_title: 'Learning Snapshot',
      snapshot_subtitle: 'A clear overview of foundational learning skills, identified strengths, and recommended practice activities.',
      overall_screening_score: 'Overall Screening Index',
      skill_breakdown_title: 'Foundational Skill Breakdown',
      skill_breakdown_desc: 'Specific performance across the evaluated cognitive and literacy domains.',
      strengths_title: 'Skill Strengths',
      strengths_note: 'Celebrate these foundational building blocks and continue encouraging these areas of confidence.',
      support_title: 'Areas for Practice',
      support_note: 'Targeted, regular practice in these areas will reinforce reading ease and cognitive processing.',
      rec_badge: 'Adaptive Recommendations',
      rec_title: 'Recommended Learning Path',
      rec_subtitle: 'Targeted activities selected based on the screening analysis results.',
      view_full_progress: 'View Full Progress',
      start_first_game: 'Start Recommended Game',
      restart_screening: 'Start New Screening',
      disclaimer_full: 'LearnEase is an educational screening and learning-support tool. It does not provide a medical diagnosis. If concerns persist, consult a qualified educational psychologist or healthcare professional.',
      learn_badge: 'Targeted Exercises',
      learn_title: 'Personalized Learning',
      learn_subtitle: 'Activities selected based on the learner\'s current skill profile, designed to build literacy, working memory, and sequential reasoning.',
      diff_easy: 'Easy',
      diff_med: 'Medium',
      play_now: 'Start Activity →',
      game1_title: 'Sound Match',
      game1_desc: 'Practice identifying initial word sounds and phonetic connections with audio prompts.',
      game2_title: 'Memory Match',
      game2_desc: 'Observe, recall, and reproduce sequences of letters, numbers, and symbols to strengthen working memory.',
      game3_title: 'Sequence Challenge',
      game3_desc: 'Identify logical pattern progressions and arrange letters, numbers, or geometric items in correct order.',
      game4_title: 'Letter Hunt',
      game4_desc: 'Identify and distinguish letters that look similar (b, d, p, q) through structured visual discrimination.',
      game5_title: 'Word Builder',
      game5_desc: 'Assemble phonics units to construct simple, age-appropriate vocabulary and sound patterns.',
      game6_title: 'Rhyming Practice',
      game6_desc: 'Identify rhyming pairs and auditory rhythms across English, Tamil, and Hindi vocabulary words.',
      play_again: 'Play Again',
      try_another: 'Try Another Activity →',
      progress_badge: 'Analytics Dashboard',
      progress_title: 'Learning Progress',
      progress_subtitle: 'Monitor longitudinal skill progression, activity completions, and structured support steps.',
      load_demo_data: 'Load Demo Data',
      reset_data: 'Reset Data',
      edit_profile: 'Edit Profile',
      empty_title: 'Your learning journey starts here',
      empty_desc: 'Complete your first screening or explore activities to see personalized progress insights.',
      start_first_screening: 'Start Screening →',
      stat_latest_score: 'Latest Screening',
      stat_completed: 'Activities Completed',
      stat_streak: 'Current Streak',
      stat_skills: 'Skills Practiced',
      dash_skill_progress: 'Skill Performance',
      dash_skill_subtitle: 'Cognitive and literacy mastery based on recent sessions.',
      dash_weekly_title: 'Weekly Activity Progress',
      dash_weekly_subtitle: 'Daily learning exercises completed across the current week.',
      dash_history_title: 'Activity History',
      dash_history_subtitle: 'Chronological record of screenings and practice game sessions.',
      col_date: 'Date',
      col_activity: 'Activity',
      col_category: 'Category',
      col_score: 'Score',
      col_status: 'Status',
      next_steps_title: 'Learning Insights',
      next_steps_subtitle: 'Structured, supportive guidance for home and classroom learning routines.',
      tip1_title: 'Practice phonics for 10 minutes',
      tip1_desc: 'Short, focused phonological exercises like Sound Match build phonetic confidence without causing fatigue.',
      tip2_title: 'Try memory activities together',
      tip2_desc: 'Practice recalling sequences of 3 to 4 items in daily life, such as numbers, colors, or everyday objects.',
      tip3_title: 'Read together for 15 minutes',
      tip3_desc: 'Paired shared reading reduces decoding stress while cultivating rich vocabulary and sentence familiarity.',
      tip4_title: 'Repeat screening in 4 to 6 weeks',
      tip4_desc: 'Monitor objective skill improvements over time after consistent, regular intervention practice.',
      tip5_title: 'Consider discussing with a qualified professional',
      tip5_desc: 'If high support needs persist across multiple screening cycles and classroom activities, consider consulting a qualified special educator, educational psychologist, or developmental pediatrician for comprehensive evaluation.',
      about_badge: 'About LearnEase',
      about_title: 'Platform Overview & Methodology',
      about_subtitle: 'An accessible educational screening and intervention system engineered to bridge early learning gaps across India.',
      about_what_title: 'What is LearnEase?',
      about_what_desc: 'LearnEase is an educational technology platform designed to support early identification of learning differences such as dyslexia. By combining structured digital screening with instant personalized interventions, LearnEase transforms what was once a stressful clinical evaluation into a constructive learning experience.',
      about_who_title: 'Who is it for?',
      about_why_title: 'Why India?',
      about_why_desc: 'India\'s classrooms are rich in linguistic diversity, with millions of students navigating multilingual environments at home and school. Traditional diagnostic tools are predominantly developed in monolingual contexts and remain inaccessible in rural or semi-urban regions. LearnEase is built from the ground up for multilingual accessibility, offering native screening in English, Tamil, and Hindi, with a modular framework ready for Telugu, Kannada, Bengali, and beyond.',
      guardrail_title: 'Ethical Framing & Non-Diagnostic Commitment',
      guardrail_desc: 'LearnEase is an educational screening and learning-support tool. It does not provide medical or clinical diagnoses. We strictly avoid clinical labeling, instead emphasizing learning support needs, strengths, and tailored practice. If severe difficulties persist, families are encouraged to seek professional assessment.',
      onboarding_title: 'Learner Profile Setup',
      onboarding_subtitle: 'Configure your learner\'s profile to begin a customized screening assessment.',
      field_child_name: 'Child\'s Name',
      field_age: 'Age',
      field_grade: 'Class / Grade',
      field_language: 'Preferred Language',
      field_role: 'Your Role',
      role_parent: 'Parent',
      role_teacher: 'Teacher / Educator',
      consent_statement: 'I understand that LearnEase provides educational screening support and is not a medical diagnosis.',
      cancel_btn: 'Cancel',
      continue_screening: 'Continue',
      footer_navigation: 'Platform',
      footer_languages: 'Languages',
      footer_disclaimer_title: 'Notice',
      tagline_main: 'Every Child Learns Differently.',
      tagline_sub: 'Screen Early. Learn Better. Grow Confidently.'
    },

    ta: {
      disclaimer_short: 'LearnEase ஒரு கல்விசார் திரையிடல் மற்றும் கற்றல் ஆதரவு கருவியாகும். இது மருத்துவக் கண்டறிதலை வழங்காது.',
      nav_home: 'முகப்பு',
      nav_screening: 'திரையிடல்',
      nav_learn: 'கற்க',
      nav_progress: 'முன்னேற்றம்',
      nav_specialists: 'வல்லுநர்கள்',
      nav_teacher: 'ஆசிரியர் தளம்',
      nav_about: 'எங்களை பற்றி',
      start_screening_btn: 'திரையிடலை தொடங்கு',
      start_screening_arrow: 'திரையிடலை தொடங்கு',
      explore_learning: 'கற்றலை ஆராய்க',
      hero_badge: 'ஆரம்பக் கல்வி திரையிடல் மற்றும் ஆதரவு',
      hero_subtitle: 'LearnEase ஆரம்பத்திலேயே கற்றல் தேவைகளைக் கண்டறிந்து, கட்டமைக்கப்பட்ட செயல்பாடுகள், பன்மொழி அணுகல் மற்றும் தெளிவான முன்னேற்றப் பதிவுகளுடன் தனிப்பயனாக்கப்பட்ட ஆதரவாக மாற்றுகிறது.',
      trust_child_friendly: 'ஆரம்ப திரையிடல்',
      trust_multilingual: 'பன்மொழி ஆதரவு',
      trust_privacy: 'தனியுரிமை & மருத்துவமற்றது',
      trust_pillars_badge: 'அடிப்படைக் கட்டமைப்பு',
      trust_pillars_title: 'ஒவ்வொரு குழந்தையின் கற்றலையும் மேம்படுத்துதல்',
      trust_pillars_desc: 'ஆரம்பக் கல்வி மற்றும் ஆதரவான பராமரிப்பிற்காக வடிவமைக்கப்பட்ட நான்கு தூண்கள்.',
      card_screening_title: 'ஆரம்ப திரையிடல்',
      card_screening_desc: 'கூடுதல் ஆதரவு தேவைப்படும் கற்றல் பகுதிகளை அடையாளம் காணுதல்.',
      card_personalized_title: 'தனிப்பயனாக்கப்பட்ட கற்றல்',
      card_personalized_desc: 'ஒவ்வொரு குழந்தையின் செயல்திறனுக்கு ஏற்ப கற்றல் பயிற்சிகளை உருவாக்குதல்.',
      card_multilingual_title: 'பன்மொழி ஆதரவு',
      card_multilingual_desc: 'தமிழ், ஆங்கிலம் மற்றும் இந்தி மொழிகளுடன் இந்தியாவின் பன்மொழி சூழலுக்காக உருவாக்கப்பட்டது.',
      card_insights_title: 'பெற்றோர் & ஆசிரியர் பார்வை',
      card_insights_desc: 'கற்றல் முன்னேற்றத்தைக் கண்காணித்து, நடைமுறை வழிகாட்டுதல்களைப் பெறுங்கள்.',
      impact_badge: 'LearnEase அணுகுமுறை',
      impact_title: 'கண்டறிதலில் இருந்து கற்பித்தல் வரை',
      impact_desc: 'கற்றல் இடைவெளிகளை உடனடியாக நடைமுறைப் பயிற்சிகளாக மாற்றும் தளம்.',
      impact_step1_title: 'அடையாளம் காணல்',
      impact_step1_desc: 'ஒலி விழிப்புணர்வு, நினைவாற்றல் மற்றும் எழுத்து அறிவை முறையான திரையிடுதல்.',
      impact_step1_tag: 'மன அழுத்தமற்ற செயல்பாடு',
      impact_step2_title: 'புரிந்துகொள்ளுதல்',
      impact_step2_desc: 'மருத்துவக் குறியீடுகள் இன்றி குழந்தையின் கற்றல் பலங்களை நேர்மறையாகப் பகுப்பாய்வு செய்தல்.',
      impact_step2_tag: 'தெளிவான பகுப்பாய்வு',
      impact_step3_title: 'ஆதரவளித்தல்',
      impact_step3_desc: 'கற்றல் இடைவெளிகளை நிரப்ப இலக்குப் பயிற்சிகள் மற்றும் தொடர் முன்னேற்றப் பதிவு.',
      impact_step3_tag: 'இலக்குப் பயிற்சி',
      flow_badge: 'படிநிலை கட்டமைப்பு',
      flow_title: 'LearnEase எவ்வாறு செயல்படுகிறது',
      flow_desc: 'குழந்தையின் சுயவிவரம் முதல் தெளிவான முன்னேற்றப் பதிவு வரையிலான பாதை.',
      step_profile: 'சுயவிவரம்',
      step_screening: 'திரையிடல்',
      step_analysis: 'திறன் பகுப்பாய்வு',
      step_activities: 'பரிந்துரை பயிற்சிகள்',
      step_progress: 'முன்னேற்றம்',
      step_insights: 'வழிகாட்டுதல்',
      compare_badge: 'புதிய மாற்றம்',
      compare_title: 'திரையிடலில் இருந்து ஆதரவு வரை',
      compare_subtitle: 'ஆரம்ப கால எளிமையான திரையிடல் குழந்தையின் கற்றல் எதிர்காலத்தை மாற்றுகிறது.',
      compare_traditional_tag: 'பாரம்பரிய முறை',
      compare_traditional_title: 'நீண்ட காத்திருப்பும் மன அழுத்தமும்',
      compare_learnease_tag: 'LearnEase தளம்',
      compare_learnease_title: 'விரைவான, பயனுள்ள முறை',
      multi_badge: 'மொழி உள்ளடக்கம்',
      multi_title: 'கற்றல் குழந்தையின் தாய்மொழியில் பேச வேண்டும்.',
      multi_desc: 'இந்தியாவில் குழந்தைகள் பல மொழிகள் பேசும் சூழலில் வளர்கிறார்கள். LearnEase ஆங்கிலம், தமிழ் மற்றும் இந்தி மொழிகளில் நேரடி ஆதரவை வழங்குகிறது.',
      privacy_title: 'குழந்தை-முதன்மை பாதுகாப்பு & தனியுரிமை',
      privacy_desc: 'அனைத்து தகவல்களும் உங்கள் சாதனத்திலேயே சேமிக்கப்படுகின்றன. எந்தவொரு தனிப்பட்ட தகவலும் வெளிப்புற சேவையகங்களுக்கு அனுப்பப்படுவதில்லை.',
      cta_banner_title: 'உங்கள் குழந்தையின் கற்றல் பலங்களைக் கண்டறிய தயாரா?',
      cta_banner_text: '8 முதல் 10 நிமிடங்கள் மட்டுமே ஆகும். குழந்தைகளுக்கு வசதியான கற்றல் அனுபவம்.',
      listen_audio: 'கேட்க',
      memory_instruction: 'இந்த வரிசையை நினைவில் வையுங்கள்:',
      memory_memorize: 'மறைவதற்குள் நினைவில் நிறுத்துங்கள்...',
      analyzing_title: 'கற்றல் தரவு பகுப்பாய்வு செய்யப்படுகிறது...',
      analyzing_desc: 'தனிப்பயனாக்கப்பட்ட ஆதரவைத் தயாரிக்க எங்களது கல்வி எஞ்சின் பதில்களை மதிப்பீடு செய்கிறது.',
      results_badge: 'மதிப்பீடு முடிந்தது',
      snapshot_title: 'கற்றல் பார்வை',
      snapshot_subtitle: 'குழந்தையின் பலங்கள் மற்றும் பயிற்சி தேவைப்படும் பகுதிகளின் சுருக்கம்.',
      overall_screening_score: 'ஒட்டுமொத்த திரையிடல் குறியீடு',
      skill_breakdown_title: 'அடிப்படைக் கற்றல் திறன் விவரம்',
      skill_breakdown_desc: 'மதிப்பிடப்பட்ட முக்கிய கற்றல் பகுதிகளின் விரிவான செயல்திறன்.',
      strengths_title: 'திறன் பலங்கள்',
      strengths_note: 'இந்த சிறப்பான திறன்களைப் பாராட்டுங்கள் மற்றும் ஊக்கப்படுத்துங்கள்.',
      support_title: 'பயிற்சி தேவைப்படும் பகுதிகள்',
      support_note: 'எளிய தினசரி பயிற்சிகள் மூலம் இப்பகுதிகளை எளிதாக மேம்படுத்தலாம்.',
      rec_badge: 'தனிப்பயனாக்கப்பட்ட கற்றல் பாதை',
      rec_title: 'பரிந்துரைக்கப்பட்ட கற்றல் பாதை',
      rec_subtitle: 'திரையிடல் முடிவுகளின் அடிப்படையில் தேர்ந்தெடுக்கப்பட்ட செயல்பாடுகள்.',
      view_full_progress: 'முழு முன்னேற்றத்தைக் காண்க',
      start_first_game: 'பரிந்துரைக்கப்பட்ட பயிற்சியைத் தொடங்கு',
      restart_screening: 'புதிய திரையிடலைத் தொடங்கு',
      disclaimer_full: 'LearnEase ஒரு கல்விசார் திரையிடல் மற்றும் கற்றல் ஆதரவு கருவியாகும். இது மருத்துவக் கண்டறிதலை வழங்காது. கவலைகள் தொடர்ந்தால் தகுதியான கல்வி அல்லது சுகாதார நிபுணரை அணுகவும்.',
      learn_badge: 'இலக்குப் பயிற்சிகள்',
      learn_title: 'தனிப்பயனாக்கப்பட்ட கற்றல்',
      learn_subtitle: 'ஒலி விழிப்புணர்வு, நினைவாற்றல் மற்றும் எழுத்து அறிவை வளர்க்கும் பயிற்சிகள்.',
      diff_easy: 'எளிது',
      diff_med: 'நடுத்தரம்',
      play_now: 'தொடங்கு →',
      game1_title: 'ஒலி பொருத்தம் (Sound Match)',
      game1_desc: 'ஒலிகளை அடையாளம் காணும் ஒலிப்புப் பயிற்சி.',
      game2_title: 'நினைவாற்றல் பயிற்சி (Memory Match)',
      game2_desc: 'வரிசைகளை நினைவில் வைத்து நினைவாற்றலை பலப்படுத்துங்கள்.',
      game3_title: 'வரிசை சவால் (Sequence Challenge)',
      game3_desc: 'பொருட்கள் மற்றும் எண்களை சரியான வரிசையில் அமையுங்கள்.',
      game4_title: 'எழுத்து தேடல்',
      game4_desc: 'ஒத்த எழுத்துக்களை அடையாளம் கண்டு பாகுபடுத்துங்கள்.',
      game5_title: 'சொல் உருவாக்குதல்',
      game5_desc: 'எழுத்துக்களை இணைத்து எளிய சொற்களை உருவாக்குங்கள்.',
      game6_title: 'இயைபுச் சொல் பயிற்சி',
      game6_desc: 'ஒத்த ஓசை கொண்ட சொற்களைப் பொருத்துங்கள்.',
      play_again: 'மீண்டும் செய்',
      try_another: 'அடுத்த செயல்பாட்டை முயற்சி செய் →',
      progress_badge: 'பகுப்பாய்வு பலகை',
      progress_title: 'கற்றல் முன்னேற்றம்',
      progress_subtitle: 'கற்றல் திறன் வளர்ச்சி மற்றும் செயல்பாட்டு வரலாற்றைக் கண்காணிக்கவும்.',
      load_demo_data: 'மாதிரித் தரவை ஏற்று',
      reset_data: 'தரவை மீட்டமைக்க',
      edit_profile: 'சுயவிவரத்தை மாற்று',
      empty_title: 'உங்கள் கற்றல் பயணம் இங்கே தொடங்குகிறது',
      empty_desc: 'தனிப்பயனாக்கப்பட்ட முன்னேற்றத்தைக் காண முதல் திரையிடலை முடிக்கவும்.',
      start_first_screening: 'திரையிடலை தொடங்கு →',
      stat_latest_score: 'சமீபத்திய திரையிடல்',
      stat_completed: 'முடிக்கப்பட்ட பயிற்சிகள்',
      stat_streak: 'தொடர் நாட்கள்',
      stat_skills: 'பயிற்சி பெற்ற திறன்கள்',
      dash_skill_progress: 'திறன் செயல்திறன்',
      dash_skill_subtitle: 'சமீபத்திய அமர்வுகளின் அடிப்படையிலான திறன் வளர்ச்சி.',
      dash_weekly_title: 'வாராந்திர செயல்பாட்டு முன்னேற்றம்',
      dash_weekly_subtitle: 'இந்த வாரத்தில் முடிக்கப்பட்ட கற்றல் பயிற்சிகள்.',
      dash_history_title: 'செயல்பாட்டு வரலாறு',
      dash_history_subtitle: 'திரையிடல்கள் மற்றும் பயிற்சிகளின் காலவரிசைப் பதிவு.',
      col_date: 'தேதி',
      col_activity: 'செயல்பாடு',
      col_category: 'பிரிவு',
      col_score: 'மதிப்பெண்',
      col_status: 'நிலை',
      next_steps_title: 'கற்றல் வழிகாட்டுதல்கள்',
      next_steps_subtitle: 'வீட்டு மற்றும் வகுப்பறை கற்றலுக்கான நடைமுறை வழிகாட்டுதல்கள்.',
      tip1_title: '10 நிமிடங்கள் ஒலிப்புப் பயிற்சி செய்யுங்கள்',
      tip1_desc: 'ஒலி பொருத்தம் போன்ற குறுகிய பயிற்சிகள் குழந்தையின் ஆர்வத்தை அதிகரிக்கும்.',
      tip2_title: 'நினைவாற்றல் பயிற்சிகளை இணைந்து செய்யுங்கள்',
      tip2_desc: 'தினசரி வாழ்வில் 3-4 பொருட்களை வரிசையாக நினைவில் கொள்ளும் பயிற்சிகள் செய்யுங்கள்.',
      tip3_title: '15 நிமிடங்கள் இணைந்து வாசியுங்கள்',
      tip3_desc: 'சேர்ந்து வாசிப்பது வாசிப்பு அச்சத்தைக் குறைத்து சொல்லகராதியை வளர்க்கிறது.',
      tip4_title: '4 முதல் 6 வாரங்களில் மீண்டும் திரையிடுங்கள்',
      tip4_desc: 'தொடர் பயிற்சிகளுக்குப் பின் குழந்தையின் முன்னேற்றத்தை எளிதாகக் கண்காணிக்கலாம்.',
      tip5_title: 'தேவையெனில் தகுதிவாய்ந்த நிபுணரை அணுகுங்கள்',
      tip5_desc: 'கற்றல் சவால்கள் தொடர்ந்து நீடித்தால், சிறப்பு கல்வியாளர் அல்லது மருத்துவ நிபுணரை அணுகி முழுமையான மதிப்பீடு பெறலாம்.',
      about_badge: 'LearnEase பற்றி',
      about_title: 'தள மேலோட்டம் மற்றும் முறையியல்',
      about_subtitle: 'இந்தியக் குழந்தைகளுக்கான எளிமையான ஆரம்ப கற்றல் ஆதரவு தளம்.',
      about_what_title: 'LearnEase என்றால் என்ன?',
      about_what_desc: 'LearnEase என்பது ஆரம்பக் கற்றல் தேவைகளை இனங்கண்டு உடனடி ஆதரவை வழங்கும் தளமாகும்.',
      about_who_title: 'யாருக்கானது?',
      about_why_title: 'ஏன் இந்தியா?',
      about_why_desc: 'இந்தியாவின் பன்மொழி சூழலில் அனைத்து குழந்தைகளுக்கும் சமமான கற்றல் வாய்ப்பை வழங்க உருவாக்கப்பட்டது.',
      guardrail_title: 'நெறிமுறை மற்றும் மருத்துவமற்ற உறுதிமொழி',
      guardrail_desc: 'LearnEase ஒரு கல்விசார் திரையிடல் கருவி மட்டுமே. இது மருத்துவ நோயறிதலை வழங்காது.',
      onboarding_title: 'சுயவிவர கட்டமைப்பு',
      onboarding_subtitle: 'தனிப்பயனாக்கப்பட்ட திரையிடலைத் தொடங்க குழந்தையின் விவரங்களை உள்ளிடவும்.',
      field_child_name: 'குழந்தையின் பெயர்',
      field_age: 'வயது',
      field_grade: 'வகுப்பு',
      field_language: 'விருப்ப மொழி',
      field_role: 'உங்கள் பங்கு',
      role_parent: 'பெற்றோர்',
      role_teacher: 'ஆசிரியர் / கல்வியாளர்',
      consent_statement: 'LearnEase ஒரு கல்விசார் ஆதரவுக் கருவி மட்டுமே, மருத்துவக் கண்டறிதல் அல்ல என்பதை நான் புரிந்துகொள்கிறேன்.',
      cancel_btn: 'ரத்து செய்',
      continue_screening: 'தொடரவும்',
      footer_navigation: 'தளம்',
      footer_languages: 'மொழிகள்',
      footer_disclaimer_title: 'அறிவிப்பு',
      tagline_main: 'ஒவ்வொரு குழந்தையும் மாறுபட்டு கற்கிறது.',
      tagline_sub: 'ஆரம்பத்தில் அறிவோம். சிறப்பாக கற்போம். நம்பிக்கையோடு வளர்வோம்.'
    },

    hi: {
      disclaimer_short: 'LearnEase एक शैक्षिक स्क्रीनिंग और शिक्षण-सहायता उपकरण है। यह कोई चिकित्सीय निदान प्रदान नहीं करता है।',
      nav_home: 'होम',
      nav_screening: 'स्क्रीनिंग',
      nav_learn: 'सीखें',
      nav_progress: 'प्रगति',
      nav_specialists: 'विशेषज्ञ',
      nav_teacher: 'शिक्षक पोर्टल',
      nav_about: 'हमारे बारे में',
      start_screening_btn: 'स्क्रीनिंग शुरू करें',
      start_screening_arrow: 'स्क्रीनिंग शुरू करें',
      explore_learning: 'सीखना शुरू करें',
      hero_badge: 'प्रारंभिक शैक्षिक स्क्रीनिंग एवं शिक्षण सहायता',
      hero_subtitle: 'LearnEase सीखने की जरूरतों को जल्दी पहचानने में मदद करता है और उन्हें संरचित गतिविधियों, बहुभाषी पहुंच और अभिभावक अंतर्दृष्टि के साथ व्यक्तिगत सहायता में बदलता है।',
      trust_child_friendly: 'प्रारंभिक स्क्रीनिंग',
      trust_multilingual: 'बहुभाषी सहायता',
      trust_privacy: 'गोपनीयता-प्रथम एवं गैर-चिकित्सीय',
      trust_pillars_badge: 'मुख्य संरचना',
      trust_pillars_title: 'हर बच्चे की सीखने की यात्रा को सशक्त बनाना',
      trust_pillars_desc: 'प्रारंभिक बचपन की शिक्षा और सहयोगी देखभाल के लिए डिज़ाइन किए गए चार स्तंभ।',
      card_screening_title: 'प्रारंभिक स्क्रीनिंग',
      card_screening_desc: 'उन कौशलों की पहचान करें जहाँ अतिरिक्त अभ्यास की आवश्यकता हो सकती है।',
      card_personalized_title: 'व्यक्तिगत शिक्षण',
      card_personalized_desc: 'प्रत्येक बच्चे के प्रदर्शन के आधार पर उपयुक्त शैक्षिक अभ्यास तैयार करें।',
      card_multilingual_title: 'बहुभाषी सहायता',
      card_multilingual_desc: 'हिंदी, तमिल और अंग्रेजी के साथ भारत के भाषाई परिवेश के लिए निर्मित।',
      card_insights_title: 'अभिभावक एवं शिक्षक अंतर्दृष्टि',
      card_insights_desc: 'सीखने की प्रगति को ट्रैक करें और बिना किसी चिकित्सीय शब्दावली के व्यावहारिक सुझाव प्राप्त करें।',
      impact_badge: 'LearnEase मॉडल',
      impact_title: 'पहचान से सहायता तक',
      impact_desc: 'सीखने की शुरुआती चिंता और दैनिक अभ्यास के बीच की दूरी को पाटना।',
      impact_step1_title: 'पहचानें',
      impact_step1_desc: 'ध्वन्यात्मक जागरूकता, स्मृति और अनुक्रमण जैसे मुख्य संज्ञानात्मक क्षेत्रों में संरचित स्क्रीनिंग।',
      impact_step1_tag: 'तनावमुक्त गतिविधि',
      impact_step2_title: 'समझें',
      impact_step2_desc: 'बिना किसी चिकित्सीय लेबल के बच्चे की सीखने की ताकत को सकारात्मक रूप से समझें।',
      impact_step2_tag: 'स्पष्ट विश्लेषण',
      impact_step3_title: 'सहायता करें',
      impact_step3_desc: 'कमजोर क्षेत्रों को मजबूत करने के लिए लक्षित अभ्यास और नियमित प्रगति ट्रैकिंग।',
      impact_step3_tag: 'लक्षित अभ्यास',
      flow_badge: 'प्रक्रिया ढांचा',
      flow_title: 'LearnEase कैसे काम करता है',
      flow_desc: 'प्रोफाइल बनाने से लेकर वास्तविक प्रगति तक एक सहज और बाल-केंद्रित यात्रा।',
      step_profile: 'प्रोफाइल',
      step_screening: 'स्क्रीनिंग',
      step_analysis: 'कौशल विश्लेषण',
      step_activities: 'सुझाई गई गतिविधियाँ',
      step_progress: 'प्रगति',
      step_insights: 'मार्गदर्शन',
      compare_badge: 'सकारात्मक बदलाव',
      compare_title: 'स्क्रीनिंग से सहायता तक',
      compare_subtitle: 'प्रारंभिक, सुलभ और डिजिटल स्क्रीनिंग बच्चों के सीखने के परिणामों को बदल देती है।',
      compare_traditional_tag: 'पारंपरिक दृष्टिकोण',
      compare_traditional_title: 'अक्सर विलंबित और तनावपूर्ण',
      compare_learnease_tag: 'LearnEase प्लेटफॉर्म',
      compare_learnease_title: 'त्वरित, उपयोगी और व्यावहारिक',
      multi_badge: 'भाषाई समावेशन',
      multi_title: 'शिक्षा बच्चे की अपनी भाषा में होनी चाहिए।',
      multi_desc: 'भारत में बच्चे बहुभाषी वातावरण में बड़े होते हैं। LearnEase अंग्रेजी, तमिल और हिंदी में तत्काल सहायता प्रदान करता है।',
      privacy_title: 'बाल-प्रथम गोपनीयता और सुरक्षा',
      privacy_desc: 'सभी जानकारी केवल आपके डिवाइस पर स्थानीय रूप से संग्रहीत की जाती है। कोई भी व्यक्तिगत डेटा बाहरी सर्वर पर नहीं भेजा जाता।',
      cta_banner_title: 'अपने बच्चे की सीखने की ताकत को जानने के लिए तैयार हैं?',
      cta_banner_text: 'केवल 8 से 10 मिनट लगते हैं। बच्चों के लिए एक आरामदायक अनुभव।',
      listen_audio: 'सुनें',
      memory_instruction: 'इस क्रम को याद रखें:',
      memory_memorize: 'गायब होने से पहले याद कर लें...',
      analyzing_title: 'डेटा का विश्लेषण किया जा रहा है...',
      analyzing_desc: 'हमारा शैक्षिक इंजन व्यक्तिगत सिफारिशें तैयार करने के लिए प्रतिक्रियाओं का मूल्यांकन कर रहा है।',
      results_badge: 'मूल्यांकन पूर्ण',
      snapshot_title: 'सीखने का स्नैपशॉट',
      snapshot_subtitle: 'बच्चे की सीखने की ताकत और अभ्यास क्षेत्रों का स्पष्ट विवरण।',
      overall_screening_score: 'समग्र स्क्रीनिंग स्कोर',
      skill_breakdown_title: 'बुनियादी कौशल विश्लेषण',
      skill_breakdown_desc: 'मूल्यांकन किए गए मुख्य संज्ञानात्मक और साक्षरता कौशलों का विस्तृत विवरण।',
      strengths_title: 'कौशल की ताकत',
      strengths_note: 'इन बुनियादी कौशलों की सराहना करें और इन्हें प्रोत्साहित करते रहें।',
      support_title: 'अभ्यास के क्षेत्र',
      support_note: 'नियमित अभ्यास से इन क्षेत्रों में आसानी से सुधार किया जा सकता है।',
      rec_badge: 'व्यक्तिगत शिक्षण मार्ग',
      rec_title: 'अनुशंसित शिक्षण पथ',
      rec_subtitle: 'स्क्रीनिंग विश्लेषण के आधार पर विशेष रूप से चुनी गई गतिविधियाँ।',
      view_full_progress: 'पूरी प्रगति देखें',
      start_first_game: 'सुझाई गई गतिविधि शुरू करें',
      restart_screening: 'नई स्क्रीनिंग शुरू करें',
      disclaimer_full: 'LearnEase एक शैक्षिक स्क्रीनिंग और शिक्षण-सहायता उपकरण है। यह कोई चिकित्सीय निदान प्रदान नहीं करता है। यदि चिंता बनी रहती है, तो किसी योग्य पेशेवर से परामर्श लें।',
      learn_badge: 'लक्षित अभ्यास',
      learn_title: 'व्यक्तिगत शिक्षण',
      learn_subtitle: 'ध्वनि पहचान, स्मृति और अनुक्रमण कौशल को मजबूत करने वाले अभ्यास।',
      diff_easy: 'आसान',
      diff_med: 'मध्यम',
      play_now: 'शुरू करें →',
      game1_title: 'ध्वनि मिलान (Sound Match)',
      game1_desc: 'शुरुआती ध्वनियों और अक्षरों को पहचानने का अभ्यास।',
      game2_title: 'स्मृति मिलान (Memory Match)',
      game2_desc: 'अनुक्रमों को याद रखकर कार्यशील स्मृति को मजबूत बनाएं।',
      game3_title: 'अनुक्रम चुनौती (Sequence Challenge)',
      game3_desc: 'पैटर्न और संख्याओं को सही क्रम में व्यवस्थित करें।',
      game4_title: 'अक्षर खोज',
      game4_desc: 'मिलते-जुलते अक्षरों को पहचानें और अंतर समझें।',
      game5_title: 'शब्द निर्माण',
      game5_desc: 'ध्वनि खंडों को जोड़कर सरल शब्द बनाएं।',
      game6_title: 'तुकबंदी अभ्यास',
      game6_desc: 'समान ध्वनि वाले शब्दों का मिलान करें।',
      play_again: 'फिर से करें',
      try_another: 'अगली गतिविधि आजमाएं →',
      progress_badge: 'विश्लेषण डैशबोर्ड',
      progress_title: 'सीखने की प्रगति',
      progress_subtitle: 'कौशल विकास, गतिविधि पूर्णता और आगामी सहायता की निगरानी करें।',
      load_demo_data: 'डेमो डेटा लोड करें',
      reset_data: 'डेटा रीसेट करें',
      edit_profile: 'प्रोफाइल बदलें',
      empty_title: 'आपकी सीखने की यात्रा यहाँ से शुरू होती है',
      empty_desc: 'व्यक्तिगत प्रगति देखने के लिए अपनी पहली स्क्रीनिंग पूरी करें।',
      start_first_screening: 'स्क्रीनिंग शुरू करें →',
      stat_latest_score: 'नवीनतम स्क्रीनिंग',
      stat_completed: 'पूर्ण गतिविधियाँ',
      stat_streak: 'सक्रिय दिन',
      stat_skills: 'अभ्यास किए गए कौशल',
      dash_skill_progress: 'कौशल प्रदर्शन',
      dash_skill_subtitle: 'हाल के सत्रों के आधार पर सीखने की क्षमता का विकास।',
      dash_weekly_title: 'साप्ताहिक गतिविधि प्रगति',
      dash_weekly_subtitle: 'इस सप्ताह में पूरी की गई दैनिक शिक्षण गतिविधियाँ।',
      dash_history_title: 'गतिविधि इतिहास',
      dash_history_subtitle: 'स्क्रीनिंग और अभ्यासों का कालानुक्रमिक रिकॉर्ड।',
      col_date: 'तारीख',
      col_activity: 'गतिविधि',
      col_category: 'श्रेणी',
      col_score: 'स्कोर',
      col_status: 'स्थिति',
      next_steps_title: 'सीखने के सुझाव',
      next_steps_subtitle: 'घर और कक्षा में सीखने के लिए व्यावहारिक और सरल सुझाव।',
      tip1_title: 'प्रतिदिन 10 मिनट ध्वन्यात्मक अभ्यास करें',
      tip1_desc: 'ध्वनि मिलान जैसे छोटे अभ्यास बच्चे की समझ को बिना थकान के मजबूत करते हैं।',
      tip2_title: 'साथ मिलकर स्मृति अभ्यास करें',
      tip2_desc: 'रोजमर्रा की जिंदगी में 3-4 वस्तुओं या संख्याओं को याद रखने का अभ्यास करें।',
      tip3_title: '15 मिनट साथ मिलकर पढ़ें',
      tip3_desc: 'साथ पढ़ने से बच्चे का पढ़ने का डर कम होता है और शब्दावली बढ़ती है।',
      tip4_title: '4 से 6 सप्ताह में दोबारा स्क्रीनिंग करें',
      tip4_desc: 'नियमित अभ्यास के बाद बच्चे की प्रगति को आसानी से देखें।',
      tip5_title: 'आवश्यकता पड़ने पर किसी योग्य विशेषज्ञ से मिलें',
      tip5_desc: 'यदि सीखने में गंभीर कठिनाई बनी रहती है, तो विस्तृत मूल्यांकन के लिए विशेष शिक्षक या बाल मनोवैज्ञानिक से परामर्श लें।',
      about_badge: 'LearnEase के बारे में',
      about_title: 'मंच विवरण एवं पद्धतियाँ',
      about_subtitle: 'भारत में प्रारंभिक शिक्षा अंतराल को पाटने के लिए एक सुलभ शैक्षिक स्क्रीनिंग उपकरण।',
      about_what_title: 'LearnEase क्या है?',
      about_what_desc: 'LearnEase एक प्रारंभिक शैक्षिक स्क्रीनिंग और शिक्षण सहायता प्लेटफॉर्म है।',
      about_who_title: 'यह किसके लिए है?',
      about_why_title: 'भारत क्यों?',
      about_why_desc: 'भारत की भाषाई विविधता में हर बच्चे को उसकी अपनी भाषा में सीखने का समान अवसर देने के लिए बनाया गया है।',
      guardrail_title: 'नैतिक दृष्टिकोण एवं गैर-चिकित्सीय वचनबद्धता',
      guardrail_desc: 'LearnEase केवल एक शैक्षिक स्क्रीनिंग उपकरण है। यह कोई चिकित्सीय निदान प्रदान नहीं करता है।',
      onboarding_title: 'प्रोफाइल सेटअप',
      onboarding_subtitle: 'स्क्रीनिंग शुरू करने के लिए बच्चे की प्रोफाइल दर्ज करें।',
      field_child_name: 'बच्चे का नाम',
      field_age: 'उम्र',
      field_grade: 'कक्षा',
      field_language: 'पसंदीदा भाषा',
      field_role: 'आपकी भूमिका',
      role_parent: 'अभिभावक',
      role_teacher: 'शिक्षक / शिक्षिका',
      consent_statement: 'मैं समझता/समझती हूँ कि LearnEase केवल शैक्षिक सहायता प्रदान करता है और यह कोई चिकित्सीय निदान नहीं है।',
      cancel_btn: 'रद्द करें',
      continue_screening: 'जारी रखें',
      footer_navigation: 'मंच',
      footer_languages: 'भाषाएं',
      footer_disclaimer_title: 'सूचना',
      tagline_main: 'हर बच्चा अलग तरह से सीखता है।',
      tagline_sub: 'जल्दी पहचानें। बेहतर सीखें। आत्मविश्वास से बढ़ें।'
    }
  };

  // ==========================================================================
  // 3. SCREENING QUESTIONS BANK (15 Items, Zero Emojis)
  // ==========================================================================
  const questions = [
    // 1. Phonological Awareness
    {
      id: 1,
      category: 'phonological',
      categoryLabel: 'PHONOLOGICAL AWARENESS',
      prompt: {
        en: 'Which word starts with the same sound as CAT?',
        ta: 'எந்த சொல் CAT போல C ஒலியுடன் தொடங்குகிறது?',
        hi: 'कौन सा शब्द CAT की तरह C की पहली ध्वनि से शुरू होता है?'
      },
      speechText: {
        en: 'Which word starts with the same sound as CAT? Cap, Dog, Fish, Tree',
        ta: 'எந்த சொல் CAT போல தொடங்குகிறது? Cap, Dog, Fish, Tree',
        hi: 'कौन सा शब्द CAT की तरह पहली ध्वनि से शुरू होता है? Cap, Dog, Fish, Tree'
      },
      options: [
        { text: 'Cap', correct: true },
        { text: 'Dog', correct: false },
        { text: 'Fish', correct: false },
        { text: 'Tree', correct: false }
      ]
    },

    // 2. Rhyming
    {
      id: 2,
      category: 'rhyming',
      categoryLabel: 'RHYMING',
      prompt: {
        en: 'Which word rhymes with DOG?',
        ta: 'DOG என்ற சொல்லுடன் ஒரே ஓசையில் முடியும் சொல் எது?',
        hi: 'कौन सा शब्द DOG के साथ तुकबंदी करता है?'
      },
      speechText: {
        en: 'Which word rhymes with DOG? Log, Sun, Fish, Tree',
        ta: 'DOG என்ற சொல்லுடன் ரைம் ஆகும் சொல் எது? Log, Sun, Fish, Tree',
        hi: 'कौन सा शब्द DOG के साथ तुक मिलाता है? Log, Sun, Fish, Tree'
      },
      options: [
        { text: 'Log', correct: true },
        { text: 'Sun', correct: false },
        { text: 'Fish', correct: false },
        { text: 'Tree', correct: false }
      ]
    },

    // 3. Letter Recognition
    {
      id: 3,
      category: 'letter_recognition',
      categoryLabel: 'LETTER RECOGNITION',
      prompt: {
        en: 'Which letter comes first in the word SUN?',
        ta: 'SUN என்ற சொல்லில் முதல் எழுத்து எது?',
        hi: 'SUN शब्द में पहला अक्षर कौन सा आता है?'
      },
      speechText: {
        en: 'Which letter comes first in the word SUN? S, U, N, or T',
        ta: 'SUN சொல்லில் முதல் எழுத்து எது? S, U, N, T',
        hi: 'SUN शब्द का पहला अक्षर क्या है? S, U, N, T'
      },
      options: [
        { text: 'S', correct: true },
        { text: 'U', correct: false },
        { text: 'N', correct: false },
        { text: 'T', correct: false }
      ]
    },

    // 4. Sequencing
    {
      id: 4,
      category: 'sequencing',
      categoryLabel: 'SEQUENCING',
      prompt: {
        en: 'What comes next in this order: 1 → 2 → ?',
        ta: 'இந்த வரிசையில் அடுத்து வருவது எது: 1 → 2 → ?',
        hi: 'इस क्रम में आगे क्या आता है: 1 → 2 → ?'
      },
      speechText: {
        en: 'What comes after 1, then 2? 3, 5, 8, or 10',
        ta: '1 மற்றும் 2-க்கு பிறகு என்ன வரும்? 3, 5, 8, 10',
        hi: '1 और 2 के बाद क्या आता है? 3, 5, 8, 10'
      },
      options: [
        { text: '3', correct: true },
        { text: '5', correct: false },
        { text: '8', correct: false },
        { text: '10', correct: false }
      ]
    },

    // 5. Working Memory
    {
      id: 5,
      category: 'memory',
      categoryLabel: 'WORKING MEMORY',
      isMemoryPreview: true,
      memoryItems: 'B - 4 - K',
      prompt: {
        en: 'Which sequence did you just see?',
        ta: 'இப்போது நீங்கள் பார்த்த வரிசை எது?',
        hi: 'आपने अभी कौन सा क्रम देखा था?'
      },
      speechText: {
        en: 'Which sequence did you see? B-4-K, K-B-4, 4-K-B, or B-K-4',
        ta: 'நீங்கள் பார்த்த வரிசை எது? B-4-K, K-B-4, 4-K-B, B-K-4',
        hi: 'आपने कौन सा क्रम देखा? B-4-K, K-B-4, 4-K-B, B-K-4'
      },
      options: [
        { text: 'B - 4 - K', correct: true },
        { text: 'K - B - 4', correct: false },
        { text: '4 - K - B', correct: false },
        { text: 'B - K - 4', correct: false }
      ]
    },

    // 6. Reading Patterns
    {
      id: 6,
      category: 'reading',
      categoryLabel: 'READING PATTERNS',
      prompt: {
        en: 'Look at the pattern: C-A-T, B-A-T. Which word fits the pattern?',
        ta: 'C-A-T, B-A-T என்ற அமைப்பைப் பாருங்கள். அடுத்த சொல் எது?',
        hi: 'पैटर्न देखें: C-A-T, B-A-T. अगला शब्द कौन सा फिट बैठता है?'
      },
      speechText: {
        en: 'Look at the pattern: CAT, BAT. Which word fits? MAT, DOG, CUP, SUN',
        ta: 'CAT, BAT அமைப்பில் பொருந்தும் சொல் எது? MAT, DOG, CUP, SUN',
        hi: 'CAT, BAT पैटर्न में कौन सा शब्द सही है? MAT, DOG, CUP, SUN'
      },
      options: [
        { text: 'MAT', correct: true },
        { text: 'DOG', correct: false },
        { text: 'CUP', correct: false },
        { text: 'SUN', correct: false }
      ]
    },

    // 7. Rapid Naming
    {
      id: 7,
      category: 'rapid_naming',
      categoryLabel: 'RAPID NAMING',
      prompt: {
        en: 'Quickly find and select the STAR shape:',
        ta: 'விரைவாக STAR வடிவத்தைத் தேர்ந்தெடுக்கவும்:',
        hi: 'जल्दी से STAR का आकार चुनें:'
      },
      speechText: {
        en: 'Quickly select the star shape.',
        ta: 'STAR வடிவத்தைத் தேர்ந்தெடுக்கவும்.',
        hi: 'STAR के आकार का चयन करें।'
      },
      options: [
        { text: 'Star', correct: true },
        { text: 'Circle', correct: false },
        { text: 'Triangle', correct: false },
        { text: 'Square', correct: false }
      ]
    },

    // 8. Phonological Awareness
    {
      id: 8,
      category: 'phonological',
      categoryLabel: 'PHONOLOGICAL AWARENESS',
      prompt: {
        en: 'Which word starts with the "M" sound like MOON?',
        ta: 'MOON போல M ஒலியுடன் தொடங்கும் சொல் எது?',
        hi: 'MOON की तरह M ध्वनि से शुरू होने वाला शब्द कौन सा है?'
      },
      speechText: {
        en: 'Which word starts with the M sound like MOON? Milk, Pen, Star, Apple',
        ta: 'MOON போல M ஒலியுடன் தொடங்கும் சொல் எது? Milk, Pen, Star, Apple',
        hi: 'MOON की तरह M से शुरू होने वाला शब्द? Milk, Pen, Star, Apple'
      },
      options: [
        { text: 'Milk', correct: true },
        { text: 'Pen', correct: false },
        { text: 'Star', correct: false },
        { text: 'Apple', correct: false }
      ]
    },

    // 9. Rhyming
    {
      id: 9,
      category: 'rhyming',
      categoryLabel: 'RHYMING',
      prompt: {
        en: 'Which word rhymes with STAR?',
        ta: 'STAR என்ற சொல்லுடன் ஒரே ஓசையில் முடியும் சொல் எது?',
        hi: 'कौन सा शब्द STAR के साथ तुक मिलाता है?'
      },
      speechText: {
        en: 'Which word rhymes with STAR? Car, Book, Moon, Bird',
        ta: 'STAR சொல்லுடன் ரைம் ஆகும் சொல் எது? Car, Book, Moon, Bird',
        hi: 'STAR के साथ तुकबंदी वाला शब्द कौन सा है? Car, Book, Moon, Bird'
      },
      options: [
        { text: 'Car', correct: true },
        { text: 'Book', correct: false },
        { text: 'Moon', correct: false },
        { text: 'Bird', correct: false }
      ]
    },

    // 10. Letter Recognition
    {
      id: 10,
      category: 'letter_recognition',
      categoryLabel: 'LETTER RECOGNITION',
      prompt: {
        en: 'Which letter looks like the mirror reflection of "b"?',
        ta: 'b என்ற எழுத்தின் கண்ணாடி பிம்பம் போல இருக்கும் எழுத்து எது?',
        hi: 'b अक्षर के उल्टे दर्पण प्रतिबिंब जैसा कौन सा अक्षर दिखता है?'
      },
      speechText: {
        en: 'Which letter looks like the mirror reflection of b? d, p, m, or t',
        ta: 'b எழுத்தின் கண்ணாடி பிம்பம் எது? d, p, m, t',
        hi: 'b के उल्टे दर्पण जैसा कौन सा अक्षर है? d, p, m, t'
      },
      options: [
        { text: 'd', correct: true },
        { text: 'p', correct: false },
        { text: 'm', correct: false },
        { text: 't', correct: false }
      ]
    },

    // 11. Sequencing
    {
      id: 11,
      category: 'sequencing',
      categoryLabel: 'SEQUENCING',
      prompt: {
        en: 'What day comes next: Monday → Tuesday → ?',
        ta: 'அடுத்து வரும் நாள் எது: திங்கள் → செவ்வாய் → ?',
        hi: 'अगला दिन कौन सा आता है: सोमवार → मंगलवार → ?'
      },
      speechText: {
        en: 'What comes after Monday, then Tuesday? Wednesday, Friday, Sunday, or Saturday',
        ta: 'திங்கள், செவ்வாய்க்குப் பிறகு என்ன வரும்? புதன் Wednesday',
        hi: 'सोमवार, मंगलवार के बाद क्या आता है? बुधवार Wednesday'
      },
      options: [
        { text: 'Wednesday', correct: true },
        { text: 'Friday', correct: false },
        { text: 'Sunday', correct: false },
        { text: 'Saturday', correct: false }
      ]
    },

    // 12. Working Memory
    {
      id: 12,
      category: 'memory',
      categoryLabel: 'WORKING MEMORY',
      isMemoryPreview: true,
      memoryItems: '7 - R - 2',
      prompt: {
        en: 'Which sequence did you just see?',
        ta: 'இப்போது நீங்கள் பார்த்த வரிசை எது?',
        hi: 'आपने अभी कौन सा क्रम देखा?'
      },
      speechText: {
        en: 'Which sequence did you see? 7-R-2, 2-R-7, R-7-2, or 7-2-R',
        ta: 'நீங்கள் பார்த்த வரிசை எது? 7-R-2',
        hi: 'आपने कौन सा क्रम देखा? 7-R-2'
      },
      options: [
        { text: '7 - R - 2', correct: true },
        { text: '2 - R - 7', correct: false },
        { text: 'R - 7 - 2', correct: false },
        { text: '7 - 2 - R', correct: false }
      ]
    },

    // 13. Reading Patterns
    {
      id: 13,
      category: 'reading',
      categoryLabel: 'READING PATTERNS',
      prompt: {
        en: 'Which word is spelled correctly for "PLAY"?',
        ta: 'PLAY என்ற சொல்லின் சரியான எழுத்துக்கூட்டு எது?',
        hi: 'PLAY की सही वर्तनी कौन सी है?'
      },
      speechText: {
        en: 'Which word is spelled correctly? P-L-A-Y, P-A-L-Y, L-P-A-Y, or P-L-Y-A',
        ta: 'சரியான சொல் எது? PLAY',
        hi: 'सही शब्द कौन सा है? PLAY'
      },
      options: [
        { text: 'PLAY', correct: true },
        { text: 'PALY', correct: false },
        { text: 'LPAY', correct: false },
        { text: 'PLYA', correct: false }
      ]
    },

    // 14. Rapid Naming
    {
      id: 14,
      category: 'rapid_naming',
      categoryLabel: 'RAPID NAMING',
      prompt: {
        en: 'Quickly find the word APPLE among these items:',
        ta: 'இவற்றில் APPLE சொல்லினை விரைவாகக் கண்டறியவும்:',
        hi: 'इनमें से APPLE को जल्दी से चुनें:'
      },
      speechText: {
        en: 'Quickly select Apple.',
        ta: 'Apple சொல்லினைத் தேர்ந்தெடுக்கவும்.',
        hi: 'Apple का चयन करें।'
      },
      options: [
        { text: 'Apple', correct: true },
        { text: 'Banana', correct: false },
        { text: 'Grapes', correct: false },
        { text: 'Orange', correct: false }
      ]
    },

    // 15. Phonological Awareness
    {
      id: 15,
      category: 'phonological',
      categoryLabel: 'PHONOLOGICAL AWARENESS',
      prompt: {
        en: 'Which word ends with the "L" sound like BELL?',
        ta: 'BELL போல இறுதியில் L ஒலியுடன் முடியும் சொல் எது?',
        hi: 'BELL की तरह अंत में L ध्वनि पर समाप्त होने वाला शब्द कौन सा है?'
      },
      speechText: {
        en: 'Which word ends with the L sound like BELL? Ball, Cup, Hat, Sun',
        ta: 'BELL போல L ஒலியுடன் முடியும் சொல் எது? Ball, Cup, Hat, Sun',
        hi: 'BELL की तरह अंत में L ध्वनि वाला शब्द? Ball, Cup, Hat, Sun'
      },
      options: [
        { text: 'Ball', correct: true },
        { text: 'Cup', correct: false },
        { text: 'Hat', correct: false },
        { text: 'Sun', correct: false }
      ]
    }
  ];

  const SCREENING_QUESTIONS = questions;

  // ==========================================================================
  // 4. STATE & STORAGE HELPERS
  // ==========================================================================
  let currentLanguage = localStorage.getItem(STORAGE_KEYS.LANGUAGE) || 'en';
  let activeView = 'home';
  let currentQuestion = 0;
  let screeningAnswers = [];
  let adaptiveDifficulty = 'medium'; // 'easy' | 'medium' | 'hard'
  let gameDifficulty = 'medium';
  let questionStartTime = 0;
  let memoryCountdownInterval = null;

  function getProfile() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  function saveProfile(profile) {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
      if (profile && profile.name && profile.age) {
        syncWithBackend('children', {
          name: profile.name,
          age: Number(profile.age) || 7,
          grade: profile.grade || 'Grade 1',
          language: profile.language || 'en'
        });
      }
    } catch (e) {
      console.warn('LocalStorage error saving profile:', e);
    }
  }

  function getScreening() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SCREENING);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  function saveScreening(screeningData) {
    try {
      localStorage.setItem(STORAGE_KEYS.SCREENING, JSON.stringify(screeningData));
    } catch (e) {
      console.warn('LocalStorage error saving screening:', e);
    }
  }

  function getProgress() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROGRESS);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  function saveProgress(progressData) {
    try {
      localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progressData));
    } catch (e) {
      console.warn('LocalStorage error saving progress:', e);
    }
  }

  function getChildProfile() {
    return getProfile() || { name: 'Aarav Patel', age: 8, grade: 'Class 3', language: 'en' };
  }

  function getScreeningResult() {
    return getScreening() || { 
      score: 78, 
      level: 'Some Practice Recommended', 
      strengths: ['Phonological Awareness'], 
      supportAreas: ['Working Memory', 'Sequencing'], 
      recommendations: ['Memory Match', 'Sequence Challenge'] 
    };
  }

  function getProgressData() {
    return getProgress() || { totalActivities: 24, dayStreak: 7, history: [] };
  }

  function saveProgressData(data) {
    saveProgress(data);
  }

  // Toast Helper (Zero Emojis)
  function showToast(message) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>✓</span> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.25s ease';
      setTimeout(() => toast.remove(), 250);
    }, 3000);
  }

  // ==========================================================================
  // 5. VIEW ROUTER
  // ==========================================================================
  function switchView(viewName) {
    if (viewName === 'all') viewName = 'learn';
    if (viewName === 'specialist') viewName = 'specialists';
    activeView = viewName;
    const views = document.querySelectorAll('.view-section');
    views.forEach(v => v.classList.remove('active'));

    const target = document.getElementById(`view-${viewName}`);
    if (target) {
      target.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      const navTarget = link.dataset.nav;
      const isMatch = (navTarget === viewName) ||
                      (viewName === 'learn' && navTarget === 'all') ||
                      (viewName === 'specialists' && navTarget === 'specialist');
      if (isMatch) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    const mainNav = document.getElementById('main-nav');
    if (mainNav) mainNav.classList.remove('mobile-active');

    if (viewName === 'progress') {
      renderProgressDashboard();
      if (typeof renderSupportTeamAndTimeline === 'function') renderSupportTeamAndTimeline();
    } else if (viewName === 'results') {
      renderResultsFromStorage();
      if (typeof renderResultsAIInsightAndSpecialist === 'function') renderResultsAIInsightAndSpecialist();
    } else if (viewName === 'specialists') {
      if (typeof renderSpecialistsDirectory === 'function') renderSpecialistsDirectory();
    } else if (viewName === 'virtual-room') {
      if (typeof initVirtualRoom === 'function') initVirtualRoom();
    } else if (viewName === 'teacher') {
      if (typeof renderTeacherDashboard === 'function') renderTeacherDashboard();
    } else if (viewName === 'auth') {
      if (typeof renderAuthView === 'function') renderAuthView();
    } else if (viewName === 'profile') {
      if (typeof renderProfileView === 'function') renderProfileView();
    } else if (viewName === 'daily-plan') {
      if (typeof renderDailyPlanView === 'function') renderDailyPlanView();
    } else if (viewName === 'weekly-check') {
      if (typeof renderWeeklyCheckView === 'function') renderWeeklyCheckView();
    } else if (viewName === 'parent') {
      if (typeof renderParentDashboard === 'function') renderParentDashboard();
    } else if (viewName === 'admin') {
      if (typeof renderAdminPanel === 'function') renderAdminPanel();
    } else if (viewName === 'portal') {
      if (typeof renderPortalView === 'function') renderPortalView();
    } else if (viewName === 'learn') {
      if (typeof initActivitiesToolbar === 'function') initActivitiesToolbar();
    } else if (viewName === 'screening') {
      if (typeof renderCurrentQuestion === 'function') renderCurrentQuestion();
    }
  }

  window.addEventListener('hashchange', () => {
    const hash = window.location.hash.replace('#', '') || 'home';
    const allowedViews = ['home','screening','results','learn','all','progress','about','specialist','specialists','virtual-room','teacher','auth','profile','daily-plan','weekly-check','parent','admin','portal'];
    if (allowedViews.includes(hash)) {
      switchView(hash);
    }
  });

  // ==========================================================================
  // 6. MULTILINGUAL & SPEECH SYNTHESIS ENGINE
  // ==========================================================================
  function setLanguage(langCode) {
    if (!translations[langCode]) langCode = 'en';
    currentLanguage = langCode;
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, langCode);

    const langSelect = document.getElementById('language-select');
    if (langSelect) langSelect.value = langCode;

    applyTranslations();

    if (activeView === 'screening') {
      renderCurrentQuestion();
    }
  }

  function applyTranslations() {
    const dict = translations[currentLanguage] || translations.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });
  }

  function speakText(text) {
    try {
      if (!('speechSynthesis' in window)) {
        showToast('Speech synthesis not supported in this browser.');
        return;
      }
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.88;
      utterance.pitch = 1.0;

      if (currentLanguage === 'ta') {
        utterance.lang = 'ta-IN';
      } else if (currentLanguage === 'hi') {
        utterance.lang = 'hi-IN';
      } else {
        utterance.lang = 'en-IN';
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis unavailable:', err);
    }
  }

  // ==========================================================================
  // 7. ONBOARDING MODAL CONTROLLER
  // ==========================================================================
  function openOnboardingModal() {
    const modal = document.getElementById('onboarding-modal');
    if (!modal) return;
    modal.classList.remove('hidden');

    const profile = getProfile();
    if (profile) {
      document.getElementById('child-name-input').value = profile.name || '';
      document.getElementById('child-age-input').value = profile.age || '8';
      document.getElementById('child-grade-input').value = profile.grade || 'Grade 3';
      document.getElementById('onboarding-lang-input').value = profile.language || currentLanguage;
      const roleRadios = document.getElementsByName('userRole');
      roleRadios.forEach(r => {
        if (r.value === profile.role) r.checked = true;
      });
      document.getElementById('consent-checkbox').checked = true;
    } else {
      document.getElementById('onboarding-lang-input').value = currentLanguage;
    }
  }

  function closeOnboardingModal() {
    const modal = document.getElementById('onboarding-modal');
    if (modal) modal.classList.add('hidden');
  }

  function handleOnboardingSubmit(e) {
    e.preventDefault();
    const nameInput = document.getElementById('child-name-input');
    const ageInput = document.getElementById('child-age-input');
    const gradeInput = document.getElementById('child-grade-input');
    const langInput = document.getElementById('onboarding-lang-input');
    const consentCheck = document.getElementById('consent-checkbox');
    const nameError = document.getElementById('name-error');
    const consentError = document.getElementById('consent-error');

    let isValid = true;

    if (!nameInput.value.trim()) {
      nameError.classList.remove('hidden');
      nameInput.focus();
      isValid = false;
    } else {
      nameError.classList.add('hidden');
    }

    if (!consentCheck.checked) {
      consentError.classList.remove('hidden');
      isValid = false;
    } else {
      consentError.classList.add('hidden');
    }

    if (!isValid) return;

    let selectedRole = 'Parent';
    document.getElementsByName('userRole').forEach(r => {
      if (r.checked) selectedRole = r.value;
    });

    const newProfile = {
      name: nameInput.value.trim(),
      age: ageInput.value,
      grade: gradeInput.value,
      language: langInput.value,
      role: selectedRole,
      createdAt: new Date().toISOString()
    };

    saveProfile(newProfile);
    if (langInput.value !== currentLanguage) {
      setLanguage(langInput.value);
    }

    closeOnboardingModal();
    startScreening();
  }

  // ==========================================================================
  // 8. SCREENING ENGINE CONTROLLER
  // ==========================================================================
  function handleRetakeScreening() {
    if (memoryCountdownInterval) {
      clearInterval(memoryCountdownInterval);
      memoryCountdownInterval = null;
    }
    currentQuestion = 0;
    screeningAnswers = [];
    questionStartTime = 0;

    // Reset results DOM elements
    const scoreNum = document.getElementById("results-score-num");
    if (scoreNum) scoreNum.textContent = "0%";
    const skillContainer = document.getElementById("results-skill-bars-container");
    if (skillContainer) skillContainer.innerHTML = "";
    const strengthsList = document.getElementById("results-strengths-list");
    if (strengthsList) strengthsList.innerHTML = "";
    const supportList = document.getElementById("results-support-list");
    if (supportList) supportList.innerHTML = "";
    const recGrid = document.getElementById("results-recommendations-grid");
    if (recGrid) recGrid.innerHTML = "";

    openOnboardingModal();
  }

  function startScreening() {
    if (memoryCountdownInterval) {
      clearInterval(memoryCountdownInterval);
      memoryCountdownInterval = null;
    }
    currentQuestion = 0;
    screeningAnswers = [];
    adaptiveDifficulty = 'medium';
    questionStartTime = performance.now();

    // Reset results UI elements if previously loaded
    const scoreNum = document.getElementById("results-score-num");
    if (scoreNum) scoreNum.textContent = "0%";
    const skillContainer = document.getElementById("results-skill-bars-container");
    if (skillContainer) skillContainer.innerHTML = "";
    const strengthsList = document.getElementById("results-strengths-list");
    if (strengthsList) strengthsList.innerHTML = "";
    const supportList = document.getElementById("results-support-list");
    if (supportList) supportList.innerHTML = "";
    const recGrid = document.getElementById("results-recommendations-grid");
    if (recGrid) recGrid.innerHTML = "";

    window.location.hash = "#screening";
    switchView("screening");
    renderCurrentQuestion();
  }

  function renderCurrentQuestion() {
    if (memoryCountdownInterval) {
      clearInterval(memoryCountdownInterval);
      memoryCountdownInterval = null;
    }

    if (currentQuestion >= questions.length) {
      sendScreeningResults();
      return;
    }

    const q = questions[currentQuestion];
    questionStartTime = performance.now();

    const catLabel = document.getElementById("q-category-label");
    if (catLabel) catLabel.textContent = q.categoryLabel || "Foundational Skill";

    const qNumStr = String(currentQuestion + 1).padStart(2, "0");
    const totalStr = String(questions.length).padStart(2, "0");
    const counterEl = document.getElementById("q-counter-text");
    if (counterEl) counterEl.textContent = `Question ${qNumStr} / ${totalStr}`;

    const pct = Math.round(((currentQuestion + 1) / questions.length) * 100);
    const fillEl = document.getElementById("screening-progress-fill");
    if (fillEl) fillEl.style.width = `${pct}%`;
    const barEl = document.getElementById("screening-progress-bar");
    if (barEl) barEl.setAttribute("aria-valuenow", pct);

    const localizedPrompt = (q.prompt && q.prompt[currentLanguage]) || (q.prompt && q.prompt.en) || "";
    const promptEl = document.getElementById("question-prompt");
    if (promptEl) promptEl.textContent = localizedPrompt;

    const memBox = document.getElementById("memory-preview-box");
    const optionsGrid = document.getElementById("options-grid");
    if (optionsGrid) optionsGrid.innerHTML = "";

    if (q.isMemoryPreview && memBox) {
      memBox.classList.remove("hidden");
      const itemsEl = document.getElementById("memory-items-display");
      if (itemsEl) itemsEl.textContent = q.memoryItems || "";
      if (optionsGrid) optionsGrid.classList.add("hidden");

      let secondsLeft = 3;
      const countEl = document.getElementById("memory-countdown-circle");
      if (countEl) countEl.textContent = secondsLeft;

      memoryCountdownInterval = setInterval(() => {
        secondsLeft -= 1;
        if (secondsLeft > 0) {
          if (countEl) countEl.textContent = secondsLeft;
        } else {
          clearInterval(memoryCountdownInterval);
          memoryCountdownInterval = null;
          if (memBox) memBox.classList.add("hidden");
          if (optionsGrid) {
            optionsGrid.classList.remove("hidden");
            populateOptions(q);
          }
        }
      }, 1000);
    } else {
      if (memBox) memBox.classList.add("hidden");
      if (optionsGrid) {
        optionsGrid.classList.remove("hidden");
        populateOptions(q);
      }
    }

    const speakBtn = document.getElementById("btn-speak-question");
    if (speakBtn) {
      speakBtn.onclick = () => {
        const speechText = (q.speechText && q.speechText[currentLanguage]) || (q.speechText && q.speechText.en) || localizedPrompt;
        speakText(speechText);
      };
    }
  }

  function populateOptions(q) {
    const optionsGrid = document.getElementById("options-grid");
    if (!optionsGrid || !q || !q.options) return;
    optionsGrid.innerHTML = "";
    const letters = ["A", "B", "C", "D"];

    q.options.forEach((opt, idx) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "option-btn";
      btn.setAttribute("role", "radio");
      btn.setAttribute("aria-checked", "false");
      btn.innerHTML = `
        <span class="option-letter">${letters[idx] || ""}</span>
        <span class="option-text">${opt.text}</span>
      `;

      btn.addEventListener("click", () => {
        handleAnswerSelection(btn, opt, q);
      });

      optionsGrid.appendChild(btn);
    });
  }

  function handleAnswerSelection(buttonEl, optionData, questionData) {
    const allBtns = document.querySelectorAll(".option-btn");
    allBtns.forEach(b => b.style.pointerEvents = "none");
    if (buttonEl) buttonEl.classList.add("selected");

    const duration = Math.max(1, Number(((performance.now() - questionStartTime) / 1000).toFixed(1)));

    // Adaptive difficulty calibration
    if (optionData.correct && duration < 4.5) {
      if (adaptiveDifficulty === 'easy') adaptiveDifficulty = 'medium';
      else if (adaptiveDifficulty === 'medium') adaptiveDifficulty = 'hard';
    } else if (!optionData.correct || duration > 7.0) {
      if (adaptiveDifficulty === 'hard') adaptiveDifficulty = 'medium';
      else if (adaptiveDifficulty === 'medium') adaptiveDifficulty = 'easy';
    }

    const adaptBadge = document.getElementById('screening-adaptive-badge');
    if (adaptBadge) {
      adaptBadge.textContent = `Adaptive: ${adaptiveDifficulty.toUpperCase()}`;
    }

    screeningAnswers.push({
      category: questionData.category,
      correct: Boolean(optionData.correct),
      responseTime: duration,
      difficulty: adaptiveDifficulty
    });

    const feedbackBar = document.getElementById("screening-feedback-text");
    const encouragements = [
      "Response recorded. Continuing to next exercise.",
      "Thank you. Pacing is consistent.",
      "Answer noted. Proceeding forward."
    ];
    if (feedbackBar) {
      feedbackBar.textContent = encouragements[currentQuestion % encouragements.length];
    }

    setTimeout(() => {
      currentQuestion += 1;
      renderCurrentQuestion();
    }, 400);
  }

  // ==========================================================================
  // 9. SCREENING SUBMISSION & BACKEND INTEGRATION
  // ==========================================================================
  async function sendScreeningResults() {
    const overlay = document.getElementById("analysis-loading-overlay");
    if (overlay) overlay.classList.remove("hidden");

    const profile = getProfile() || {
      name: "Aarav",
      age: 8,
      grade: "Grade 3",
      language: currentLanguage
    };

    const payload = {
      profile: {
        name: profile.name || "Aarav",
        age: Number(profile.age) || 8,
        grade: profile.grade || "Grade 3",
        language: profile.language || currentLanguage
      },
      answers: screeningAnswers.map(a => ({
        category: a.category,
        correct: Boolean(a.correct),
        responseTime: Number(a.responseTime) || 4.0
      }))
    };

    let resultData = null;

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const result = await response.json();
      if (!result || !result.success) {
        throw new Error((result && result.message) || "Backend returned an unsuccessful result");
      }

      resultData = result;
    } catch (error) {
      console.error("Backend connection failed:", error);
      showToast("Backend unavailable. Calculating evaluation locally.");
      resultData = calculateScreeningLocally(screeningAnswers, profile);
    }

    setTimeout(() => {
      if (overlay) overlay.classList.add("hidden");
      saveScreening(resultData);
      updateProgressWithScreening(resultData);
      window.location.hash = "#results";
      switchView("results");
      displayResults(resultData);
    }, 900);
  }

  const finishScreening = sendScreeningResults;

  function calculateScreeningLocally(answers, profile) {
    const catMap = {
      phonological: "Phonological Awareness",
      rhyming: "Rhyming",
      letterRecognition: "Letter Recognition",
      letter_recognition: "Letter Recognition",
      sequencing: "Sequencing",
      workingMemory: "Working Memory",
      memory: "Working Memory",
      reading: "Reading Patterns",
      rapidNaming: "Rapid Naming",
      rapid_naming: "Rapid Naming"
    };

    const catActivities = {
      phonological: ["Sound Match", "Rhyming Practice"],
      rhyming: ["Rhyming Practice", "Sound Match"],
      letterRecognition: ["Letter Hunt", "Word Builder"],
      letter_recognition: ["Letter Hunt", "Word Builder"],
      sequencing: ["Sequence Challenge", "Word Builder"],
      workingMemory: ["Memory Match", "Sequence Challenge"],
      memory: ["Memory Match", "Sequence Challenge"],
      reading: ["Word Builder", "Letter Hunt"],
      rapidNaming: ["Sound Match", "Letter Hunt"],
      rapid_naming: ["Sound Match", "Letter Hunt"]
    };

    const catStats = {};
    let correctCount = 0;
    let totalTime = 0;

    answers.forEach(a => {
      let cat = a.category;
      if (cat === "letter_recognition") cat = "letterRecognition";
      if (cat === "memory") cat = "workingMemory";
      if (cat === "rapid_naming") cat = "rapidNaming";

      if (!catStats[cat]) catStats[cat] = { correct: 0, total: 0 };
      if (a.correct) {
        catStats[cat].correct += 1;
        correctCount += 1;
      }
      catStats[cat].total += 1;
      totalTime += (a.responseTime || 4.0);
    });

    const categoryScores = {};
    const strengths = [];
    const supportAreas = [];
    const recommendedActivitiesSet = new Set();

    Object.keys(catStats).forEach(c => {
      const s = catStats[c];
      const pct = Math.round((s.correct / s.total) * 100);
      categoryScores[c] = pct;

      const friendly = catMap[c] || c;
      if (pct >= 70) {
        strengths.push(friendly);
      } else {
        supportAreas.push(friendly);
        const acts = catActivities[c] || ["Sound Match", "Memory Match"];
        acts.forEach(x => recommendedActivitiesSet.add(x));
      }
    });

    const overallScore = answers.length > 0 ? Math.round((correctCount / answers.length) * 100) : 75;
    const avgTime = answers.length > 0 ? Number((totalTime / answers.length).toFixed(1)) : 3.8;

    let level = "Some Practice Recommended";
    if (overallScore >= 80) level = "Strong Foundation";
    else if (overallScore < 60) level = "More Support Recommended";

    if (strengths.length === 0) strengths.push("Letter Recognition");
    if (supportAreas.length === 0) supportAreas.push("Working Memory");

    if (recommendedActivitiesSet.size === 0) {
      recommendedActivitiesSet.add("Memory Match");
      recommendedActivitiesSet.add("Sequence Challenge");
    }

    return {
      success: true,
      score: overallScore,
      level,
      categoryScores,
      strengths: strengths.slice(0, 3),
      supportAreas: supportAreas.slice(0, 3),
      recommendations: Array.from(recommendedActivitiesSet).slice(0, 3),
      responseTimeAverage: avgTime,
      totalQuestions: answers.length,
      correctCount,
      profile: profile || null
    };
  }

  // ==========================================================================
  // 10. RESULTS DASHBOARD RENDERING
  // ==========================================================================
  const CATEGORY_DISPLAY_NAMES = {
    phonological: "Phonological Awareness",
    rhyming: "Rhyming",
    letterRecognition: "Letter Recognition",
    letter_recognition: "Letter Recognition",
    sequencing: "Sequencing",
    workingMemory: "Working Memory",
    memory: "Working Memory",
    reading: "Reading Patterns",
    rapidNaming: "Rapid Naming",
    rapid_naming: "Rapid Naming"
  };

  function renderResultsFromStorage() {
    const data = getScreening();
    if (data) {
      displayResults(data);
    } else {
      const demo = generateDemoData();
      displayResults(demo.screening);
    }
  }

  function displayResults(result) {
    if (!result) return;

    // 1. Overall Score
    const scoreNum = document.getElementById("results-score-num");
    const scorePath = document.getElementById("score-svg-path");
    const scoreVal = result.score !== undefined ? result.score : 75;
    if (scoreNum) scoreNum.textContent = `${scoreVal}%`;
    if (scorePath) {
      scorePath.setAttribute("stroke-dasharray", `${scoreVal}, 100`);
      scorePath.style.stroke = "var(--primary-blue)";
    }

    // 2. Support Level Pill & Descriptions
    const levelPill = document.getElementById("results-level-pill");
    const levelHeading = document.getElementById("results-level-heading");
    const levelDesc = document.getElementById("results-level-desc");

    const levelText = result.level || "Some Practice Recommended";
    if (levelPill) levelPill.textContent = levelText;
    if (levelHeading) levelHeading.textContent = levelText;

    if (levelDesc) {
      if (scoreVal >= 80) {
        levelDesc.textContent = "Your child demonstrates strong foundational skills across the evaluated areas. Continuing structured daily activities will maintain this confident learning progress.";
      } else if (scoreVal >= 60) {
        levelDesc.textContent = "Your child has developed key strengths in several areas. Targeted practice in memory and phonics will help reinforce reading confidence.";
      } else {
        levelDesc.textContent = "Screening indicates several learning areas would benefit from structured, multisensory practice. Try our recommended daily exercises and consider consulting an educator if questions persist.";
      }
    }

    // Meta Info
    const avgTimeEl = document.getElementById("results-avg-time");
    if (avgTimeEl) avgTimeEl.textContent = `${result.responseTimeAverage || 3.8}s`;

    const totalItemsEl = document.getElementById("results-total-items");
    if (totalItemsEl) totalItemsEl.textContent = `${result.totalQuestions || 15} questions`;

    const childNameEl = document.getElementById("results-child-name");
    const profile = result.profile || getProfile();
    if (childNameEl) childNameEl.textContent = (profile && profile.name) || "Aarav";

    // 3. Category Skill Bars
    const skillContainer = document.getElementById("results-skill-bars-container");
    if (skillContainer && result.categoryScores) {
      skillContainer.innerHTML = "";
      Object.entries(result.categoryScores).forEach(([catKey, scoreValue]) => {
        const displayName = CATEGORY_DISPLAY_NAMES[catKey] || catKey;
        const card = document.createElement("div");
        card.className = "skill-bar-card";
        card.innerHTML = `
          <div class="skill-bar-header">
            <span class="skill-bar-name">${displayName}</span>
            <span class="skill-bar-pct">${scoreValue}%</span>
          </div>
          <div class="skill-track">
            <div class="skill-fill" style="width: ${scoreValue}%;"></div>
          </div>
        `;
        skillContainer.appendChild(card);
      });
    }

    // 4. Strengths & Practice Areas Lists
    const strengthsList = document.getElementById("results-strengths-list");
    if (strengthsList && result.strengths) {
      strengthsList.innerHTML = "";
      result.strengths.forEach(s => {
        const li = document.createElement("li");
        li.innerHTML = `<span class="badge-tag strength-tag">${s}</span>`;
        strengthsList.appendChild(li);
      });
    }

    const supportList = document.getElementById("results-support-list");
    if (supportList && result.supportAreas) {
      supportList.innerHTML = "";
      result.supportAreas.forEach(s => {
        const li = document.createElement("li");
        li.innerHTML = `<span class="badge-tag support-tag">${s}</span>`;
        supportList.appendChild(li);
      });
    }

    // 5. Dynamic Recommendations with Clean SVG Icons
    const recGrid = document.getElementById("results-recommendations-grid");
    if (recGrid && result.recommendations) {
      recGrid.innerHTML = "";
      const recMeta = {
        "Sound Match": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>',
          desc: "Identify initial sounds and phonetic connections.",
          gameKey: "sound-match"
        },
        "Memory Match": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
          desc: "Recall sequences of items to boost working memory.",
          gameKey: "memory-match"
        },
        "Sequence Challenge": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>',
          desc: "Arrange patterns and numbers in structured order.",
          gameKey: "sequence-challenge"
        },
        "Rhyming Practice": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
          desc: "Match rhyming pairs and auditory rhythms.",
          gameKey: "sound-match"
        },
        "Letter Hunt": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
          desc: "Distinguish tricky mirrored letter shapes.",
          gameKey: "sound-match"
        },
        "Word Builder": {
          svg: '<svg viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
          desc: "Piece together phonetic sound blocks into full words.",
          gameKey: "sequence-challenge"
        }
      };

      result.recommendations.forEach(recName => {
        const meta = recMeta[recName] || recMeta["Sound Match"];
        const card = document.createElement("div");
        card.className = "rec-card";
        card.innerHTML = `
          <div>
            <div class="rec-card-icon">${meta.svg}</div>
            <h4 class="rec-card-title">${recName}</h4>
            <p class="rec-card-desc">${meta.desc}</p>
          </div>
          <button type="button" class="btn btn-primary btn-sm btn-play-rec" data-game="${meta.gameKey}">
            Start Activity →
          </button>
        `;
        recGrid.appendChild(card);
      });

      recGrid.querySelectorAll(".btn-play-rec").forEach(btn => {
        btn.addEventListener("click", () => {
          launchGame(btn.dataset.game);
        });
      });
    }

    // Render newly added comprehensive modules
    renderErrorPatterns(result);
    renderDailyPath(result);
    renderLearningProfile(result);
    renderParentSummary(result);
  }

  const renderResults = displayResults;

  // ==========================================================================
  // ERROR PATTERN ANALYSIS (NON-DIAGNOSTIC EDUCATIONAL OBSERVATIONS)
  // ==========================================================================
  function renderErrorPatterns(result) {
    const container = document.getElementById("results-patterns-container");
    if (!container) return;
    container.innerHTML = "";

    const scores = result.categoryScores || {};
    const phonVal = scores.phonological !== undefined ? scores.phonological : (scores["Phonological Awareness"] || 75);
    const letterVal = scores.letterRecognition !== undefined ? scores.letterRecognition : (scores["Letter Recognition"] || 80);
    const seqVal = scores.sequencing !== undefined ? scores.sequencing : (scores["Sequencing"] || 70);
    const memVal = scores.workingMemory !== undefined ? scores.workingMemory : (scores["Working Memory"] || 60);
    const readVal = scores.reading !== undefined ? scores.reading : (scores["Reading Patterns"] || 80);
    const avgTime = Number(result.responseTimeAverage || 3.8);

    function evaluatePattern(score, lowDesc, medDesc, highDesc) {
      if (score >= 75) return { status: "Strong", badgeClass: "pattern-status-strong", desc: highDesc };
      if (score >= 60) return { status: "Developing", badgeClass: "pattern-status-developing", desc: medDesc };
      return { status: "Needs additional practice", badgeClass: "pattern-status-practice", desc: lowDesc };
    }

    const patterns = [
      {
        title: "Sound Matching & Auditory Phonetics",
        ...evaluatePattern(
          phonVal,
          "Observed difficulty isolating initial phonetic sounds. Regular rhyme and sound-matching activities will strengthen auditory awareness.",
          "Solid initial sound identification; occasional support needed on complex blended phonemes.",
          "Demonstrates strong phonetic discrimination and confident auditory matching across varied sound prompts."
        )
      },
      {
        title: "Letter Recognition & Spatial Orientation",
        ...evaluatePattern(
          letterVal,
          "Shows hesitation with mirrored letter shapes (e.g. b/d, p/q). Tactile tracing and visual anchor cards are recommended.",
          "Developing steady letter identification with occasional pacing pauses on mirrored characters.",
          "Quick, accurate distinction between visually similar characters and symbols."
        )
      },
      {
        title: "Cognitive Sequencing & Progressive Order",
        ...evaluatePattern(
          seqVal,
          "Benefit seen in multisensory chronological sequencing. Step-by-step numbering games will build tracking confidence.",
          "Understands sequential order; occasional pauses when sequences reverse or skip.",
          "Consistently maintains structured order across numeric, alphabetical, and visual sequences."
        )
      },
      {
        title: "Working Memory Retention & Recall",
        ...evaluatePattern(
          memVal,
          "Benefit observed from short recall chunks (2–3 items). Multi-round memory games will expand working capacity.",
          "Retains 3-item sequences reliably; slight decay on 4-item cognitive loads.",
          "Excellent short-term sequence retention and immediate recall across alphanumeric items."
        )
      },
      {
        title: "Reading Pattern Blending & Decoding",
        ...evaluatePattern(
          readVal,
          "Phonetic word-building exercises will reinforce blending confidence and decoding fluency.",
          "Recognizes familiar phonetic word families (e.g. -at, -it); reinforces with structured word building.",
          "Fluent visual pattern recognition and consistent phonetic decoding."
        )
      },
      {
        title: "Cognitive Response Pacing & Reflection",
        status: avgTime < 4.5 ? "Steady & Prompt" : "Deliberate & Thoughtful",
        badgeClass: avgTime < 4.5 ? "pattern-status-strong" : "pattern-status-developing",
        desc: avgTime < 4.5
          ? `Average pacing of ${avgTime}s demonstrates prompt confidence across familiar exercises.`
          : `Average pacing of ${avgTime}s indicates thoughtful, careful deliberation on memory and sequencing tasks.`
      }
    ];

    patterns.forEach(p => {
      const card = document.createElement("div");
      card.className = "pattern-card";
      card.innerHTML = `
        <div class="pattern-card-header">
          <span class="pattern-title">${p.title}</span>
          <span class="pattern-status-badge ${p.badgeClass}">${p.status}</span>
        </div>
        <p class="pattern-desc">${p.desc}</p>
      `;
      container.appendChild(card);
    });
  }

  // ==========================================================================
  // TODAY'S PERSONALIZED DAILY LEARNING PATH
  // ==========================================================================
  function renderDailyPath(result) {
    const container = document.getElementById("results-daily-path-container");
    if (!container) return;
    container.innerHTML = "";

    const scores = result.categoryScores || {};
    const phon = scores.phonological !== undefined ? scores.phonological : (scores["Phonological Awareness"] || 75);
    const mem = scores.workingMemory !== undefined ? scores.workingMemory : (scores["Working Memory"] || 60);
    const seq = scores.sequencing !== undefined ? scores.sequencing : (scores["Sequencing"] || 70);

    const candidates = [
      { key: "sound-match", title: "Sound Match", score: phon, domain: "Phonological Awareness", desc: "Identify initial sounds and rhyming word connections." },
      { key: "memory-match", title: "Memory Match", score: mem, domain: "Working Memory", desc: "Recall sequences of 3 to 4 items to expand cognitive span." },
      { key: "sequence-challenge", title: "Sequence Challenge", score: seq, domain: "Structured Sequencing", desc: "Solve pattern jumps and maintain chronological ordering." },
      { key: "sound-match", title: "Rhyming Practice", score: phon + 2, domain: "Auditory Rhymes", desc: "Connect rhyming word families through auditory matching." }
    ];

    candidates.sort((a, b) => a.score - b.score);
    const pathItems = candidates.slice(0, 3);

    pathItems.forEach((item, idx) => {
      const card = document.createElement("div");
      card.className = "daily-path-card";
      card.innerHTML = `
        <div>
          <div class="daily-path-card-top">
            <span class="daily-step-num">Step 0${idx + 1}</span>
            <span class="daily-duration">5 Minutes</span>
          </div>
          <h4 class="daily-activity-title">${item.title}</h4>
          <span class="daily-activity-domain">${item.domain}</span>
          <p class="pattern-desc" style="margin-top: 8px;">${item.desc}</p>
        </div>
        <button type="button" class="btn btn-primary btn-sm btn-play-daily-step" data-game="${item.key}" style="margin-top: 10px;">
          Start Activity →
        </button>
      `;
      container.appendChild(card);
    });

    container.querySelectorAll(".btn-play-daily-step").forEach(btn => {
      btn.addEventListener("click", () => {
        launchGame(btn.dataset.game);
      });
    });

    const listenBtn = document.getElementById("btn-listen-daily-path");
    if (listenBtn) {
      listenBtn.onclick = () => {
        const text = `Today's learning path consists of three activities totaling 15 minutes. Step one: ${pathItems[0].title} for five minutes. Step two: ${pathItems[1].title} for five minutes. Step three: ${pathItems[2].title} for five minutes. Consistent daily practice builds confident learners!`;
        speakText(text);
      };
    }
  }

  // ==========================================================================
  // EDUCATIONAL LEARNING PROFILE
  // ==========================================================================
  function renderLearningProfile(result) {
    const levelBadge = document.getElementById("profile-level-badge");
    const strongList = document.getElementById("profile-strong-list");
    const practiceList = document.getElementById("profile-practice-list");
    const langVal = document.getElementById("profile-lang-val");
    const levelVal = document.getElementById("profile-current-level-val");

    const level = result.level || "Developing";
    if (levelBadge) levelBadge.textContent = level;
    if (levelVal) levelVal.textContent = level;

    const langNames = { en: "English (EN)", ta: "தமிழ் (Tamil)", hi: "हिन्दी (Hindi)" };
    if (langVal) langVal.textContent = langNames[currentLanguage] || "English (EN)";

    if (strongList) {
      strongList.innerHTML = "";
      (result.strengths || ["Letter Recognition", "Phonological Awareness"]).forEach(s => {
        const li = document.createElement("li");
        li.textContent = s;
        strongList.appendChild(li);
      });
    }

    if (practiceList) {
      practiceList.innerHTML = "";
      (result.supportAreas || ["Working Memory", "Sequencing"]).forEach(s => {
        const li = document.createElement("li");
        li.textContent = s;
        practiceList.appendChild(li);
      });
    }
  }

  // ==========================================================================
  // PARENT & TEACHER LEARNING SUMMARY
  // ==========================================================================
  function renderParentSummary(result) {
    const container = document.getElementById("parent-summary-points");
    if (!container) return;
    container.innerHTML = "";

    const firstStrength = (result.strengths && result.strengths[0]) || "Letter Recognition";
    const firstSupport = (result.supportAreas && result.supportAreas[0]) || "Working Memory";
    const recGame = (result.recommendations && result.recommendations[0]) || "Memory Match";

    const points = [
      {
        tag: "Observed Strength",
        text: `Strong foundational ability observed in ${firstStrength}. Celebrate this confidence and encourage your child's natural enthusiasm for reading patterns.`
      },
      {
        tag: "Targeted Practice Area",
        text: `${firstSupport} will benefit from brief, regular multisensory activities. Short 5–10 minute games prevent cognitive fatigue while consolidating skills.`
      },
      {
        tag: "Actionable Recommendation",
        text: `Play ${recGame} together daily. Repetition of sequences and audio cues reinforces auditory and visual memory pathways.`
      },
      {
        tag: "Constructive Next Step",
        text: "Continue structured daily practice at home and school. If high support needs persist across multiple learning cycles, consider consulting a qualified educational specialist."
      }
    ];

    points.forEach(pt => {
      const card = document.createElement("div");
      card.className = "summary-point-card";
      card.innerHTML = `
        <span class="summary-point-tag">${pt.tag}</span>
        <p class="summary-point-text">${pt.text}</p>
      `;
      container.appendChild(card);
    });

    const listenSummaryBtn = document.getElementById("btn-listen-parent-summary");
    if (listenSummaryBtn) {
      listenSummaryBtn.onclick = () => {
        const text = `Parent and Teacher Learning Summary. Strength: Strong foundational ability observed in ${firstStrength}. Practice: ${firstSupport} will benefit from brief, regular activities. Recommendation: Play ${recGame} together daily for 5 to 10 minutes. Next step: Continue regular reading and playful language activities.`;
        speakText(text);
      };
    }
  }


  // ==========================================================================
  // 11. THREE FULLY PLAYABLE INTERACTIVE GAMES (ZERO EMOJIS)
  // ==========================================================================
  let activeGame = null;
  let gameRound = 0;
  let gameScore = 0;
  const GAME_TOTAL_ROUNDS = 5;

  // Sound Match Game Bank (Clean vocabulary)
  const SOUND_MATCH_ROUNDS = [
    { prompt: 'Which word starts with the sound like SUN?', speech: 'Which word starts like SUN?', sound: 'S', correct: 'Sock', options: ['Sock', 'Boat', 'Duck', 'Cup'] },
    { prompt: 'Which word starts with the sound like BALL?', speech: 'Which word starts like BALL?', sound: 'B', correct: 'Bat', options: ['Tree', 'Bat', 'Fish', 'Star'] },
    { prompt: 'Which word starts with the sound like FISH?', speech: 'Which word starts like FISH?', sound: 'F', correct: 'Fan', options: ['Cat', 'Apple', 'Fan', 'House'] },
    { prompt: 'Which word starts with the sound like MOON?', speech: 'Which word starts like MOON?', sound: 'M', correct: 'Monkey', options: ['Dog', 'Sun', 'Leaf', 'Monkey'] },
    { prompt: 'Which word starts with the sound like TREE?', speech: 'Which word starts like TREE?', sound: 'T', correct: 'Tiger', options: ['Tiger', 'Pig', 'Bird', 'Moon'] }
  ];

  // Memory Match Game Bank (Clean alphanumeric & geometric sequences)
  const MEMORY_MATCH_ROUNDS = [
    { display: ['A', '9', 'X'], options: ['A - 9 - X', '9 - A - X', 'X - 9 - A', 'A - X - 9'], correct: 'A - 9 - X' },
    { display: ['4', 'K', '2'], options: ['4 - K - 2', 'K - 4 - 2', '2 - K - 4', '4 - 2 - K'], correct: '4 - K - 2' },
    { display: ['Circle', 'Triangle', 'Square'], options: ['Circle - Triangle - Square', 'Triangle - Circle - Square', 'Square - Triangle - Circle', 'Circle - Square - Triangle'], correct: 'Circle - Triangle - Square' },
    { display: ['7', 'B', '3'], options: ['7 - B - 3', 'B - 7 - 3', '3 - B - 7', '7 - 3 - B'], correct: '7 - B - 3' },
    { display: ['M', '8', 'P'], options: ['M - 8 - P', '8 - M - P', 'P - 8 - M', 'M - P - 8'], correct: 'M - 8 - P' }
  ];

  // Sequence Challenge Game Bank (Clean patterns & progressions)
  const SEQUENCE_ROUNDS = [
    { prompt: 'What is the next number in this sequence?', sequence: '2 → 4 → 6 → ?', options: ['8', '7', '10', '5'], correct: '8' },
    { prompt: 'What comes next in the letter sequence?', sequence: 'A → C → E → ?', options: ['G', 'F', 'H', 'D'], correct: 'G' },
    { prompt: 'What is the next number in this countdown?', sequence: '10 → 8 → 6 → ?', options: ['4', '5', '3', '2'], correct: '4' },
    { prompt: 'What is the next step in this shape sequence?', sequence: 'Circle → Square → Triangle → Circle → ?', options: ['Square', 'Circle', 'Triangle', 'Hexagon'], correct: 'Square' },
    { prompt: 'What comes next in the day progression?', sequence: 'Mon → Tue → Wed → ?', options: ['Thu', 'Fri', 'Sat', 'Sun'], correct: 'Thu' }
  ];

  // ==========================================================================
  // MULTILINGUAL & ADAPTIVE GAME BANKS (EN, TA, HI x EASY, MEDIUM, HARD)
  // ==========================================================================
  const SOUND_MATCH_BANKS = {
    en: {
      easy: [
        { prompt: "Which word starts with the sound like SUN?", speech: "Which word starts like SUN?", sound: "S", correct: "Sock", options: ["Sock", "Boat", "Duck", "Cup"] },
        { prompt: "Which word starts with the sound like BALL?", speech: "Which word starts like BALL?", sound: "B", correct: "Bat", options: ["Tree", "Bat", "Fish", "Star"] },
        { prompt: "Which word starts with the sound like FISH?", speech: "Which word starts like FISH?", sound: "F", correct: "Fan", options: ["Cat", "Apple", "Fan", "House"] },
        { prompt: "Which word starts with the sound like MOON?", speech: "Which word starts like MOON?", sound: "M", correct: "Monkey", options: ["Dog", "Sun", "Leaf", "Monkey"] },
        { prompt: "Which word starts with the sound like TREE?", speech: "Which word starts like TREE?", sound: "T", correct: "Tiger", options: ["Tiger", "Pig", "Bird", "Moon"] }
      ],
      medium: [
        { prompt: "Which word rhymes with CAT?", speech: "Which word rhymes with CAT?", sound: "AT", correct: "Bat", options: ["Bat", "Dog", "Cup", "Sun"] },
        { prompt: "Which word starts with the blend like FROG?", speech: "Which word starts like FROG?", sound: "FR", correct: "Fruit", options: ["Star", "Fruit", "Ship", "Ball"] },
        { prompt: "Which word rhymes with RING?", speech: "Which word rhymes with RING?", sound: "ING", correct: "King", options: ["Bell", "King", "Tree", "Duck"] },
        { prompt: "Which word starts with the blend like STAR?", speech: "Which word starts like STAR?", sound: "ST", correct: "Step", options: ["Tiger", "Pig", "Step", "Bird"] },
        { prompt: "Which word rhymes with BOAT?", speech: "Which word rhymes with BOAT?", sound: "OAT", correct: "Coat", options: ["Sock", "Coat", "Fish", "Moon"] }
      ],
      hard: [
        { prompt: "Which word shares the ending blend in CLOUD?", speech: "Which word shares the ending sound in CLOUD?", sound: "D", correct: "Proud", options: ["Proud", "Clown", "Clock", "Clean"] },
        { prompt: "Identify the rhyme pattern for TRAIN:", speech: "Which word rhymes with TRAIN?", sound: "AIN", correct: "Brain", options: ["Brain", "Tree", "Trail", "Trap"] },
        { prompt: "Which word has the same vowel digraph as LIGHT?", speech: "Which word sounds like LIGHT?", sound: "IGHT", correct: "Night", options: ["Late", "Night", "Lip", "List"] },
        { prompt: "Identify the word that rhymes with BRUSH:", speech: "Which word rhymes with BRUSH?", sound: "USH", correct: "Crush", options: ["Crush", "Bush", "Brave", "Bark"] },
        { prompt: "Which word matches the sound structure of STRING?", speech: "Which word rhymes with STRING?", sound: "ING", correct: "Spring", options: ["Stick", "Spring", "Strong", "Strap"] }
      ]
    },
    ta: {
      easy: [
        { prompt: "அம்மா (அ) என்ற ஒலியுடன் தொடங்கும் சொல் எது?", speech: "அம்மா என்ற சொல்லின் முதல் ஒலியுடன் தொடங்கும் சொல் எது?", sound: "அ", correct: "அனில்", options: ["அனில்", "பந்து", "கண்", "மரம்"] },
        { prompt: "பட்டம் (ப) என்ற ஒலியுடன் தொடங்கும் சொல் எது?", speech: "பட்டம் என்ற சொல்லின் முதல் ஒலியுடன் தொடங்கும் சொல் எது?", sound: "ப", correct: "பந்து", options: ["பூனை", "பந்து", "மீன்", "நரி"] },
        { prompt: "மரம் (ம) என்ற ஒலியுடன் தொடங்கும் சொல் எது?", speech: "மரம் என்ற சொல்லின் முதல் ஒலியுடன் தொடங்கும் சொல் எது?", sound: "ம", correct: "மாம்பழம்", options: ["வீடு", "மாம்பழம்", "நாய்", "காடு"] },
        { prompt: "காடு (க) என்ற ஒலியுடன் தொடங்கும் சொல் எது?", speech: "காடு என்ற சொல்லின் முதல் ஒலியுடன் தொடங்கும் சொல் எது?", sound: "க", correct: "காகம்", options: ["ஆடு", "காகம்", "மணி", "புலி"] },
        { prompt: "யானை (ய) என்ற ஒலியுடன் தொடங்கும் சொல் எது?", speech: "யானை என்ற சொல்லின் முதல் ஒலியுடன் தொடங்கும் சொல் எது?", sound: "ய", correct: "யாழ்", options: ["யாழ்", "நரி", "மான்", "வண்டு"] }
      ],
      medium: [
        { prompt: "பூ → கூ → சூ என்ற எதுகை வரிசையில் அடுத்த ஒலி எது?", speech: "பூ கூ சூ என்ற எதுகை வரிசையில் அடுத்த சொல் எது?", sound: "ஊ", correct: "தூ", options: ["தூ", "கல்", "பல்", "சொல்"] },
        { prompt: "கல் என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", speech: "கல் என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", sound: "அல்", correct: "பல்", options: ["பல்", "மண்", "கண்", "மரம்"] },
        { prompt: "மான் என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", speech: "மான் என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", sound: "ஆன்", correct: "வான்", options: ["வான்", "புலி", "நரி", "பூனை"] },
        { prompt: "பாட்டு என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", speech: "பாட்டு என்ற சொல்லுடன் எதுகை ஒலிக்கும் சொல் எது?", sound: "ஆட்டு", correct: "காட்டு", options: ["காட்டு", "வீடு", "ஆடு", "மாடு"] },
        { prompt: "பனி என்ற சொல்லுடன் ஒலி ஒப்புமை உள்ள சொல் எது?", speech: "பனி என்ற சொல்லுடன் ஒலி ஒப்புமை உள்ள சொல் எது?", sound: "அனி", correct: "கனி", options: ["கனி", "மரம்", "கல்", "பல்"] }
      ],
      hard: [
        { prompt: "வல்லின மெய்யெழுத்து ஒலி எது?", speech: "வல்லின மெய்யெழுத்து ஒலி எது?", sound: "க்", correct: "கப்பல்", options: ["கப்பல்", "மரம்", "வண்டு", "யாழ்"] },
        { prompt: "மெல்லின மெய்யெழுத்து ஒலி எது?", speech: "மெல்லின மெய்யெழுத்து ஒலி எது?", sound: "ம்", correct: "மலர்", options: ["மலர்", "கல்", "பல்", "சொல்"] },
        { prompt: "இரட்டைக்கிளவி ஒலி எது?", speech: "இரட்டைக்கிளவி ஒலி எது?", sound: "சல", correct: "சலசல", options: ["சலசல", "வேகம்", "மெதுவாக", "உயர்"] },
        { prompt: "ஐகாரக் குறுக்கம் உள்ள சொல் எது?", speech: "ஐகாரக் குறுக்கம் உள்ள சொல் எது?", sound: "ஐ", correct: "தலைவன்", options: ["தலைவன்", "அம்மா", "அப்பா", "தம்பி"] },
        { prompt: "ஆய்த எழுத்து ஒலி உள்ள சொல் எது?", speech: "ஆய்த எழுத்து ஒலி உள்ள சொல் எது?", sound: "ஃ", correct: "எஃகு", options: ["எஃகு", "மரம்", "கப்பல்", "பந்து"] }
      ]
    },
    hi: {
      easy: [
        { prompt: "सूरज (स) की ध्वनि से शुरू होने वाला शब्द कौन सा है?", speech: "सूरज की ध्वनि से शुरू होने वाला शब्द कौन सा है?", sound: "स", correct: "सेब", options: ["सेब", "नाव", "बतख", "प्याला"] },
        { prompt: "बस (ब) की ध्वनि से शुरू होने वाला शब्द कौन सा है?", speech: "बस की ध्वनि से शुरू होने वाला शब्द कौन सा है?", sound: "ब", correct: "बल्ला", options: ["पेड़", "बल्ला", "मछली", "तारा"] },
        { prompt: "पतंग (प) की ध्वनि से शुरू होने वाला शब्द कौन सा है?", speech: "पतंग की ध्वनि से शुरू होने वाला शब्द कौन सा है?", sound: "प", correct: "पानी", options: ["बिल्ली", "आम", "पानी", "घर"] },
        { prompt: "मोर (म) की ध्वनि से शुरू होने वाला शब्द कौन सा है?", speech: "मोर की ध्वनि से शुरू होने वाला शब्द कौन सा है?", sound: "म", correct: "मछली", options: ["कुत्ता", "मछली", "पत्ता", "तारा"] },
        { prompt: "तितली (त) की ध्वनि से शुरू होने वाला शब्द कौन सा है?", speech: "तितली की ध्वनि से शुरू होने वाला शब्द कौन सा है?", sound: "त", correct: "तारा", options: ["तारा", "सूरज", "घर", "पेड़"] }
      ],
      medium: [
        { prompt: "कम → हम → रम की तुकबंदी में अगला शब्द कौन सा है?", speech: "कम हम रम की तुकबंदी में अगला शब्द कौन सा है?", sound: "अम", correct: "दम", options: ["दम", "जल", "कल", "फल"] },
        { prompt: "रात से तुक मिलाने वाला शब्द कौन सा है?", speech: "रात से तुक मिलाने वाला शब्द कौन सा है?", sound: "आत", correct: "बात", options: ["बात", "दिन", "सुबह", "शाम"] },
        { prompt: "राजा से तुक मिलाने वाला शब्द कौन सा है?", speech: "राजा से तुक मिलाने वाला शब्द कौन सा है?", sound: "आजा", correct: "बाजा", options: ["बाजा", "रानी", "महल", "घोड़ा"] },
        { prompt: "माला से तुक मिलाने वाला शब्द कौन सा है?", speech: "माला से तुक मिलाने वाला शब्द कौन सा है?", sound: "आला", correct: "ताला", options: ["ताला", "फूल", "पत्ता", "डाली"] },
        { prompt: "पानी से तुक मिलाने वाला शब्द कौन सा है?", speech: "पानी से तुक मिलाने वाला शब्द कौन सा है?", sound: "आनी", correct: "नानी", options: ["नानी", "दूध", "चाय", "रस"] }
      ],
      hard: [
        { prompt: "संयुक्त व्यंजन (क्ष, त्र, ज्ञ) की पहचान करें:", speech: "संयुक्त व्यंजन वाला शब्द कौन सा है?", sound: "क्ष", correct: "कक्षा", options: ["कक्षा", "कमल", "कलम", "कप"] },
        { prompt: "अनुस्वार (ं) ध्वनि वाला शब्द कौन सा है?", speech: "अनुस्वार ध्वनि वाला शब्द कौन सा है?", sound: "ं", correct: "पतंग", options: ["पतंग", "पानी", "पत्ता", "पीला"] },
        { prompt: "रेफ (र्) की ध्वनि वाला शब्द पहचानें:", speech: "रेफ की ध्वनि वाला शब्द पहचानें:", sound: "र्", correct: "सूर्य", options: ["सूर्य", "सूरज", "सवेरा", "साल"] },
        { prompt: "ऋ की मात्रा वाला शब्द कौन सा है?", speech: "ऋ की मात्रा वाला शब्द कौन सा है?", sound: "ऋ", correct: "वृक्ष", options: ["वृक्ष", "पेड़", "पौधा", "पत्ता"] },
        { prompt: "विदेशी आगत ध्वनि (ऑ) का शब्द कौन सा है?", speech: "आगत ध्वनि वाला शब्द कौन सा है?", sound: "ऑ", correct: "डॉक्टर", options: ["डॉक्टर", "दवा", "इलाज", "रोगी"] }
      ]
    }
  };

  const MEMORY_MATCH_BANKS = {
    en: {
      easy: [
        { display: ["A", "9"], options: ["A - 9", "9 - A", "B - 9", "A - 8"], correct: "A - 9" },
        { display: ["4", "K"], options: ["4 - K", "K - 4", "4 - M", "2 - K"], correct: "4 - K" },
        { display: ["Red", "Blue"], options: ["Red - Blue", "Blue - Red", "Green - Red", "Red - Green"], correct: "Red - Blue" },
        { display: ["7", "B"], options: ["7 - B", "B - 7", "7 - D", "3 - B"], correct: "7 - B" },
        { display: ["M", "8"], options: ["M - 8", "8 - M", "W - 8", "M - 3"], correct: "M - 8" }
      ],
      medium: [
        { display: ["A", "9", "X"], options: ["A - 9 - X", "9 - A - X", "X - 9 - A", "A - X - 9"], correct: "A - 9 - X" },
        { display: ["4", "K", "2"], options: ["4 - K - 2", "K - 4 - 2", "2 - K - 4", "4 - 2 - K"], correct: "4 - K - 2" },
        { display: ["Circle", "Triangle", "Square"], options: ["Circle - Triangle - Square", "Triangle - Circle - Square", "Square - Triangle - Circle", "Circle - Square - Triangle"], correct: "Circle - Triangle - Square" },
        { display: ["7", "B", "3"], options: ["7 - B - 3", "B - 7 - 3", "3 - B - 7", "7 - 3 - B"], correct: "7 - B - 3" },
        { display: ["M", "8", "P"], options: ["M - 8 - P", "8 - M - P", "P - 8 - M", "M - P - 8"], correct: "M - 8 - P" }
      ],
      hard: [
        { display: ["B", "7", "M", "4"], options: ["B - 7 - M - 4", "7 - B - M - 4", "B - M - 7 - 4", "4 - M - 7 - B"], correct: "B - 7 - M - 4" },
        { display: ["9", "P", "3", "K"], options: ["9 - P - 3 - K", "P - 9 - 3 - K", "9 - 3 - P - K", "K - 3 - P - 9"], correct: "9 - P - 3 - K" },
        { display: ["D", "5", "R", "8"], options: ["D - 5 - R - 8", "5 - D - R - 8", "D - R - 5 - 8", "8 - R - 5 - D"], correct: "D - 5 - R - 8" },
        { display: ["6", "T", "2", "H"], options: ["6 - T - 2 - H", "T - 6 - 2 - H", "6 - 2 - T - H", "H - 2 - T - 6"], correct: "6 - T - 2 - H" },
        { display: ["F", "4", "N", "9"], options: ["F - 4 - N - 9", "4 - F - N - 9", "F - N - 4 - 9", "9 - N - 4 - F"], correct: "F - 4 - N - 9" }
      ]
    },
    ta: {
      easy: [
        { display: ["அ", "5"], options: ["அ - 5", "5 - அ", "ஆ - 5", "அ - 2"], correct: "அ - 5" },
        { display: ["க", "3"], options: ["க - 3", "3 - க", "ச - 3", "க - 7"], correct: "க - 3" },
        { display: ["ம", "8"], options: ["ம - 8", "8 - ம", "ப - 8", "ம - 4"], correct: "ம - 8" },
        { display: ["த", "2"], options: ["த - 2", "2 - த", "ந - 2", "த - 9"], correct: "த - 2" },
        { display: ["வ", "6"], options: ["வ - 6", "6 - வ", "ழ - 6", "வ - 3"], correct: "வ - 6" }
      ],
      medium: [
        { display: ["அ", "5", "க"], options: ["அ - 5 - க", "5 - அ - க", "க - 5 - அ", "அ - க - 5"], correct: "அ - 5 - க" },
        { display: ["ம", "2", "ப"], options: ["ம - 2 - ப", "2 - ம - ப", "ப - 2 - ம", "ம - ப - 2"], correct: "ம - 2 - ப" },
        { display: ["வ", "7", "ள"], options: ["வ - 7 - ள", "7 - வ - ள", "ள - 7 - வ", "வ - ள - 7"], correct: "வ - 7 - ள" },
        { display: ["த", "9", "ந"], options: ["த - 9 - ந", "9 - த - ந", "ந - 9 - த", "த - ந - 9"], correct: "த - 9 - ந" },
        { display: ["ர", "4", "ல"], options: ["ர - 4 - ல", "4 - ர - ல", "ல - 4 - ர", "ர - ல - 4"], correct: "ர - 4 - ல" }
      ],
      hard: [
        { display: ["அ", "3", "க", "7"], options: ["அ - 3 - க - 7", "3 - அ - க - 7", "அ - க - 3 - 7", "7 - க - 3 - அ"], correct: "அ - 3 - க - 7" },
        { display: ["ம", "6", "ப", "2"], options: ["ம - 6 - ப - 2", "6 - ம - ப - 2", "ம - ப - 6 - 2", "2 - ப - 6 - ம"], correct: "ம - 6 - ப - 2" },
        { display: ["வ", "8", "ள", "4"], options: ["வ - 8 - ள - 4", "8 - வ - ள - 4", "வ - ள - 8 - 4", "4 - ள - 8 - வ"], correct: "வ - 8 - ள - 4" },
        { display: ["த", "1", "ந", "9"], options: ["த - 1 - ந - 9", "1 - த - ந - 9", "த - ந - 1 - 9", "9 - ந - 1 - த"], correct: "த - 1 - ந - 9" },
        { display: ["ச", "5", "ஞ", "8"], options: ["ச - 5 - ஞ - 8", "5 - ச - ஞ - 8", "ச - ஞ - 5 - 8", "8 - ஞ - 5 - ச"], correct: "ச - 5 - ஞ - 8" }
      ]
    },
    hi: {
      easy: [
        { display: ["क", "4"], options: ["क - 4", "4 - क", "ख - 4", "क - 2"], correct: "क - 4" },
        { display: ["म", "7"], options: ["म - 7", "7 - म", "न - 7", "म - 3"], correct: "म - 7" },
        { display: ["प", "2"], options: ["प - 2", "2 - प", "ब - 2", "प - 8"], correct: "प - 2" },
        { display: ["स", "9"], options: ["स - 9", "9 - स", "श - 9", "स - 5"], correct: "स - 9" },
        { display: ["र", "6"], options: ["र - 6", "6 - र", "ल - 6", "र - 1"], correct: "र - 6" }
      ],
      medium: [
        { display: ["क", "4", "स"], options: ["क - 4 - स", "4 - क - स", "स - 4 - क", "क - स - 4"], correct: "क - 4 - स" },
        { display: ["म", "8", "र"], options: ["म - 8 - र", "8 - म - र", "र - 8 - म", "म - र - 8"], correct: "म - 8 - र" },
        { display: ["प", "3", "ल"], options: ["प - 3 - ल", "3 - प - ल", "ल - 3 - प", "प - ल - 3"], correct: "प - 3 - ल" },
        { display: ["त", "6", "न"], options: ["त - 6 - न", "6 - त - न", "न - 6 - त", "त - न - 6"], correct: "त - 6 - न" },
        { display: ["च", "2", "ह"], options: ["च - 2 - ह", "2 - च - ह", "ह - 2 - च", "च - ह - 2"], correct: "च - 2 - ह" }
      ],
      hard: [
        { display: ["क", "7", "म", "2"], options: ["क - 7 - म - 2", "7 - क - म - 2", "क - म - 7 - 2", "2 - म - 7 - क"], correct: "क - 7 - म - 2" },
        { display: ["प", "4", "स", "9"], options: ["प - 4 - स - 9", "4 - प - स - 9", "प - स - 4 - 9", "9 - स - 4 - प"], correct: "प - 4 - स - 9" },
        { display: ["र", "8", "ल", "3"], options: ["र - 8 - ल - 3", "8 - र - ल - 3", "र - ल - 8 - 3", "3 - ल - 8 - र"], correct: "र - 8 - ल - 3" },
        { display: ["त", "5", "द", "1"], options: ["त - 5 - द - 1", "5 - त - द - 1", "त - द - 5 - 1", "1 - द - 5 - त"], correct: "त - 5 - द - 1" },
        { display: ["ज", "6", "ब", "4"], options: ["ज - 6 - ब - 4", "6 - ज - ब - 4", "ज - ब - 6 - 4", "4 - ब - 6 - ज"], correct: "ज - 6 - ब - 4" }
      ]
    }
  };

  const SEQUENCE_BANKS = {
    en: {
      easy: [
        { prompt: "What is the next number in this sequence?", sequence: "2 → 4 → 6 → ?", options: ["8", "7", "10", "5"], correct: "8" },
        { prompt: "What comes next in counting?", sequence: "10 → 20 → 30 → ?", options: ["40", "35", "50", "25"], correct: "40" },
        { prompt: "What is the next number in this countdown?", sequence: "5 → 4 → 3 → ?", options: ["2", "1", "0", "6"], correct: "2" },
        { prompt: "What comes next in the alphabet?", sequence: "A → B → C → ?", options: ["D", "E", "F", "C"], correct: "D" },
        { prompt: "What comes next in the shape pattern?", sequence: "Circle → Square → Circle → ?", options: ["Square", "Circle", "Triangle", "Star"], correct: "Square" }
      ],
      medium: [
        { prompt: "What is the next number in this jump sequence?", sequence: "3 → 6 → 9 → ?", options: ["12", "11", "15", "10"], correct: "12" },
        { prompt: "What comes next in the letter sequence?", sequence: "A → C → E → ?", options: ["G", "F", "H", "D"], correct: "G" },
        { prompt: "What is the next number in this countdown?", sequence: "10 → 8 → 6 → ?", options: ["4", "5", "3", "2"], correct: "4" },
        { prompt: "What is the next step in this shape sequence?", sequence: "Circle → Square → Triangle → Circle → ?", options: ["Square", "Circle", "Triangle", "Hexagon"], correct: "Square" },
        { prompt: "What comes next in the day progression?", sequence: "Mon → Tue → Wed → ?", options: ["Thu", "Fri", "Sat", "Sun"], correct: "Thu" }
      ],
      hard: [
        { prompt: "What is the next number in this alternating pattern?", sequence: "2 → 5 → 4 → 7 → 6 → ?", options: ["9", "8", "10", "7"], correct: "9" },
        { prompt: "What comes next in this reverse alphabet sequence?", sequence: "Z → X → V → ?", options: ["T", "U", "S", "W"], correct: "T" },
        { prompt: "What is the next number in this sequence?", sequence: "1 → 2 → 4 → 8 → ?", options: ["16", "12", "14", "10"], correct: "16" },
        { prompt: "What is the next letter in this sequence?", sequence: "B → E → H → ?", options: ["K", "J", "I", "L"], correct: "K" },
        { prompt: "What completes this double sequence?", sequence: "10 → 20 → 15 → 25 → 20 → ?", options: ["30", "25", "35", "22"], correct: "30" }
      ]
    },
    ta: {
      easy: [
        { prompt: "அடுத்த எண் எது?", sequence: "2 → 4 → 6 → ?", options: ["8", "7", "10", "5"], correct: "8" },
        { prompt: "தமிழ் அகரவரிசையில் அடுத்த எழுத்து எது?", sequence: "அ → ஆ → இ → ?", options: ["ஈ", "உ", "ஊ", "எ"], correct: "ஈ" },
        { prompt: "அடுத்த பத்து எண் எது?", sequence: "10 → 20 → 30 → ?", options: ["40", "35", "50", "25"], correct: "40" },
        { prompt: "அகரவரிசையில் அடுத்த எழுத்து எது?", sequence: "உ → ஊ → எ → ?", options: ["ஏ", "ஐ", "ஒ", "ஓ"], correct: "ஏ" },
        { prompt: "அடுத்த கிழமை எது?", sequence: "திங்கள் → செவ்வாய் → புதன் → ?", options: ["வியாழன்", "வெள்ளி", "சனி", "ஞாயிறு"], correct: "வியாழன்" }
      ],
      medium: [
        { prompt: "எழுத்து வரிசையில் விடுபட்ட எழுத்து எது?", sequence: "க → ங → ச → ?", options: ["ஞ", "ட", "ண", "த"], correct: "ஞ" },
        { prompt: "இரட்டை எண்கள் வரிசை:", sequence: "4 → 8 → 12 → ?", options: ["16", "14", "18", "20"], correct: "16" },
        { prompt: "அடுத்த எழுத்து எது?", sequence: "த → ந → ப → ?", options: ["ம", "ய", "ர", "ல"], correct: "ம" },
        { prompt: "பின்னோக்கு எண் வரிசை:", sequence: "10 → 8 → 6 → ?", options: ["4", "5", "3", "2"], correct: "4" },
        { prompt: "அடுத்த மாதம் எது?", sequence: "சித்திரை → வைகாசி → ஆனி → ?", options: ["ஆடி", "ஆவணி", "புரட்டாசி", "ஐப்பசி"], correct: "ஆடி" }
      ],
      hard: [
        { prompt: "இடைப்பட்ட மெய்யெழுத்து வரிசை:", sequence: "க் → ச் → ட் → ?", options: ["த்", "ப்", "ற்", "ஞ்"], correct: "த்" },
        { prompt: "இரட்டிப்பு எண் வரிசை:", sequence: "1 → 2 → 4 → 8 → ?", options: ["16", "12", "14", "10"], correct: "16" },
        { prompt: "மாற்று வரிசையில் அடுத்த எண்:", sequence: "2 → 5 → 4 → 7 → 6 → ?", options: ["9", "8", "10", "7"], correct: "9" },
        { prompt: "இடையின மெய்யெழுத்து வரிசை:", sequence: "ய் → ர் → ல் → ?", options: ["வ்", "ழ்", "ள்", "ண்"], correct: "வ்" },
        { prompt: "பின்னோக்கு தமிழ் எழுத்து வரிசை:", sequence: "ஔ → ஓ → ஒ → ?", options: ["ஐ", "ஏ", "எ", "ஊ"], correct: "ஐ" }
      ]
    },
    hi: {
      easy: [
        { prompt: "अगली संख्या कौन सी है?", sequence: "2 → 4 → 6 → ?", options: ["8", "7", "10", "5"], correct: "8" },
        { prompt: "वर्णमाला में अगला स्वर कौन सा है?", sequence: "अ → आ → इ → ?", options: ["ई", "उ", "ऊ", "ए"], correct: "ई" },
        { prompt: "दहाई क्रम में अगला अंक कौन सा है?", sequence: "10 → 20 → 30 → ?", options: ["40", "35", "50", "25"], correct: "40" },
        { prompt: "स्वर क्रम में अगला अक्षर कौन सा है?", sequence: "उ → ऊ → ऋ → ?", options: ["ए", "ऐ", "ओ", "औ"], correct: "ए" },
        { prompt: "सप्ताह के क्रम में अगला दिन कौन सा है?", sequence: "सोम → मंगल → बुध → ?", options: ["गुरु", "शुक्र", "शनि", "रवि"], correct: "गुरु" }
      ],
      medium: [
        { prompt: "व्यंजन क्रम में अगला अक्षर कौन सा है?", sequence: "क → ख → ग → ?", options: ["घ", "च", "छ", "ज"], correct: "घ" },
        { prompt: "तीन की गिनती में अगली संख्या:", sequence: "3 → 6 → 9 → ?", options: ["12", "11", "15", "10"], correct: "12" },
        { prompt: "व्यंजन क्रम में अगला अक्षर:", sequence: "ट → ठ → ड → ?", options: ["ढ", "त", "थ", "द"], correct: "ढ" },
        { prompt: "उल्टी गिनती में अगली संख्या:", sequence: "10 → 8 → 6 → ?", options: ["4", "5", "3", "2"], correct: "4" },
        { prompt: "व्यंजन क्रम में अगला अक्षर:", sequence: "त → थ → द → ?", options: ["ध", "न", "प", "फ"], correct: "ध" }
      ],
      hard: [
        { prompt: "अल्टरनेटिव संख्या क्रम में अगली संख्या:", sequence: "2 → 5 → 4 → 7 → 6 → ?", options: ["9", "8", "10", "7"], correct: "9" },
        { prompt: "उल्टी वर्णमाला में अगला अक्षर:", sequence: "ज्ञ → त्र → क्ष → ?", options: ["ह", "श", "ष", "स"], correct: "ह" },
        { prompt: "दोगुनी संख्या का क्रम:", sequence: "1 → 2 → 4 → 8 → ?", options: ["16", "12", "14", "10"], correct: "16" },
        { prompt: "क वर्ग, च वर्ग, ट वर्ग के बाद अगला वर्ग:", sequence: "क → च → ट → ?", options: ["त", "प", "य", "श"], correct: "त" },
        { prompt: "मिश्रित अनुक्रम पूरा करें:", sequence: "10 → 20 → 15 → 25 → 20 → ?", options: ["30", "25", "35", "22"], correct: "30" }
      ]
    }
  };

  function getActiveSoundMatchRounds() {
    const lang = SOUND_MATCH_BANKS[currentLanguage] ? currentLanguage : "en";
    const diff = (SOUND_MATCH_BANKS[lang] && SOUND_MATCH_BANKS[lang][gameDifficulty]) ? gameDifficulty : "medium";
    return SOUND_MATCH_BANKS[lang][diff];
  }

  function getActiveMemoryMatchRounds() {
    const lang = MEMORY_MATCH_BANKS[currentLanguage] ? currentLanguage : "en";
    const diff = (MEMORY_MATCH_BANKS[lang] && MEMORY_MATCH_BANKS[lang][gameDifficulty]) ? gameDifficulty : "medium";
    return MEMORY_MATCH_BANKS[lang][diff];
  }

  function getActiveSequenceRounds() {
    const lang = SEQUENCE_BANKS[currentLanguage] ? currentLanguage : "en";
    const diff = (SEQUENCE_BANKS[lang] && SEQUENCE_BANKS[lang][gameDifficulty]) ? gameDifficulty : "medium";
    return SEQUENCE_BANKS[lang][diff];
  }

  function launchGame(gameKey) {
    activeGame = gameKey;
    gameRound = 0;
    gameScore = 0;

    const overlay = document.getElementById('game-arena-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');

    const diffBadge = document.getElementById('game-difficulty-badge');
    if (diffBadge) diffBadge.textContent = `Level: ${gameDifficulty.toUpperCase()}`;

    const alertEl = document.getElementById('game-diff-adjusted-alert');
    if (alertEl) alertEl.classList.add('hidden');

    const celebScreen = document.getElementById('game-celebration-screen');
    celebScreen.classList.add('hidden');
    const stageContainer = document.getElementById('game-stage-container');
    stageContainer.classList.remove('hidden');

    const titleMap = {
      'sound-match': 'Sound Match (Phonics)',
      'memory-match': 'Memory Match (Working Memory)',
      'sequence-challenge': 'Sequence Challenge (Sequencing)',
      'letter-hunt': 'Letter Hunt (Letter Recognition)',
      'word-builder': 'Word Builder (Reading Patterns)',
      'rhyming-game': 'Rhyming Practice (Rhyming)',
      'rapid-naming': 'Rapid Naming Sprint',
      'vocab-sparks': 'Vocabulary Sparks',
      'auditory-rhythm': 'Auditory Rhythm (Listening)'
    };

    document.getElementById('arena-game-title').textContent = titleMap[gameKey] || 'Interactive Exercise';
    renderGameRound();
  }

  function renderGameRound() {
    if (gameRound >= GAME_TOTAL_ROUNDS) {
      finishGame();
      return;
    }

    document.getElementById('arena-round-badge').textContent = `Round ${gameRound + 1} / ${GAME_TOTAL_ROUNDS}`;
    document.getElementById('arena-score-badge').textContent = `Score: ${gameScore * 20} pts`;

    const stage = document.getElementById('game-stage-container');
    stage.innerHTML = '';

    if (activeGame === 'sound-match' || activeGame === 'letter-hunt' || activeGame === 'rhyming-game' || activeGame === 'auditory-rhythm') {
      renderSoundMatchStage(stage);
    } else if (activeGame === 'memory-match') {
      renderMemoryMatchStage(stage);
    } else {
      renderSequenceStage(stage);
    }
  }

  function renderSoundMatchStage(container) {
    const rounds = getActiveSoundMatchRounds();
    const roundData = rounds[gameRound % rounds.length];

    const heading = document.createElement('h3');
    heading.className = 'game-prompt-title';
    heading.textContent = roundData.prompt;

    const visual = document.createElement('div');
    visual.className = 'game-prompt-visual';
    visual.innerHTML = `
      <button type="button" class="btn btn-audio" id="btn-sound-play" style="padding: 10px 20px;">
        <svg class="audio-svg" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="9 4 4 8 1 8 1 12 4 12 9 16 9 4"/><path d="M14 6C15.5 7.5 15.5 12.5 14 14"/></svg>
        <span>Play Sound "${roundData.sound}"</span>
      </button>
    `;

    const grid = document.createElement('div');
    grid.className = 'game-options-row';

    roundData.options.forEach(opt => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'game-choice-btn';
      btn.textContent = opt;

      btn.addEventListener('click', () => {
        handleGameChoice(btn, opt === roundData.correct);
      });

      grid.appendChild(btn);
    });

    container.appendChild(heading);
    container.appendChild(visual);
    container.appendChild(grid);

    const playBtn = container.querySelector('#btn-sound-play');
    if (playBtn) {
      playBtn.onclick = () => speakText(`${roundData.speech}. Options are ${roundData.options.join(', ')}`);
    }
  }

  function renderMemoryMatchStage(container) {
    const rounds = getActiveMemoryMatchRounds();
    const roundData = rounds[gameRound % rounds.length];

    const heading = document.createElement('h3');
    heading.className = 'game-prompt-title';
    heading.textContent = 'Remember the sequence:';

    const revealStrip = document.createElement('div');
    revealStrip.className = 'memory-reveal-strip';

    roundData.display.forEach(item => {
      const box = document.createElement('div');
      box.className = 'memory-card-box';
      box.textContent = item;
      revealStrip.appendChild(box);
    });

    const timerBar = document.createElement('div');
    timerBar.innerHTML = `<span class="countdown-text">Cards will turn in 2 seconds...</span>`;

    container.appendChild(heading);
    container.appendChild(revealStrip);
    container.appendChild(timerBar);

    setTimeout(() => {
      heading.textContent = 'Which sequence did you see?';
      timerBar.remove();

      const boxes = container.querySelectorAll('.memory-card-box');
      boxes.forEach(b => {
        b.classList.add('hidden-card');
        b.textContent = '—';
      });

      const grid = document.createElement('div');
      grid.className = 'game-options-row';

      roundData.options.forEach(opt => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'game-choice-btn';
        btn.textContent = opt;
        btn.addEventListener('click', () => {
          handleGameChoice(btn, opt === roundData.correct);
        });
        grid.appendChild(btn);
      });

      container.appendChild(grid);
    }, 2000);
  }

  function renderSequenceStage(container) {
    const rounds = getActiveSequenceRounds();
    const roundData = rounds[gameRound % rounds.length];

    const heading = document.createElement('h3');
    heading.className = 'game-prompt-title';
    heading.textContent = roundData.prompt;

    const visual = document.createElement('div');
    visual.className = 'game-prompt-visual';
    visual.style.letterSpacing = '0.12em';
    visual.style.fontWeight = '700';
    visual.style.fontSize = '1.8rem';
    visual.style.color = 'var(--primary-blue)';
    visual.textContent = roundData.sequence;

    const grid = document.createElement('div');
    grid.className = 'game-options-row';

    roundData.options.forEach(opt => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'game-choice-btn';
      btn.textContent = opt;

      btn.addEventListener('click', () => {
        handleGameChoice(btn, opt === roundData.correct);
      });

      grid.appendChild(btn);
    });

    container.appendChild(heading);
    container.appendChild(visual);
    container.appendChild(grid);
  }

  function handleGameChoice(buttonEl, isCorrect) {
    const allBtns = document.querySelectorAll('.game-choice-btn');
    allBtns.forEach(b => b.style.pointerEvents = 'none');

    if (isCorrect) {
      buttonEl.style.backgroundColor = 'var(--primary-blue)';
      buttonEl.style.color = '#FFFFFF';
      buttonEl.style.borderColor = 'var(--primary-blue)';
      gameScore += 1;
      showToast('Correct selection.');
    } else {
      buttonEl.style.backgroundColor = '#E5E7EB';
      buttonEl.style.borderColor = '#9CA3AF';
      showToast('Completed. Moving to next.');
    }

    setTimeout(() => {
      gameRound += 1;
      renderGameRound();
    }, 550);
  }

  function finishGame() {
    const stage = document.getElementById('game-stage-container');
    stage.classList.add('hidden');

    const celeb = document.getElementById('game-celebration-screen');
    celeb.classList.remove('hidden');

    const pct = Math.round((gameScore / GAME_TOTAL_ROUNDS) * 100);
    document.getElementById('celebration-message').textContent = `You completed ${gameScore} out of ${GAME_TOTAL_ROUNDS} challenges.`;
    document.getElementById('celebration-score-pill').textContent = `Activity Score: ${pct}%`;

    // Adaptive difficulty calibration based on performance
    const diffBadge = document.getElementById('game-difficulty-badge');
    const alertEl = document.getElementById('game-diff-adjusted-alert');
    if (gameScore >= 4) {
      if (gameDifficulty === 'easy') gameDifficulty = 'medium';
      else if (gameDifficulty === 'medium') gameDifficulty = 'hard';
      if (alertEl) {
        alertEl.textContent = `Difficulty adjusted for you (Current Level: ${gameDifficulty.toUpperCase()}).`;
        alertEl.classList.remove('hidden');
      }
    } else if (gameScore <= 1) {
      if (gameDifficulty === 'hard') gameDifficulty = 'medium';
      else if (gameDifficulty === 'medium') gameDifficulty = 'easy';
      if (alertEl) {
        alertEl.textContent = `Difficulty adjusted for you (Current Level: ${gameDifficulty.toUpperCase()}).`;
        alertEl.classList.remove('hidden');
      }
    }
    if (diffBadge) diffBadge.textContent = `Level: ${gameDifficulty.toUpperCase()}`;

    recordGameCompletion(activeGame, gameScore, GAME_TOTAL_ROUNDS);
  }

  function recordGameCompletion(gameKey, score, total) {
    const progress = getProgress() || generateDemoData().progress;
    progress.activitiesCompleted = (progress.activitiesCompleted || 0) + 1;

    const gameNames = {
      'sound-match': 'Sound Match',
      'memory-match': 'Memory Match',
      'sequence-challenge': 'Sequence Challenge'
    };

    const newHistoryItem = {
      date: 'Just now',
      activity: gameNames[gameKey] || 'Interactive Practice',
      category: gameKey.replace('-', ' '),
      score: `${score}/${total}`,
      status: 'Completed'
    };

    progress.history = [newHistoryItem, ...(progress.history || [])];
    saveProgress(progress);
    showToast('Activity saved to progress records.');

    // Asynchronously sync with backend database
    const profile = getProfile();
    syncWithBackend('activities', {
      childId: (profile && profile.name) || 'current-learner',
      activityName: gameNames[gameKey] || 'Interactive Practice',
      skill: gameKey.replace('-', ' '),
      difficulty: typeof gameDifficulty !== 'undefined' ? (gameDifficulty.charAt(0).toUpperCase() + gameDifficulty.slice(1)) : 'Medium',
      score: score,
      accuracy: Math.round((score / (total || 1)) * 100),
      attempts: 1,
      responseTime: 3.5
    });
  }

  // ==========================================================================
  // 12. PROGRESS DASHBOARD CONTROLLER
  // ==========================================================================
  function updateProgressWithScreening(screeningResult) {
    const progress = getProgress() || generateDemoData().progress;
    progress.latestScore = screeningResult.score;
    progress.activitiesCompleted = (progress.activitiesCompleted || 0) + 1;
    progress.categoryScores = screeningResult.categoryScores || progress.categoryScores;

    const newHistory = {
      date: 'Today',
      activity: 'Full Screening Assessment',
      category: 'Learning Screening',
      score: `${screeningResult.score}%`,
      status: screeningResult.level || 'Completed'
    };

    progress.history = [newHistory, ...(progress.history || [])];
    saveProgress(progress);
  }

  function renderProgressDashboard() {
    const profile = getProfile();
    const screening = getScreening();
    const progress = getProgress();

    const emptyContainer = document.getElementById('empty-progress-state');
    const contentContainer = document.getElementById('dashboard-content');

    if (!profile && !screening && !progress) {
      if (emptyContainer) emptyContainer.classList.remove('hidden');
      if (contentContainer) contentContainer.classList.add('hidden');
      return;
    }

    if (emptyContainer) emptyContainer.classList.add('hidden');
    if (contentContainer) contentContainer.classList.remove('hidden');

    const activeProfile = profile || {
      name: 'Aarav',
      age: '8',
      grade: 'Class 3',
      language: 'English',
      role: 'Parent'
    };

    const nameEl = document.getElementById('dash-child-name');
    const ageEl = document.getElementById('dash-child-age');
    const gradeEl = document.getElementById('dash-child-grade');
    const langEl = document.getElementById('dash-child-lang');
    const roleEl = document.getElementById('dash-profile-role');
    const demoBadge = document.getElementById('dash-demo-indicator');

    if (nameEl) nameEl.textContent = activeProfile.name;
    if (ageEl) ageEl.textContent = activeProfile.age;
    if (gradeEl) gradeEl.textContent = activeProfile.grade;
    if (langEl) langEl.textContent = activeProfile.language;
    if (roleEl) roleEl.textContent = activeProfile.role ? `${activeProfile.role} Observation` : 'Parent Observation';

    if (demoBadge) {
      if (progress && progress.isDemo) demoBadge.classList.remove('hidden');
      else demoBadge.classList.add('hidden');
    }

    const statScore = document.getElementById('stat-latest-score');
    const statCompleted = document.getElementById('stat-completed-activities');
    const statStreak = document.getElementById('stat-streak-days');
    const statSkills = document.getElementById('stat-skills-practiced');

    const latest = (screening && screening.score) || (progress && progress.latestScore) || 78;
    const completedCount = (progress && progress.activitiesCompleted) || 24;
    const streakDays = (progress && progress.streakDays) || 5;

    if (statScore) statScore.textContent = `${latest}%`;
    if (statCompleted) statCompleted.textContent = completedCount;
    if (statStreak) statStreak.textContent = `${streakDays} days`;
    if (statSkills) statSkills.textContent = '4 / 6';

    const catScores = (screening && screening.categoryScores) || (progress && progress.categoryScores) || {
      'Phonological Awareness': 80,
      'Letter Recognition': 90,
      'Working Memory': 60,
      'Sequencing': 70,
      'Reading Patterns': 80
    };

    updateProgressBars(catScores);

    // Update dynamic weekly activity chart
    const daysArr = [
      { key: "mon", label: "Mon", index: 1 },
      { key: "tue", label: "Tue", index: 2 },
      { key: "wed", label: "Wed", index: 3 },
      { key: "thu", label: "Thu", index: 4 },
      { key: "fri", label: "Fri", index: 5 },
      { key: "sat", label: "Sat", index: 6 },
      { key: "sun", label: "Sun", index: 0 }
    ];

    const weekly = (progress && progress.weeklyActivity) || { mon: 2, tue: 3, wed: 1, thu: 4, fri: 3, sat: 2, sun: 0 };
    const todayIndex = new Date().getDay();
    const maxVal = Math.max(5, ...Object.values(weekly));

    const weeklyContainer = document.getElementById("weekly-chart-bars");
    if (weeklyContainer) {
      weeklyContainer.innerHTML = "";
      daysArr.forEach(d => {
        const count = weekly[d.key] || 0;
        const pctHeight = Math.min(100, Math.max(15, Math.round((count / maxVal) * 100)));
        const isToday = d.index === todayIndex;
        const col = document.createElement("div");
        col.className = `weekly-col ${isToday ? "active" : ""}`;
        col.innerHTML = `
          <div class="weekly-bar-track">
            <div class="weekly-bar-fill" style="height: ${pctHeight}%;" title="${d.label}: ${count} activities"></div>
          </div>
          <span class="weekly-day-label">${d.label}</span>
        `;
        weeklyContainer.appendChild(col);
      });
    }

    const historyList = (progress && progress.history) || [
      { date: 'Today', activity: 'Memory Match', category: 'Working Memory', score: '5/5', status: 'Completed' },
      { date: 'Yesterday', activity: 'Sound Match', category: 'Phonological', score: '4/5', status: 'Completed' },
      { date: '3 days ago', activity: 'Learning Skills Screening', category: 'Screening', score: '78%', status: 'Completed' },
      { date: '5 days ago', activity: 'Sequence Challenge', category: 'Sequencing', score: '5/5', status: 'Completed' }
    ];

    renderHistoryTable(historyList);
  }

  function updateProgressBars(scores) {
    const map = [
      { keys: ['Phonological Awareness', 'phonological'], valId: 'bar-val-phonological', fillId: 'bar-fill-phonological', def: 80 },
      { keys: ['Letter Recognition', 'letterRecognition', 'letter_recognition'], valId: 'bar-val-letter', fillId: 'bar-fill-letter', def: 90 },
      { keys: ['Working Memory', 'workingMemory', 'memory'], valId: 'bar-val-memory', fillId: 'bar-fill-memory', def: 60 },
      { keys: ['Sequencing', 'sequencing'], valId: 'bar-val-seq', fillId: 'bar-fill-seq', def: 70 },
      { keys: ['Reading Patterns', 'reading'], valId: 'bar-val-reading', fillId: 'bar-fill-reading', def: 80 }
    ];

    map.forEach(item => {
      let val = item.def;
      if (scores) {
        for (const k of item.keys) {
          if (scores[k] !== undefined) {
            val = scores[k];
            break;
          }
        }
      }
      const vEl = document.getElementById(item.valId);
      const fEl = document.getElementById(item.fillId);
      if (vEl) vEl.textContent = `${val}%`;
      if (fEl) fEl.style.width = `${val}%`;
    });
  }

  function renderHistoryTable(items) {
    const tbody = document.getElementById('history-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    items.forEach(it => {
      const tr = document.createElement('tr');
      const isScreening = it.activity.includes('Screening');
      const statusPillClass = isScreening ? 'status-pill screening' : 'status-pill completed';

      tr.innerHTML = `
        <td>${it.date}</td>
        <td><strong>${it.activity}</strong></td>
        <td>${it.category}</td>
        <td>${it.score}</td>
        <td><span class="${statusPillClass}">${it.status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // ==========================================================================
  // 13. DEMO DATA GENERATOR & RESET CONTROLLERS (ZERO EMOJIS)
  // ==========================================================================
  function generateDemoData() {
    const demoProfile = {
      name: 'Aarav',
      age: '8',
      grade: 'Class 3',
      language: 'English',
      role: 'Parent',
      createdAt: new Date().toISOString()
    };

    const demoScreening = {
      success: true,
      score: 78,
      level: 'Some Practice Recommended',
      supportTier: 'Some Practice Recommended',
      strengths: ['Letter Recognition', 'Rhyming', 'Phonological Awareness'],
      supportAreas: ['Working Memory', 'Sequencing'],
      recommendations: ['Memory Match', 'Sequence Challenge', 'Sound Match'],
      categoryScores: {
        'Phonological Awareness': 80,
        'Letter Recognition': 90,
        'Working Memory': 60,
        'Sequencing': 70,
        'Reading Patterns': 80,
        'Rhyming': 85,
        'Rapid Naming': 75
      },
      responseTimeAverage: 3.8,
      totalQuestions: 15,
      correctCount: 12,
      childProfile: demoProfile,
      disclaimer: 'LearnEase is an educational screening and learning-support tool and does not provide a medical diagnosis.'
    };

    const demoProgress = {
      isDemo: true,
      latestScore: 78,
      activitiesCompleted: 24,
      streakDays: 5,
      skillsPracticed: 4,
      categoryScores: demoScreening.categoryScores,
      history: [
        { date: 'Today', activity: 'Memory Match', category: 'Working Memory', score: '5/5', status: 'Completed' },
        { date: 'Yesterday', activity: 'Sound Match', category: 'Phonological', score: '4/5', status: 'Completed' },
        { date: '3 days ago', activity: 'Learning Skills Screening', category: 'Screening', score: '78%', status: 'Completed' },
        { date: '5 days ago', activity: 'Sequence Challenge', category: 'Sequencing', score: '5/5', status: 'Completed' },
        { date: '6 days ago', activity: 'Letter Recognition Hunt', category: 'Letter Recognition', score: '10/10', status: 'Completed' }
      ]
    };

    return { profile: demoProfile, screening: demoScreening, progress: demoProgress };
  }

  function loadDemoDataIntoStorage() {
    const demo = generateDemoData();
    saveProfile(demo.profile);
    saveScreening(demo.screening);
    saveProgress(demo.progress);
    showToast('Loaded demo screening & progress records.');
    renderProgressDashboard();
  }

  function resetAllData() {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.SCREENING);
    localStorage.removeItem(STORAGE_KEYS.PROGRESS);
    showToast('All progress and profile data reset.');
    switchView('home');
    renderProgressDashboard();
  }

  // ==========================================================================
  // 14. INITIALIZATION & EVENT LISTENERS
  // ==========================================================================
  document.addEventListener('DOMContentLoaded', () => {
    // Language selector
    const langSelect = document.getElementById('language-select');
    if (langSelect) {
      langSelect.value = currentLanguage;
      langSelect.addEventListener('change', (e) => {
        setLanguage(e.target.value);
      });
    }

    // Footer language links
    document.querySelectorAll('.footer-lang-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        setLanguage(btn.dataset.lang);
      });
    });

    // Navigation Links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetView = link.dataset.nav;
        window.location.hash = `#${targetView}`;
        switchView(targetView);
      });
    });

    // Brand Logo Button
    const brandBtn = document.getElementById('brand-logo-btn');
    if (brandBtn) {
      brandBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.hash = '#home';
        switchView('home');
      });
    }

    // Mobile Menu Toggle
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mainNav = document.getElementById('main-nav');
    if (mobileBtn && mainNav) {
      mobileBtn.addEventListener('click', () => {
        const isExpanded = mobileBtn.getAttribute('aria-expanded') === 'true';
        mobileBtn.setAttribute('aria-expanded', !isExpanded);
        mainNav.classList.toggle('mobile-active');
      });
    }

    // Start Screening Triggers
    const startBtns = [
      document.getElementById('nav-start-btn'),
      document.getElementById('hero-start-btn'),
      document.getElementById('bottom-start-btn'),
      document.getElementById('btn-empty-start-screening')
    ];
    startBtns.forEach(btn => {
      if (btn) btn.addEventListener('click', openOnboardingModal);
    });

    // Explore Learning Trigger
    const exploreBtn = document.getElementById('hero-explore-btn');
    if (exploreBtn) {
      exploreBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.hash = '#learn';
        switchView('learn');
      });
    }

    // Onboarding Modal controls
    const onboardingForm = document.getElementById('onboarding-form');
    if (onboardingForm) onboardingForm.addEventListener('submit', handleOnboardingSubmit);

    const closeOnboardingBtn = document.getElementById('btn-close-onboarding');
    if (closeOnboardingBtn) closeOnboardingBtn.addEventListener('click', closeOnboardingModal);

    const cancelOnboardingBtn = document.getElementById('btn-cancel-onboarding');
    if (cancelOnboardingBtn) cancelOnboardingBtn.addEventListener('click', closeOnboardingModal);

    // Screening Exit button
    const exitScreeningBtn = document.getElementById('btn-exit-screening');
    if (exitScreeningBtn) {
      exitScreeningBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to pause screening? Your progress will return to home.')) {
          window.location.hash = '#home';
          switchView('home');
        }
      });
    }

    // Screening Previous / Next Navigation Controls
    const prevQBtn = document.getElementById('btn-prev-question');
    const nextQBtn = document.getElementById('btn-next-question');
    if (prevQBtn) {
      prevQBtn.addEventListener('click', () => {
        if (currentQuestion > 0) {
          currentQuestion--;
          renderCurrentQuestion();
        }
      });
    }
    if (nextQBtn) {
      nextQBtn.addEventListener('click', () => {
        if (currentQuestion < questions.length - 1) {
          currentQuestion++;
          renderCurrentQuestion();
        } else {
          sendScreeningResults();
        }
      });
    }

    // Results Action buttons
    const viewProgBtn = document.getElementById('btn-view-progress-from-results');
    if (viewProgBtn) {
      viewProgBtn.addEventListener('click', () => {
        window.location.hash = '#progress';
        switchView('progress');
      });
    }

    const retakeBtn = document.getElementById('btn-retake-screening');
    if (retakeBtn) {
      retakeBtn.addEventListener('click', handleRetakeScreening);
    }

    const playRecBtn = document.getElementById('btn-play-recommended-direct');
    if (playRecBtn) {
      playRecBtn.addEventListener('click', () => {
        const screening = getScreening();
        const firstRec = (screening && screening.recommendations && screening.recommendations[0]) || 'Sound Match';
        const keyMap = {
          'Sound Match': 'sound-match',
          'Memory Match': 'memory-match',
          'Sequence Challenge': 'sequence-challenge',
          'Rhyming Practice': 'sound-match'
        };
        launchGame(keyMap[firstRec] || 'sound-match');
      });
    }

    // Learn Page Game Play Buttons
    document.querySelectorAll('.btn-play-game').forEach(btn => {
      btn.addEventListener('click', () => {
        launchGame(btn.dataset.game);
      });
    });

    // Game Arena Close & Replay Controls
    const closeGameBtn = document.getElementById('btn-close-game');
    if (closeGameBtn) {
      closeGameBtn.addEventListener('click', () => {
        document.getElementById('game-arena-overlay').classList.add('hidden');
      });
    }

    const replayBtn = document.getElementById('btn-replay-game');
    if (replayBtn) {
      replayBtn.addEventListener('click', () => {
        launchGame(activeGame || 'sound-match');
      });
    }

    const nextActivityBtn = document.getElementById('btn-next-activity');
    if (nextActivityBtn) {
      nextActivityBtn.addEventListener('click', () => {
        document.getElementById('game-arena-overlay').classList.add('hidden');
        window.location.hash = '#learn';
        switchView('learn');
      });
    }

    // Progress Dashboard Controls
    const toggleDemoBtn = document.getElementById('btn-toggle-demo');
    if (toggleDemoBtn) {
      toggleDemoBtn.addEventListener('click', loadDemoDataIntoStorage);
    }

    const editProfileBtn = document.getElementById('btn-edit-profile');
    if (editProfileBtn) {
      editProfileBtn.addEventListener('click', openOnboardingModal);
    }

    const resetDataBtn = document.getElementById('btn-reset-data');
    const resetModal = document.getElementById('reset-confirm-modal');
    const cancelResetBtn = document.getElementById('btn-cancel-reset');
    const confirmResetBtn = document.getElementById('btn-confirm-reset');

    if (resetDataBtn && resetModal) {
      resetDataBtn.addEventListener('click', () => {
        resetModal.classList.remove('hidden');
      });
    }
    if (cancelResetBtn && resetModal) {
      cancelResetBtn.addEventListener('click', () => {
        resetModal.classList.add('hidden');
      });
    }
    if (confirmResetBtn && resetModal) {
      confirmResetBtn.addEventListener('click', () => {
        resetModal.classList.add('hidden');
        resetAllData();
      });
    }

    // Service Worker & Offline Capability
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js').catch(err => {
          console.warn('Service worker registration skipped:', err);
        });
      });
    }

    // Network connectivity status handler
    function updateNetworkStatus() {
      const pill = document.getElementById('network-status-pill');
      const text = document.getElementById('network-status-text');
      if (!pill || !text) return;
      if (navigator.onLine) {
        pill.className = 'network-status-indicator online';
        text.textContent = 'Online';
      } else {
        pill.className = 'network-status-indicator offline';
        text.textContent = 'Offline Mode';
        showToast('Offline Mode: Learning activities remain fully accessible.');
      }
    }
    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    updateNetworkStatus();

    // PWA installation prompt handler
    let deferredInstallPrompt = null;
    const installBtn = document.getElementById('btn-install-pwa');
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredInstallPrompt = e;
      if (installBtn) {
        installBtn.classList.remove('hidden');
        installBtn.addEventListener('click', async () => {
          if (deferredInstallPrompt) {
            deferredInstallPrompt.prompt();
            const result = await deferredInstallPrompt.userChoice;
            if (result.outcome === 'accepted') {
              showToast('LearnEase installed successfully!');
            }
            deferredInstallPrompt = null;
            installBtn.classList.add('hidden');
          }
        });
      }
    });

    applyTranslations();
    
    // ==========================================================================
    // 14. AI + HUMAN LEARNING SUPPORT ECOSYSTEM IMPLEMENTATION
    // ==========================================================================

    // --- Storage Helpers & Seeding ---
    function getStoredProfiles() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.TEACHER_PROFILES);
        return raw ? JSON.parse(raw) : null;
      } catch (e) {
        return null;
      }
    }

    function saveStoredProfiles(profiles) {
      try {
        localStorage.setItem(STORAGE_KEYS.TEACHER_PROFILES, JSON.stringify(profiles));
      } catch (e) {
        console.error("Error saving teacher profiles:", e);
      }
    }

    function getStoredSessions() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    function saveStoredSessions(sessions) {
      try {
        localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
      } catch (e) {
        console.error("Error saving sessions:", e);
      }
    }

    function getStoredSessionNotes() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.SESSION_NOTES);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    function saveStoredSessionNotes(notes) {
      try {
        localStorage.setItem(STORAGE_KEYS.SESSION_NOTES, JSON.stringify(notes));
      } catch (e) {
        console.error("Error saving session notes:", e);
      }
    }

    const DEFAULT_SPECIALISTS = [
      {
        id: "spec-ananya",
        name: "Ananya Rao",
        role: "Learning Support Specialist",
        qualification: "M.Ed (Special Education)",
        institution: "National Institute of Mental Health",
        experience: "7+ Years Experience",
        languages: ["English", "Tamil"],
        specializations: ["Reading Support", "Phonological Awareness"],
        availability: "Weekdays & Sat (10:00 AM - 4:00 PM)",
        verificationStatus: "Verified by LearnEase",
        bio: "Specializes in early phonological interventions and multi-sensory reading support for primary grade bilingual learners."
      },
      {
        id: "spec-rajesh",
        name: "Dr. Rajesh Sharma",
        role: "Cognitive Interventionist & Educational Consultant",
        qualification: "Ph.D. / M.Ed",
        institution: "Delhi University / NCERT",
        experience: "12+ Years Experience",
        languages: ["English", "Hindi"],
        specializations: ["Working Memory", "Sequencing", "Reading Support"],
        availability: "Tue - Sun (11:00 AM - 5:00 PM)",
        verificationStatus: "Verified by LearnEase",
        bio: "Pioneer in structured working memory exercises and sequential cognitive rehearsal for children with learning differences."
      },
      {
        id: "spec-priya",
        name: "Priya Sundaram",
        role: "Certified Dyslexia & Literacy Coach",
        qualification: "B.Ed (Special Education)",
        institution: "Madras Dyslexia Association (MDA)",
        experience: "5+ Years Experience",
        languages: ["English", "Tamil"],
        specializations: ["Letter Reversals", "Phonological Awareness"],
        availability: "Mon - Fri (2:00 PM - 7:00 PM)",
        verificationStatus: "Credentials Submitted",
        bio: "Passionate about multi-sensory Tamil-English phonetic scaffolding and structured kinesthetic letter recognition."
      },
      {
        id: "spec-amit",
        name: "Amit Verma",
        role: "Primary Remedial Educator",
        qualification: "M.A. Applied Psychology & B.Ed",
        institution: "Tata Institute of Social Sciences (TISS)",
        experience: "4+ Years Experience",
        languages: ["English", "Hindi"],
        specializations: ["Rapid Naming", "Reading Support", "Sequencing"],
        availability: "Weekends (9:00 AM - 2:00 PM)",
        verificationStatus: "Pending Verification",
        bio: "Focuses on building retrieval fluency, positive emotional resilience, and low-anxiety home learning routines."
      }
    ];

    function seedEcosystemData() {
      if (!getStoredProfiles() || getStoredProfiles().length === 0) {
        saveStoredProfiles(DEFAULT_SPECIALISTS);
      }
      if (getStoredSessions().length === 0) {
        saveStoredSessions([
          {
            id: "sess-default-1",
            learnerName: "Aarav Patel",
            specialistId: "spec-ananya",
            specialistName: "Ananya Rao, M.Ed",
            date: "Upcoming Saturday",
            time: "10:30 AM",
            duration: "30 minutes",
            language: "English / Tamil",
            status: "Confirmed",
            consentGranted: true,
            focus: "Working Memory & Sequencing"
          }
        ]);
      }
      if (getStoredSessionNotes().length === 0) {
        saveStoredSessionNotes([
          {
            id: "note-default-1",
            date: "Sept 10, 2026",
            learnerName: "Aarav Patel",
            specialistName: "Ananya Rao, M.Ed",
            activities: ["Sound Match", "Memory Match"],
            strengths: "High engagement with auditory cues and phonological matching.",
            difficulties: "Slight hesitation during 4-item sequence recall.",
            observations: "Learner showed strong positive response to multi-sensory color-coded cues. Receptive to rhythmic breakdown of phonemes.",
            homePractice: "Memory Match — 10 minutes daily",
            nextFocus: "Working Memory & Visual Sequencing"
          }
        ]);
      }
    }

    seedEcosystemData();

    // --- Smart Match Score Calculator ---
    function calculateSpecialistMatch(spec, learnerProfile, screeningData) {
      let score = 70;
      let reasons = [];

      const targetLang = (learnerProfile && learnerProfile.language === "ta") ? "Tamil" :
                         (learnerProfile && learnerProfile.language === "hi") ? "Hindi" : "English";

      if (spec.languages.includes(targetLang)) {
        score += 15;
        reasons.push(`${targetLang} session instruction available`);
      }

      // Check screening deficit match
      let lowestCat = "workingMemory";
      if (screeningData && screeningData.categoryScores) {
        const sorted = Object.entries(screeningData.categoryScores).sort((a,b) => a[1] - b[1]);
        if (sorted[0]) lowestCat = sorted[0][0];
      }

      const catKeywordMap = {
        workingMemory: "Working Memory",
        sequencing: "Sequencing",
        phonological: "Phonological Awareness",
        rhyming: "Reading Support",
        reading: "Reading Support",
        letterRecognition: "Letter Reversals",
        rapidNaming: "Rapid Naming"
      };

      const neededSpec = catKeywordMap[lowestCat] || "Reading Support";
      if (spec.specializations.includes(neededSpec)) {
        score += 10;
        reasons.push(`Specializes in prioritized ${neededSpec} practice`);
      }

      if (spec.verificationStatus === "Verified by LearnEase") {
        score += 5;
      }

      score = Math.min(score, 96);
      if (reasons.length === 0) {
        reasons.push("Experience with multi-sensory primary learning support");
      }

      return { score, reasons };
    }

    // --- Specialists Directory Rendering ---
    window.renderSpecialistsDirectory = function() {
      const grid = document.getElementById("specialist-cards-grid");
      if (!grid) return;

      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
      const profile = getChildProfile();
      const screening = getScreeningResult();

      const searchVal = (document.getElementById("specialist-search-input")?.value || "").toLowerCase().trim();
      const langVal = document.getElementById("filter-language")?.value || "all";
      const specVal = document.getElementById("filter-specialization")?.value || "all";
      const qualVal = document.getElementById("filter-qualification")?.value || "all";
      const verifiedOnly = document.getElementById("filter-verified-only")?.checked || false;

      // Filter
      const filtered = profiles.filter(s => {
        if (searchVal) {
          const matchName = s.name.toLowerCase().includes(searchVal);
          const matchRole = s.role.toLowerCase().includes(searchVal);
          const matchQual = s.qualification.toLowerCase().includes(searchVal);
          const matchSpec = s.specializations.some(sp => sp.toLowerCase().includes(searchVal));
          if (!matchName && !matchRole && !matchQual && !matchSpec) return false;
        }
        if (langVal !== "all" && !s.languages.includes(langVal)) return false;
        if (specVal !== "all" && !s.specializations.includes(specVal)) return false;
        if (qualVal !== "all" && !s.qualification.includes(qualVal)) return false;
        if (verifiedOnly && s.verificationStatus !== "Verified by LearnEase") return false;
        return true;
      });

      // Calculate matches
      let bestMatch = null;
      let highestScore = -1;

      filtered.forEach(s => {
        const match = calculateSpecialistMatch(s, profile, screening);
        s._match = match;
        if (match.score > highestScore) {
          highestScore = match.score;
          bestMatch = s;
        }
      });

      // Update banner
      const bannerScore = document.getElementById("directory-match-score-pill");
      const bannerReason = document.getElementById("directory-match-reason-col");
      if (bestMatch && bannerScore && bannerReason) {
        bannerScore.textContent = `Match: ${bestMatch._match.score}%`;
        bannerReason.innerHTML = `<strong>Best match for ${profile?.name || "learner"}:</strong> ${bestMatch.name} (${bestMatch.role}) — ${bestMatch._match.reasons.join(", ")}.`;
      }

      grid.innerHTML = "";

      if (filtered.length === 0) {
        grid.innerHTML = `
          <div class="no-results-msg" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-muted);">
            <p>No specialists match the selected criteria. Try adjusting your filters.</p>
          </div>
        `;
        return;
      }

      filtered.forEach(s => {
        const isBest = (bestMatch && bestMatch.id === s.id);
        const card = document.createElement("div");
        card.className = `specialist-card ${isBest ? "is-best-match" : ""}`;

        const statusClass = s.verificationStatus === "Verified by LearnEase" ? "verified" :
                            s.verificationStatus === "Pending Verification" ? "pending" : "submitted";

        card.innerHTML = `
          <div>
            <div class="specialist-card-header">
              <div>
                ${isBest ? `<span class="best-match-pill">Best Match &bull; ${s._match.score}%</span>` : ""}
                <h3 class="spec-name">${s.name}</h3>
                <p class="spec-role">${s.role}</p>
                <div class="spec-qual-line">${s.qualification} &bull; ${s.institution}</div>
              </div>
              <span class="verification-tag ${statusClass}">
                <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 8 7 12 13 4"/></svg>
                ${s.verificationStatus}
              </span>
            </div>

            <div class="spec-details-list">
              <div class="spec-detail-row">
                <span class="detail-lbl">Experience:</span>
                <span class="detail-val">${s.experience}</span>
              </div>
              <div class="spec-detail-row">
                <span class="detail-lbl">Languages:</span>
                <span class="detail-val">${s.languages.join(" &bull; ")}</span>
              </div>
              <div class="spec-detail-row">
                <span class="detail-lbl">Availability:</span>
                <span class="detail-val">${s.availability}</span>
              </div>
            </div>

            <div class="spec-skills-pills">
              ${s.specializations.map(sp => `<span class="spec-skill-tag">${sp}</span>`).join("")}
            </div>
          </div>

          <div class="spec-footer-wrap">
            <div class="spec-actions-row">
              <button type="button" class="btn btn-secondary btn-sm btn-spec-view-profile" data-id="${s.id}">View Profile</button>
              <button type="button" class="btn btn-primary btn-sm btn-spec-book-session" data-id="${s.id}">Book Session</button>
            </div>
            <button type="button" class="btn-admin-verify-card" data-id="${s.id}">
              Admin: Toggle Verification Status
            </button>
          </div>
        `;

        grid.appendChild(card);
      });

      // Wire buttons
      grid.querySelectorAll(".btn-spec-view-profile").forEach(btn => {
        btn.addEventListener("click", () => openSpecialistProfileModal(btn.dataset.id));
      });
      grid.querySelectorAll(".btn-spec-book-session").forEach(btn => {
        btn.addEventListener("click", () => openBookingModal(btn.dataset.id));
      });
      grid.querySelectorAll(".btn-admin-verify-card").forEach(btn => {
        btn.addEventListener("click", () => toggleSpecialistVerification(btn.dataset.id));
      });
    };

    function toggleSpecialistVerification(specId) {
      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
      const target = profiles.find(p => p.id === specId);
      if (target) {
        if (target.verificationStatus === "Verified by LearnEase") {
          target.verificationStatus = "Pending Verification";
        } else {
          target.verificationStatus = "Verified by LearnEase";
        }
        saveStoredProfiles(profiles);
        renderSpecialistsDirectory();
        showToast(`Verification status updated for ${target.name}: "${target.verificationStatus}"`);
      }
    }

    // Toggle all admin verify
    const adminToggleAllBtn = document.getElementById("btn-toggle-admin-verify");
    if (adminToggleAllBtn) {
      adminToggleAllBtn.addEventListener("click", () => {
        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        const allVerified = profiles.every(p => p.verificationStatus === "Verified by LearnEase");
        profiles.forEach(p => {
          p.verificationStatus = allVerified ? "Pending Verification" : "Verified by LearnEase";
        });
        saveStoredProfiles(profiles);
        renderSpecialistsDirectory();
        showToast(allVerified ? "Profiles reset to Pending Verification" : "All profiles marked Verified by LearnEase!");
      });
    }

    // Filter listeners
    ["specialist-search-input", "filter-language", "filter-specialization", "filter-qualification", "filter-verified-only"].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", renderSpecialistsDirectory);
        el.addEventListener("change", renderSpecialistsDirectory);
      }
    });

    const quickBookBestBtn = document.getElementById("btn-quick-book-best-match");
    if (quickBookBestBtn) {
      quickBookBestBtn.addEventListener("click", () => {
        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        const best = profiles[0];
        if (best) openBookingModal(best.id);
      });
    }

    // --- Specialist Profile Modal ---
    function openSpecialistProfileModal(specId) {
      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
      const s = profiles.find(p => p.id === specId) || profiles[0];
      const modal = document.getElementById("specialist-profile-modal");
      const nameEl = document.getElementById("prof-modal-name");
      const roleEl = document.getElementById("prof-modal-role");
      const bodyEl = document.getElementById("prof-modal-body");
      const bookBtn = document.getElementById("btn-prof-book");

      if (!modal || !s) return;

      if (nameEl) nameEl.textContent = s.name;
      if (roleEl) roleEl.textContent = `${s.role} • ${s.qualification}`;
      if (bodyEl) {
        bodyEl.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 14px; margin-bottom: 20px;">
            <p style="font-size: 0.95rem; color: var(--text-dark); line-height: 1.6;">${s.bio || "Dedicated special educator helping young learners build literacy and memory confidence."}</p>
            <div style="background-color: var(--bg-subtle); padding: 16px; border-radius: 8px; border: 1px solid var(--border-color);">
              <h4 style="font-size: 0.85rem; font-weight: 700; color: var(--text-dark); margin-bottom: 8px;">Credential Summary:</h4>
              <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.85rem; color: var(--text-muted); display: flex; flex-direction: column; gap: 6px;">
                <li>• Degree: <strong>${s.qualification}</strong> (${s.institution})</li>
                <li>• Experience: <strong>${s.experience}</strong> in educational support</li>
                <li>• Languages: <strong>${s.languages.join(", ")}</strong></li>
                <li>• Status: <strong style="color: #059669;">${s.verificationStatus}</strong></li>
              </ul>
            </div>
            <div style="font-size: 0.82rem; color: var(--text-muted); line-height: 1.5;">
              Sessions are conducted in the secure LearnEase Virtual Learning Room with interactive whiteboard, multi-sensory phonics cards, and parent oversight.
            </div>
          </div>
        `;
      }

      if (bookBtn) {
        bookBtn.onclick = () => {
          modal.classList.add("hidden");
          openBookingModal(s.id);
        };
      }

      modal.classList.remove("hidden");
    }

    const closeProfBtn = document.getElementById("btn-close-prof-modal");
    const closeProfBtn2 = document.getElementById("btn-prof-close");
    if (closeProfBtn) closeProfBtn.addEventListener("click", () => document.getElementById("specialist-profile-modal")?.classList.add("hidden"));
    if (closeProfBtn2) closeProfBtn2.addEventListener("click", () => document.getElementById("specialist-profile-modal")?.classList.add("hidden"));

    // --- Teacher Onboarding Workflow ---
    const openTeacherOnboardBtn = document.getElementById("btn-open-teacher-onboarding");
    const teacherOnboardModal = document.getElementById("teacher-onboarding-modal");
    const closeTeacherOnboardBtn = document.getElementById("btn-close-teacher-onboard");
    const cancelTeacherOnboardBtn = document.getElementById("btn-cancel-teacher-onboard");
    const teacherOnboardForm = document.getElementById("teacher-onboard-form");

    if (openTeacherOnboardBtn && teacherOnboardModal) {
      openTeacherOnboardBtn.addEventListener("click", () => {
        teacherOnboardModal.classList.remove("hidden");
      });
    }
    if (closeTeacherOnboardBtn && teacherOnboardModal) {
      closeTeacherOnboardBtn.addEventListener("click", () => teacherOnboardModal.classList.add("hidden"));
    }
    if (cancelTeacherOnboardBtn && teacherOnboardModal) {
      cancelTeacherOnboardBtn.addEventListener("click", () => teacherOnboardModal.classList.add("hidden"));
    }

    if (teacherOnboardForm) {
      teacherOnboardForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = document.getElementById("teacher-name-input")?.value.trim();
        const role = document.getElementById("teacher-role-input")?.value.trim();
        const qual = document.getElementById("teacher-qualification-input")?.value;
        const inst = document.getElementById("teacher-institution-input")?.value.trim() || "State University";
        const exp = document.getElementById("teacher-exp-input")?.value || "5-7 Years";
        const avail = document.getElementById("teacher-avail-input")?.value.trim() || "Weekdays (10 AM - 4 PM)";

        if (!name || !role) {
          showToast("Please provide your name and professional role.");
          return;
        }

        const langs = Array.from(document.querySelectorAll("input[name='teacherLang']:checked")).map(cb => cb.value);
        const specs = Array.from(document.querySelectorAll("input[name='teacherSpec']:checked")).map(cb => cb.value);

        const newProfile = {
          id: "spec-" + Date.now(),
          name,
          role,
          qualification: qual,
          institution: inst,
          experience: exp,
          languages: langs.length ? langs : ["English"],
          specializations: specs.length ? specs : ["Reading Support"],
          availability: avail,
          verificationStatus: "Pending Verification",
          bio: `Educator committed to accessible learning support and individualized student scaffolding.`
        };

        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        profiles.unshift(newProfile);
        saveStoredProfiles(profiles);

        // Asynchronously sync with backend database
        syncWithBackend('teachers', {
          name: newProfile.name,
          qualification: newProfile.qualification,
          institution: newProfile.institution,
          experience: newProfile.experience,
          specializations: newProfile.specializations,
          languages: newProfile.languages,
          availability: newProfile.availability,
          credentialStatus: 'submitted'
        });

        teacherOnboardModal.classList.add("hidden");
        teacherOnboardForm.reset();
        renderSpecialistsDirectory();
        showToast("Credentials submitted! Status marked as 'Pending Verification'.");
      });
    }

    // --- Session Booking & Mandatory Parent Consent ---
    function openBookingModal(specialistId) {
      const modal = document.getElementById("booking-modal");
      const specSelect = document.getElementById("booking-specialist-select");
      const dateInput = document.getElementById("booking-date-input");
      if (!modal || !specSelect) return;

      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
      specSelect.innerHTML = "";
      profiles.forEach(s => {
        const opt = document.createElement("option");
        opt.value = s.id;
        opt.textContent = `${s.name} (${s.role} — ${s.verificationStatus})`;
        if (s.id === specialistId) opt.selected = true;
        specSelect.appendChild(opt);
      });

      // Default tomorrow's date
      if (dateInput) {
        const tom = new Date();
        tom.setDate(tom.getDate() + 1);
        dateInput.value = tom.toISOString().split("T")[0];
      }

      const consentBox = document.getElementById("booking-parent-consent");
      if (consentBox) consentBox.checked = false;
      const consentErr = document.getElementById("booking-consent-error");
      if (consentErr) consentErr.classList.add("hidden");

      modal.classList.remove("hidden");
    }

    const closeBookingBtn = document.getElementById("btn-close-booking");
    const cancelBookingBtn = document.getElementById("btn-cancel-booking");
    const bookingForm = document.getElementById("booking-form");

    if (closeBookingBtn) closeBookingBtn.addEventListener("click", () => document.getElementById("booking-modal")?.classList.add("hidden"));
    if (cancelBookingBtn) cancelBookingBtn.addEventListener("click", () => document.getElementById("booking-modal")?.classList.add("hidden"));

    if (bookingForm) {
      bookingForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const consentBox = document.getElementById("booking-parent-consent");
        const consentErr = document.getElementById("booking-consent-error");

        if (!consentBox || !consentBox.checked) {
          if (consentErr) consentErr.classList.remove("hidden");
          showToast("Parent/guardian consent is mandatory to schedule a session.");
          return;
        }
        if (consentErr) consentErr.classList.add("hidden");

        const specId = document.getElementById("booking-specialist-select")?.value;
        const date = document.getElementById("booking-date-input")?.value;
        const time = document.getElementById("booking-time-select")?.value;
        const lang = document.getElementById("booking-language-select")?.value;
        const dur = document.getElementById("booking-duration-select")?.value;

        if (!date) {
          showToast("Please select a valid session date.");
          return;
        }

        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        const selectedSpec = profiles.find(p => p.id === specId) || profiles[0];
        const childProfile = getChildProfile();

        const newSession = {
          id: "sess-" + Date.now(),
          learnerName: childProfile?.name || "Aarav Patel",
          childName: childProfile?.name || "Aarav Patel",
          specialistId: selectedSpec.id,
          specialistName: selectedSpec.name,
          teacherName: selectedSpec.name,
          date: date || "Upcoming",
          time: time || "11:30 AM",
          duration: dur || "30 minutes",
          language: lang || "English",
          status: "Confirmed",
          consentGranted: true,
          focus: (selectedSpec.specializations && selectedSpec.specializations[0]) || "Working Memory & Sequencing"
        };

        // Sync with backend MongoDB
        try {
          const res = await fetch(`${BACKEND_BASE}/sessions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              childId: newSession.learnerName,
              childName: newSession.learnerName,
              teacherId: newSession.specialistId,
              teacherName: newSession.specialistName,
              date: `${newSession.date} ${newSession.time}`,
              duration: parseInt(newSession.duration, 10) || 30,
              language: newSession.language,
              status: 'scheduled',
              activities: [newSession.focus],
              consentGranted: true
            })
          });

          if (res.status === 409) {
            showToast("An active session already exists for this time.");
            return;
          } else if (res.status === 503) {
            console.warn('[LearnEase DB] Database offline, preserving session in client storage.');
          }
        } catch (netErr) {
          console.warn('[LearnEase DB] Network sync note:', netErr.message);
        }

        const sessions = getStoredSessions();
        const exists = sessions.some(s => (s.learnerName === newSession.learnerName || s.childName === newSession.learnerName) && (s.specialistName === newSession.specialistName || s.teacherName === newSession.specialistName) && s.date === newSession.date && s.time === newSession.time);
        if (!exists) {
          sessions.unshift(newSession);
          saveStoredSessions(sessions);
        }

        // Save consent flag
        localStorage.setItem(STORAGE_KEYS.TEACHER_CONSENT, JSON.stringify({
          consentGranted: true,
          timestamp: new Date().toISOString(),
          sessionId: newSession.id
        }));

        document.getElementById("booking-modal")?.classList.add("hidden");

        // Show Booking Confirmation Modal
        const confModal = document.getElementById("booking-confirmed-modal");
        if (confModal) {
          const confChild = document.getElementById("conf-child-name");
          const confSpec = document.getElementById("conf-specialist-name");
          const confDate = document.getElementById("conf-date");
          const confTime = document.getElementById("conf-time");
          const confDur = document.getElementById("conf-duration");
          const confLang = document.getElementById("conf-language");
          const confStatus = document.getElementById("conf-status");

          if (confChild) confChild.textContent = newSession.learnerName;
          if (confSpec) confSpec.textContent = newSession.specialistName;
          if (confDate) confDate.textContent = newSession.date;
          if (confTime) confTime.textContent = newSession.time;
          if (confDur) confDur.textContent = newSession.duration;
          if (confLang) confLang.textContent = newSession.language;
          if (confStatus) confStatus.textContent = "Scheduled";

          confModal.classList.remove("hidden");

          const closeConfBtn = document.getElementById("btn-close-confirmed");
          if (closeConfBtn) closeConfBtn.onclick = () => confModal.classList.add("hidden");

          const parentDashBtn = document.getElementById("btn-confirmed-parent-dash");
          if (parentDashBtn) {
            parentDashBtn.onclick = () => {
              confModal.classList.add("hidden");
              window.location.hash = "#parent";
              switchView("parent");
            };
          }

          const enterRoomBtn = document.getElementById("btn-confirmed-enter-room");
          if (enterRoomBtn) {
            enterRoomBtn.onclick = () => {
              confModal.classList.add("hidden");
              window.location.hash = "#virtual-room";
              switchView("virtual-room");
            };
          }
        }

        showToast(`Session booked with ${selectedSpec.name} for ${newSession.date} at ${newSession.time}!`);

        // Refresh UI in background
        if (typeof window.renderTeacherDashboard === 'function') window.renderTeacherDashboard();
        if (typeof renderParentDashboard === 'function') renderParentDashboard();
      });
    }

    // --- Virtual Learning Room Implementation ---
    let roomCountdownTimer = null;
    let roomSecondsRemaining = 28 * 60 + 45; // 28:45
    let localMediaStream = null;

    window.initVirtualRoom = function() {
      const child = getChildProfile();
      const sessions = getStoredSessions();
      const currentSess = sessions[0];

      const learnerNameEl = document.getElementById("room-learner-name");
      const specNameEl = document.getElementById("room-specialist-name");
      const placeChild = document.getElementById("placeholder-child-name");
      const placeSpec = document.getElementById("placeholder-specialist-name");

      const lName = child?.name || currentSess?.learnerName || "Aarav Patel";
      const sName = currentSess?.specialistName || "Ananya Rao, M.Ed";

      if (learnerNameEl) learnerNameEl.textContent = `${lName} (${child?.grade || "Class 3"})`;
      if (specNameEl) specNameEl.textContent = sName;
      if (placeChild) placeChild.textContent = lName;
      if (placeSpec) placeSpec.textContent = sName;

      // Reset timer
      clearInterval(roomCountdownTimer);
      roomSecondsRemaining = 28 * 60 + 45;
      updateRoomTimerDisplay();
      roomCountdownTimer = setInterval(() => {
        roomSecondsRemaining--;
        if (roomSecondsRemaining <= 0) {
          clearInterval(roomCountdownTimer);
          roomSecondsRemaining = 0;
          showToast("Session scheduled duration reached. Please record post-session notes.");
        }
        updateRoomTimerDisplay();
      }, 1000);

      // Populate Session Plan
      renderRoomSessionPlan();
      // Initialize Whiteboard
      initWhiteboard();
      // Update AI Co-Pilot
      updateAICoPilot();
    };

    function updateRoomTimerDisplay() {
      const el = document.getElementById("room-timer-display");
      if (!el) return;
      const m = Math.floor(roomSecondsRemaining / 60);
      const s = roomSecondsRemaining % 60;
      el.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }

    function renderRoomSessionPlan() {
      const list = document.getElementById("room-plan-steps-list");
      if (!list) return;

      const steps = [
        { time: "05 min", title: "Warm-up & Multi-Sensory Phonics", key: "sound-match" },
        { time: "10 min", title: "Targeted Working Memory Rehearsal", key: "memory-match" },
        { time: "10 min", title: "Visual & Numeric Sequencing", key: "sequence-challenge" },
        { time: "05 min", title: "Guided Reading & Review", key: "word-builder" }
      ];

      list.innerHTML = steps.map((st, i) => `
        <div class="plan-step-item">
          <span class="step-time-lbl">${st.time}</span>
          <span class="step-desc-lbl">${st.title}</span>
          <button type="button" class="btn btn-ghost btn-xs btn-launch-step" data-key="${st.key}">Start</button>
        </div>
      `).join("");

      list.querySelectorAll(".btn-launch-step").forEach(btn => {
        btn.addEventListener("click", () => {
          switchWorkspaceTab("game");
          const sel = document.getElementById("shared-game-select");
          if (sel) sel.value = btn.dataset.key;
          launchSharedRoomGame(btn.dataset.key, "medium");
        });
      });
    }

    // --- Interactive Whiteboard Canvas ---
    function initWhiteboard() {
      const canvas = document.getElementById("whiteboard-canvas");
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      let drawing = false;
      let currentColor = "#2563EB";
      let currentLineWidth = 3;
      let isEraser = false;

      function getPos(e) {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
          x: clientX - rect.left,
          y: clientY - rect.top
        };
      }

      function startDraw(e) {
        drawing = true;
        const pos = getPos(e);
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        e.preventDefault();
      }

      function draw(e) {
        if (!drawing) return;
        const pos = getPos(e);
        ctx.strokeStyle = isEraser ? "#FFFFFF" : currentColor;
        ctx.lineWidth = isEraser ? 16 : currentLineWidth;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        e.preventDefault();
      }

      function stopDraw() {
        drawing = false;
      }

      canvas.onmousedown = startDraw;
      canvas.onmousemove = draw;
      canvas.onmouseup = stopDraw;
      canvas.onmouseleave = stopDraw;

      canvas.ontouchstart = startDraw;
      canvas.ontouchmove = draw;
      canvas.ontouchend = stopDraw;

      const penBtn = document.getElementById("btn-wb-pen");
      const eraserBtn = document.getElementById("btn-wb-eraser");
      const clearBtn = document.getElementById("btn-clear-whiteboard");

      if (penBtn) {
        penBtn.onclick = () => {
          isEraser = false;
          penBtn.classList.add("active");
          eraserBtn?.classList.remove("active");
        };
      }
      if (eraserBtn) {
        eraserBtn.onclick = () => {
          isEraser = true;
          eraserBtn.classList.add("active");
          penBtn?.classList.remove("active");
        };
      }
      if (clearBtn) {
        clearBtn.onclick = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          showToast("Whiteboard cleared.");
        };
      }

      document.querySelectorAll(".wb-color-btn").forEach(btn => {
        btn.onclick = () => {
          document.querySelectorAll(".wb-color-btn").forEach(b => b.classList.remove("active"));
          btn.classList.add("active");
          currentColor = btn.dataset.color || "#2563EB";
          isEraser = false;
          penBtn?.classList.add("active");
          eraserBtn?.classList.remove("active");
        };
      });
    }

    // --- Virtual Room Workspace Navigation ---
    function switchWorkspaceTab(mode) {
      document.querySelectorAll(".workspace-header-tabs .tab-btn").forEach(b => {
        b.classList.toggle("active", b.dataset.workspace === mode);
      });
      const panelWhiteboard = document.getElementById("panel-whiteboard");
      const panelGame = document.getElementById("panel-game");
      const panelWord = document.getElementById("panel-word");
      const panelSeq = document.getElementById("panel-sequence");

      if (panelWhiteboard) panelWhiteboard.className = mode === "whiteboard" ? "workspace-panel active" : "workspace-panel hidden";
      if (panelGame) panelGame.className = mode === "game" ? "workspace-panel active" : "workspace-panel hidden";
      if (panelWord) panelWord.className = mode === "word" ? "workspace-panel active" : "workspace-panel hidden";
      if (panelSeq) panelSeq.className = mode === "sequence" ? "workspace-panel active" : "workspace-panel hidden";
    }

    document.querySelectorAll(".workspace-header-tabs .tab-btn").forEach(btn => {
      btn.addEventListener("click", () => switchWorkspaceTab(btn.dataset.workspace));
    });

    // --- Shared Practice Game Inside Room ---
    function launchSharedRoomGame(gameKey, difficulty) {
      const stage = document.getElementById("shared-game-arena-stage");
      if (!stage) return;

      const titles = {
        "sound-match": "Sound Match (Phonological Awareness)",
        "memory-match": "Memory Match (Working Memory)",
        "sequence-challenge": "Sequence Challenge",
        "word-builder": "Word Builder (Orthographic)",
        "rhyming-game": "Rhyming Practice"
      };

      stage.innerHTML = `
        <div style="width: 100%; text-align: center; padding: 20px; background-color: #0B0F14; border-radius: 8px;">
          <div style="font-size: 0.8rem; font-weight: 700; color: #60A5FA; text-transform: uppercase; margin-bottom: 6px;">
            Active Shared Session &bull; Level: ${difficulty.toUpperCase()}
          </div>
          <h3 style="font-size: 1.4rem; color: #FFFFFF; margin-bottom: 16px;">${titles[gameKey] || "Interactive Activity"}</h3>
          
          <div id="shared-sub-game-viewport" style="max-width: 480px; margin: 0 auto; background-color: #111827; padding: 24px; border-radius: 8px; border: 1px solid #1F2937;">
            <p style="color: #D1D5DB; font-size: 1.05rem; margin-bottom: 20px;">
              Teacher & Learner are solving this activity together.
            </p>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
              <button type="button" class="btn btn-primary btn-md" id="btn-complete-shared-round">Complete Challenge Round</button>
              <button type="button" class="btn btn-secondary btn-md" id="btn-next-shared-round">Next Item →</button>
            </div>
          </div>
        </div>
      `;

      const compBtn = document.getElementById("btn-complete-shared-round");
      if (compBtn) {
        compBtn.onclick = () => {
          // Add progress to child
          const prog = getProgressData();
          prog.practiceTimeMinutes = (prog.practiceTimeMinutes || 0) + 5;
          prog.activitiesCompleted = (prog.activitiesCompleted || 0) + 1;
          saveProgressData(prog);
          showToast(`Shared exercise "${titles[gameKey]}" completed! 5 mins practice logged.`);
          updateAICoPilot();
        };
      }
    }

    const launchSharedGameBtn = document.getElementById("btn-launch-shared-game");
    if (launchSharedGameBtn) {
      launchSharedGameBtn.addEventListener("click", () => {
        const gameKey = document.getElementById("shared-game-select")?.value || "sound-match";
        const diff = document.getElementById("shared-diff-select")?.value || "medium";
        launchSharedRoomGame(gameKey, diff);
      });
    }

    // --- Phonics Word Share Audio ---
    const speakWordBtn = document.getElementById("btn-room-speak-word");
    if (speakWordBtn) {
      speakWordBtn.addEventListener("click", () => {
        const wordEl = document.getElementById("room-phonics-word");
        const text = wordEl ? wordEl.textContent.replace(/•/g, "").trim() : "BAT";
        speakText(text, currentLanguage === "ta" ? "ta-IN" : currentLanguage === "hi" ? "hi-IN" : "en-IN");
      });
    }

    const nextWordBtn = document.getElementById("btn-room-next-word");
    const sampleWords = [
      { word: "C • A • T", sub: "Initial Consonant: /k/ • Vowel: /æ/ • Rime: -at" },
      { word: "S • U • N", sub: "Initial Consonant: /s/ • Vowel: /ʌ/ • Rime: -un" },
      { word: "P • E • N", sub: "Initial Consonant: /p/ • Vowel: /e/ • Rime: -en" },
      { word: "B • A • T", sub: "Initial Consonant: /b/ • Vowel: /æ/ • Rime: -at" }
    ];
    let wordIdx = 0;
    if (nextWordBtn) {
      nextWordBtn.addEventListener("click", () => {
        wordIdx = (wordIdx + 1) % sampleWords.length;
        const item = sampleWords[wordIdx];
        const wEl = document.getElementById("room-phonics-word");
        const sEl = document.getElementById("room-phonics-sub");
        if (wEl) wEl.textContent = item.word;
        if (sEl) sEl.textContent = item.sub;
      });
    }

    // Sequence choices in room
    document.querySelectorAll(".seq-choice-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        if (btn.dataset.val === "8") {
          showToast("Correct sequence match: 2 -> 4 -> 6 -> 8!");
          btn.style.backgroundColor = "#059669";
        } else {
          showToast("Try again: Look at the step interval of +2.");
        }
      });
    });

    // --- AI Teacher Co-Pilot Update ---
    function updateAICoPilot() {
      const screening = getScreeningResult();
      const notes = getStoredSessionNotes();
      const lastNote = notes[0];

      const focusEl = document.getElementById("copilot-focus");
      const actEl = document.getElementById("copilot-activity");
      const patEl = document.getElementById("copilot-pattern");
      const nextEl = document.getElementById("copilot-next-step");

      let focus = "Working Memory & Retrieval";
      let act = "Memory Match — Level 2";
      let pat = "Learner required additional attempts on sequence recall in initial rounds.";
      let next = "Use a shorter 3-item visual sequence before increasing difficulty.";

      if (lastNote) {
        focus = lastNote.nextFocus || focus;
        pat = `Previous session observation: ${lastNote.difficulties || pat}`;
        next = `Teacher recommendation: ${lastNote.homePractice || next}`;
      } else if (screening && screening.supportAreas && screening.supportAreas.length > 0) {
        focus = screening.supportAreas[0];
        act = `${focus} Guided Exercise`;
      }

      if (focusEl) focusEl.textContent = focus;
      if (actEl) actEl.textContent = act;
      if (patEl) patEl.textContent = pat;
      if (nextEl) nextEl.textContent = next;
    }

    const copilotApplyBtn = document.getElementById("btn-copilot-apply");
    if (copilotApplyBtn) {
      copilotApplyBtn.addEventListener("click", () => {
        switchWorkspaceTab("game");
        const sel = document.getElementById("shared-game-select");
        if (sel) sel.value = "memory-match";
        launchSharedRoomGame("memory-match", "medium");
        showToast("AI Co-Pilot suggestion applied to shared stage!");
      });
    }

    // --- Virtual Room Toolbar Buttons ---
    const toolWbBtn = document.getElementById("btn-tool-whiteboard");
    const toolActBtn = document.getElementById("btn-tool-start-activity");
    const toolWordBtn = document.getElementById("btn-tool-share-word");
    const toolSeqBtn = document.getElementById("btn-tool-share-seq");
    const toolMemBtn = document.getElementById("btn-tool-memory");
    const toolNoteBtn = document.getElementById("btn-tool-quick-note");

    if (toolWbBtn) toolWbBtn.onclick = () => switchWorkspaceTab("whiteboard");
    if (toolActBtn) toolActBtn.onclick = () => switchWorkspaceTab("game");
    if (toolWordBtn) toolWordBtn.onclick = () => switchWorkspaceTab("word");
    if (toolSeqBtn) toolSeqBtn.onclick = () => switchWorkspaceTab("sequence");
    if (toolMemBtn) {
      toolMemBtn.onclick = () => {
        switchWorkspaceTab("game");
        const sel = document.getElementById("shared-game-select");
        if (sel) sel.value = "memory-match";
        launchSharedRoomGame("memory-match", "medium");
      };
    }
    if (toolNoteBtn) {
      toolNoteBtn.onclick = () => document.getElementById("session-notes-modal")?.classList.remove("hidden");
    }

    // Video Device Controls
    let micMuted = false;
    let camMuted = false;
    const btnToggleMic = document.getElementById("btn-toggle-mic");
    const lblToggleMic = document.getElementById("label-toggle-mic");
    const btnToggleCam = document.getElementById("btn-toggle-cam");
    const lblToggleCam = document.getElementById("label-toggle-cam");
    const btnRequestCam = document.getElementById("btn-request-cam");

    if (btnToggleMic) {
      btnToggleMic.onclick = () => {
        micMuted = !micMuted;
        if (lblToggleMic) lblToggleMic.textContent = micMuted ? "Unmute" : "Mute";
        if (localMediaStream) {
          localMediaStream.getAudioTracks().forEach(t => t.enabled = !micMuted);
        }
        showToast(micMuted ? "Microphone muted" : "Microphone active");
      };
    }

    if (btnToggleCam) {
      btnToggleCam.onclick = () => {
        camMuted = !camMuted;
        if (lblToggleCam) lblToggleCam.textContent = camMuted ? "Start Cam" : "Camera";
        if (localMediaStream) {
          localMediaStream.getVideoTracks().forEach(t => t.enabled = !camMuted);
        }
        showToast(camMuted ? "Camera disabled" : "Camera enabled");
      };
    }

    if (btnRequestCam) {
      btnRequestCam.onclick = async () => {
        try {
          if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            localMediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            const childVid = document.getElementById("child-video");
            const placeholder = document.getElementById("child-video-placeholder");
            if (childVid) {
              childVid.srcObject = localMediaStream;
              childVid.classList.remove("hidden");
              if (placeholder) placeholder.classList.add("hidden");
            }
            showToast("Webcam connected for 1-on-1 virtual session.");
          } else {
            showToast("Camera API not supported in this browser. Showing avatar placeholder.");
          }
        } catch (err) {
          console.warn("Webcam access declined or unavailable:", err);
          showToast("Camera permission not granted. Safe avatar placeholder active.");
        }
      };
    }

    // End Session & Open Notes Modal
    const endSessionBtn = document.getElementById("btn-room-end-session");
    const notesModal = document.getElementById("session-notes-modal");
    const closeNotesBtn = document.getElementById("btn-close-notes");
    const cancelNotesBtn = document.getElementById("btn-cancel-notes");
    const notesForm = document.getElementById("session-notes-form");

    if (endSessionBtn && notesModal) {
      endSessionBtn.onclick = () => notesModal.classList.remove("hidden");
    }
    if (closeNotesBtn && notesModal) {
      closeNotesBtn.onclick = () => notesModal.classList.add("hidden");
    }
    if (cancelNotesBtn && notesModal) {
      cancelNotesBtn.onclick = () => notesModal.classList.add("hidden");
    }

    if (notesForm) {
      notesForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const activities = Array.from(document.querySelectorAll("input[name='notesActivity']:checked")).map(cb => cb.value);
        const strengths = document.getElementById("notes-strengths")?.value.trim();
        const difficulties = document.getElementById("notes-difficulties")?.value.trim();
        const observations = document.getElementById("notes-observations")?.value.trim();
        const homePractice = document.getElementById("notes-home-practice")?.value.trim();
        const nextFocus = document.getElementById("notes-next-focus")?.value.trim();

        const child = getChildProfile();
        const newNote = {
          id: "note-" + Date.now(),
          date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
          learnerName: child?.name || "Aarav Patel",
          specialistName: document.getElementById("room-specialist-name")?.textContent || "Ananya Rao, M.Ed",
          activities: activities.length ? activities : ["Sound Match", "Memory Match"],
          strengths: strengths || "Demonstrated high motivation and phonological responsiveness.",
          difficulties: difficulties || "Needed extra pacing on rapid recall sequences.",
          observations: observations || "Strong multi-sensory engagement.",
          homePractice: homePractice || "Memory Match — 10 minutes daily",
          nextFocus: nextFocus || "Working Memory & Sequencing"
        };

        const notes = getStoredSessionNotes();
        notes.unshift(newNote);
        saveStoredSessionNotes(notes);

        // Asynchronously sync with backend database
        syncWithBackend('teacher-notes', {
          childId: newNote.learnerName,
          teacherName: newNote.specialistName,
          strengths: newNote.strengths,
          observations: newNote.observations,
          practiceAreas: newNote.difficulties,
          homePractice: newNote.homePractice,
          nextSessionFocus: newNote.nextFocus
        });

        // Clean up media
        if (localMediaStream) {
          localMediaStream.getTracks().forEach(t => t.stop());
          localMediaStream = null;
        }
        clearInterval(roomCountdownTimer);

        notesModal.classList.add("hidden");
        showToast("Session documentation saved! Progress timeline and AI recommendations updated.");
        switchView("progress");
      });
    }

    // --- Parent Dashboard Support Team & Progress Timeline ---
    window.renderSupportTeamAndTimeline = function() {
      const notes = getStoredSessionNotes();
      const sessions = getStoredSessions();
      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;

      const activeSession = sessions[0];
      const lastNote = notes[0];
      const spec = profiles.find(p => p.id === activeSession?.specialistId) || profiles[0];

      const nameEl = document.getElementById("dash-specialist-name");
      const nextEl = document.getElementById("dash-next-session");
      const focusEl = document.getElementById("dash-current-focus");
      const homeEl = document.getElementById("dash-home-practice");

      if (nameEl) nameEl.textContent = `${spec.name}, ${spec.qualification.split(" ")[0]}`;
      if (nextEl) nextEl.textContent = activeSession ? `${activeSession.date}, ${activeSession.time}` : "Saturday, 10:30 AM";
      if (focusEl) focusEl.textContent = lastNote ? lastNote.nextFocus : "Working Memory & Sequencing";
      if (homeEl) homeEl.textContent = lastNote ? lastNote.homePractice : "Memory Match (10 mins daily)";

      // Progress Timeline
      const timelineFlow = document.getElementById("progress-timeline-flow");
      if (timelineFlow) {
        const milestones = [
          {
            date: "Sept 01, 2026",
            badge: "Screening Checkpoint",
            title: "Initial Comprehensive Screening",
            desc: "Baseline evaluation completed with 72% overall index. Phonological awareness identified as strong; working memory targeted for intervention."
          },
          {
            date: "Sept 05, 2026",
            badge: "Targeted Practice",
            title: "Memory Match Guided Exercises",
            desc: "Completed 5 practice rounds. Retention improved on 3-item numeric sequences."
          },
          {
            date: "Sept 10, 2026",
            badge: "Specialist Session",
            title: `1-on-1 Virtual Session with ${spec.name}`,
            desc: lastNote ? lastNote.observations : "Focused on multi-sensory phoneme segmentation and working memory rehearsal."
          },
          {
            date: "Sept 15, 2026",
            badge: "Skill Trajectory",
            title: "Follow-up Adaptive Activity Session",
            desc: "Overall retrieval confidence increased to 81%. Multi-sensory color-coding reinforcement active."
          }
        ];

        // Insert additional notes if saved
        if (notes.length > 1) {
          for (let i = 1; i < notes.length; i++) {
            const n = notes[i];
            milestones.splice(3, 0, {
              date: n.date,
              badge: "Specialist Session",
              title: `Session with ${n.specialistName}`,
              desc: `${n.observations} (Home Practice: ${n.homePractice})`
            });
          }
        }

        timelineFlow.innerHTML = milestones.map(m => `
          <div class="timeline-milestone-item">
            <div class="milestone-dot"></div>
            <div class="milestone-meta-row">
              <span class="milestone-date">${m.date}</span>
              <span class="milestone-badge">${m.badge}</span>
            </div>
            <h4 class="milestone-title">${m.title}</h4>
            <p class="milestone-desc">${m.desc}</p>
          </div>
        `).join("");
      }
    };

    const enterRoomFromDashBtn = document.getElementById("btn-dash-enter-virtual-room");
    if (enterRoomFromDashBtn) {
      enterRoomFromDashBtn.onclick = () => switchView("virtual-room");
    }
    const bookSessionFromDashBtn = document.getElementById("btn-dash-book-session");
    if (bookSessionFromDashBtn) {
      bookSessionFromDashBtn.onclick = () => {
        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        openBookingModal(profiles[0].id);
      };
    }

    // --- Results View AI Insight & Matched Specialist ---
    window.renderResultsAIInsightAndSpecialist = function() {
      const screening = getScreeningResult();
      const profile = getChildProfile();
      const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;

      // AI Insight Text
      const insightText = document.getElementById("results-ai-insight-text");
      if (insightText && screening) {
        const support = (screening.supportAreas && screening.supportAreas[0]) || "working memory";
        insightText.innerHTML = `
          Recent screening performance suggests that <strong>${support}</strong> reinforcement activities may be particularly beneficial for building retrieval ease. A 15-minute daily routine of structured multi-sensory exercises is recommended.
        `;

        // Asynchronously sync with backend database
        syncWithBackend('ai-insights', {
          childId: (profile && profile.name) || 'current-learner',
          source: 'screening',
          skill: support,
          insight: `Screening indicates ${support} reinforcement activities are beneficial for retrieval fluency.`,
          recommendation: 'A 15-minute daily routine of structured multi-sensory exercises is recommended.',
          confidence: 0.88
        });
      }

      // Matched Specialist
      let bestMatch = profiles[0];
      let high = -1;
      profiles.forEach(s => {
        const m = calculateSpecialistMatch(s, profile, screening);
        s._m = m;
        if (m.score > high) {
          high = m.score;
          bestMatch = s;
        }
      });

      const matchBadge = document.getElementById("results-match-score-badge");
      if (matchBadge && bestMatch) {
        matchBadge.textContent = `Match: ${bestMatch._m.score}%`;
      }

      const infoContainer = document.getElementById("results-matched-specialist-info");
      if (infoContainer && bestMatch) {
        infoContainer.innerHTML = `
          <div class="team-member-badge" style="background: none; border: none; padding: 0;">
            <div class="team-avatar-box">
              <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#2563EB" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <div class="team-member-meta">
              <h4 class="team-name">${bestMatch.name}</h4>
              <span class="team-role">${bestMatch.role} &bull; ${bestMatch.qualification}</span>
              <span class="verification-tag verified">${bestMatch.verificationStatus}</span>
            </div>
          </div>
        `;
      }

      const rationaleList = document.getElementById("results-match-rationale-list");
      if (rationaleList && bestMatch) {
        rationaleList.innerHTML = bestMatch._m.reasons.map(r => `<li>${r}</li>`).join("");
      }
    };

    const aiInsightPracticeBtn = document.getElementById("btn-ai-insight-practice");
    if (aiInsightPracticeBtn) {
      aiInsightPracticeBtn.onclick = () => switchView("learn");
    }
    const aiInsightAskBtn = document.getElementById("btn-ai-insight-ask");
    if (aiInsightAskBtn) {
      aiInsightAskBtn.onclick = () => openAIDrawerWithPrompt("What does this screening result mean?");
    }
    const aiInsightSpecBtn = document.getElementById("btn-ai-insight-specialist");
    if (aiInsightSpecBtn) {
      aiInsightSpecBtn.onclick = () => switchView("specialists");
    }
    const resultsBookSpecBtn = document.getElementById("btn-results-book-specialist");
    if (resultsBookSpecBtn) {
      resultsBookSpecBtn.onclick = () => {
        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        openBookingModal(profiles[0].id);
      };
    }
    const resultsViewAllSpecBtn = document.getElementById("btn-results-view-all-specialists");
    if (resultsViewAllSpecBtn) {
      resultsViewAllSpecBtn.onclick = () => switchView("specialists");
    }

    // --- Teacher Dashboard View ---
    window.renderTeacherDashboard = function() {
      const learnersGrid = document.getElementById("teacher-students-grid");
      const sessionsTbody = document.getElementById("teacher-sessions-tbody");
      const sessions = getStoredSessions();
      const child = getChildProfile();

      const students = [
        {
          name: child?.name || "Aarav Patel",
          grade: child?.grade || "Class 3",
          focus: "Working Memory & Sequencing",
          score: "78%",
          lastSession: "Sept 10, 2026",
          status: "Virtual Session Scheduled",
          screeningCat: "Working Memory (64%), Phonological (82%)"
        },
        {
          name: "Meera Krishnan",
          grade: "Class 2",
          focus: "Phonological Awareness",
          score: "64%",
          lastSession: "Sept 08, 2026",
          status: "Follow-up Reading Practice",
          screeningCat: "Phonological (58%), Rhyming (60%)"
        },
        {
          name: "Kabir Sharma",
          grade: "Class 4",
          focus: "Visual Sequencing & Rapid Retrieval",
          score: "82%",
          lastSession: "Sept 05, 2026",
          status: "Home Practice Review",
          screeningCat: "Sequencing (70%), Rapid Naming (65%)"
        }
      ];

      if (learnersGrid) {
        learnersGrid.innerHTML = students.map((st, i) => `
          <div class="learner-card" data-idx="${i}">
            <div class="learner-card-header">
              <h4 class="learner-name">${st.name}</h4>
              <span class="badge-difficulty">${st.grade}</span>
            </div>
            <div class="learner-meta-row">
              <div><strong>Current Focus:</strong> ${st.focus}</div>
              <div><strong>Latest Screening Index:</strong> ${st.score}</div>
              <div><strong>Last Session:</strong> ${st.lastSession}</div>
              <div><strong>Next Action:</strong> ${st.status}</div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm btn-inspect-student" data-idx="${i}">
              Open Student Profile & Notes
            </button>
          </div>
        `).join("");

        learnersGrid.querySelectorAll(".btn-inspect-student").forEach(btn => {
          btn.addEventListener("click", () => openStudentDrawer(students[btn.dataset.idx]));
        });
      }

      // Populate dynamic session rows in the Teacher sessions table
      if (sessionsTbody) {
        const defaultDemoSessions = [
          {
            childName: "Aarav Patel",
            childGrade: "Class 3",
            sessionTime: "10:30 AM (Upcoming)",
            duration: "30 min",
            focusAreas: "Working Memory & Sequencing",
            language: "English / Tamil",
            status: "Confirmed"
          },
          {
            childName: "Meera Krishnan",
            childGrade: "Class 2",
            sessionTime: "03:00 PM",
            duration: "45 min",
            focusAreas: "Phonological Awareness",
            language: "Tamil",
            status: "Confirmed"
          }
        ];

        const allSessions = [...(sessions || [])];
        defaultDemoSessions.forEach(demo => {
          if (!allSessions.some(s => (s.childName === demo.childName || s.student === demo.childName) && (s.sessionTime === demo.sessionTime || s.time === demo.sessionTime))) {
            allSessions.push(demo);
          }
        });

        sessionsTbody.innerHTML = allSessions.map(s => {
          const name = s.childName || s.student || "Learner";
          const grade = s.childGrade || s.grade || "Class 3";
          const time = s.sessionDate ? `${s.sessionDate} at ${s.sessionTime || s.time || "10:00 AM"}` : (s.sessionTime || s.time || "10:30 AM");
          const dur = s.duration || "30 min";
          const focus = s.focusAreas || s.focus || "Targeted Intervention";
          const lang = s.language || "English / Multilingual";
          const status = s.status || "Confirmed";

          return `
            <tr>
              <td><strong>${name}</strong> (${grade})</td>
              <td>${time}</td>
              <td>${dur}</td>
              <td>${focus}</td>
              <td>${lang}</td>
              <td><span class="status-pill confirmed">${status}</span></td>
              <td>
                <button type="button" class="btn btn-primary btn-sm btn-join-room-table" data-student="${name}">
                  Launch Room
                </button>
              </td>
            </tr>
          `;
        }).join("");
      }

      // Wire launch room in table
      document.querySelectorAll(".btn-join-room-table").forEach(btn => {
        btn.onclick = () => switchView("virtual-room");
      });
    };

    function openStudentDrawer(st) {
      const modal = document.getElementById("student-drawer-modal");
      const nameEl = document.getElementById("drawer-student-name");
      const bodyEl = document.getElementById("drawer-student-body");
      const launchBtn = document.getElementById("btn-drawer-launch-room");
      if (!modal || !st) return;

      if (nameEl) nameEl.textContent = `${st.name} (${st.grade})`;
      if (bodyEl) {
        bodyEl.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 18px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
              <div style="background: var(--bg-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
                <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">Latest Index</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: var(--primary-blue);">${st.score}</div>
              </div>
              <div style="background: var(--bg-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
                <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">Intervention Focus</div>
                <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-dark);">${st.focus}</div>
              </div>
              <div style="background: var(--bg-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
                <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">Next Milestone</div>
                <div style="font-size: 0.95rem; font-weight: 700; color: #059669;">${st.status}</div>
              </div>
            </div>

            <div style="background: #FFFFFF; border: 1px solid var(--border-color); border-radius: 8px; padding: 16px;">
              <h4 style="font-size: 0.88rem; font-weight: 700; color: var(--text-dark); margin-bottom: 8px;">Breakdown by Evaluated Domain:</h4>
              <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0 0 10px 0;">${st.screeningCat}</p>
              <h4 style="font-size: 0.88rem; font-weight: 700; color: var(--text-dark); margin-bottom: 8px;">AI Co-Pilot Advisory Guidance:</h4>
              <p style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; margin: 0;">
                Prioritize 5-minute working memory games with visual sequencing cues. Reinforce auditory phoneme segmentation before introducing multi-syllabic text.
              </p>
            </div>
          </div>
        `;
      }

      if (launchBtn) {
        launchBtn.onclick = () => {
          modal.classList.add("hidden");
          switchView("virtual-room");
        };
      }

      modal.classList.remove("hidden");
    }

    const closeStudentDrawerBtn = document.getElementById("btn-close-student-drawer");
    const closeStudentDrawerBtn2 = document.getElementById("btn-drawer-close");
    if (closeStudentDrawerBtn) closeStudentDrawerBtn.onclick = () => document.getElementById("student-drawer-modal")?.classList.add("hidden");
    if (closeStudentDrawerBtn2) closeStudentDrawerBtn2.onclick = () => document.getElementById("student-drawer-modal")?.classList.add("hidden");

    const newDashSessionBtn = document.getElementById("btn-dash-new-session");
    if (newDashSessionBtn) {
      newDashSessionBtn.onclick = () => {
        const profiles = getStoredProfiles() || DEFAULT_SPECIALISTS;
        openBookingModal(profiles[0].id);
      };
    }

    // --- 1. LearnEase AI Assistant (Floating & Contextual) ---
    const floatingAiBtn = document.getElementById("btn-floating-ai");
    const headerAiBtn = document.getElementById("btn-header-ai");
    const aiDrawer = document.getElementById("ai-assistant-drawer");
    const closeAiBtn = document.getElementById("btn-close-ai-drawer");
    const aiQueryForm = document.getElementById("ai-query-form");
    const aiQueryInput = document.getElementById("ai-query-input");
    const aiMessagesContainer = document.getElementById("ai-chat-messages");

    function toggleAIDrawer() {
      if (!aiDrawer) return;
      aiDrawer.classList.toggle("hidden");
      updateAIContextBanner();
    }

    function openAIDrawerWithPrompt(promptText) {
      if (!aiDrawer) return;
      aiDrawer.classList.remove("hidden");
      updateAIContextBanner();
      handleAIQuery(promptText);
    }

    function updateAIContextBanner() {
      const banner = document.getElementById("ai-context-text");
      if (!banner) return;
      const child = getChildProfile();
      const screening = getScreeningResult();
      const score = screening?.score ? `${screening.score}%` : "78%";
      banner.textContent = `Context: ${child?.name || "Aarav Patel"} (${child?.grade || "Class 3"}) • Screening: ${score}`;
    }

    if (floatingAiBtn) floatingAiBtn.addEventListener("click", toggleAIDrawer);
    if (headerAiBtn) headerAiBtn.addEventListener("click", toggleAIDrawer);
    if (closeAiBtn) closeAiBtn.addEventListener("click", toggleAIDrawer);

    // Prompt Chips
    document.querySelectorAll(".ai-chip").forEach(chip => {
      chip.addEventListener("click", () => {
        const prompt = chip.dataset.prompt;
        if (prompt) handleAIQuery(prompt);
      });
    });

    if (aiQueryForm) {
      aiQueryForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const text = aiQueryInput?.value.trim();
        if (text) {
          handleAIQuery(text);
          aiQueryInput.value = "";
        }
      });
    }

    // Contextual rule-based AI generator (Safe & Non-diagnostic)
    async function queryLearnEaseAI(prompt, context) {
      try {
        const res = await fetch("/api/ai-assistant", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt, context })
        });
        if (res.ok) {
          const data = await res.json();
          if (data && (data.reply || data.response)) {
            return data.reply || data.response;
          }
        }
      } catch (err) {
        console.warn("[LearnEase AI] Direct API call fallback:", err);
      }
      return generateContextualAIResponse(prompt, context);
    }

    function generateContextualAIResponse(query, ctx) {
      const q = (query || "").toLowerCase().trim();
      const name = ctx?.profile?.name || "Aarav";
      const grade = ctx?.profile?.grade || "Class 3";
      const score = ctx?.screening?.score !== undefined ? ctx.screening.score : 78;
      const notes = getStoredSessionNotes();
      const lastNote = notes[0];

      // 1. Greetings
      if (/^(hi|hello|hey|greetings|good morning|good afternoon|good evening|namaste|vanakkam)[\s!.]*$/i.test(q)) {
        return `Hello! I am the <strong>LearnEase AI Assistant</strong>. I can help you understand ${name}'s learning progress, explain screening results, suggest personalized practice activities, and assist teachers and parents with structured support plans.<br><br>How can I assist you today?`;
      }

      // 2. Tamil Query Support
      if (q.includes("tamil") || q.includes("தமிழ்")) {
        return `
          <strong>கற்றல் ஆதரவு வழிகாட்டல் (Tamil Explanation):</strong><br><br>
          LearnEase உங்கள் குழந்தையின் தொடக்கக்கால வாசிப்பு மற்றும் நினைவாற்றல் திறன்களை ஆராய்ந்து எளிய பயிற்சிகளை வழங்குகிறது.<br><br>
          • <strong>அவதானிக்கப்பட்ட தேவை:</strong> சொற்களின் ஒலி அமைப்பை நினைவில் வைத்தல் மற்றும் வரிசைப்படுத்துதல் (${name} - ${score}%).<br>
          • <strong>பரிந்துரைக்கப்படும் பயிற்சி:</strong> Sound Match மற்றும் Memory Match ஆகியவற்றை தினமும் 10 முதல் 15 நிமிடங்கள் பயிற்சி செய்யலாம்.<br>
          • <strong>குறிப்பு:</strong> இது ஒரு கல்விசார் ஆதரவு கருவியாகும், மருத்துவ மதிப்பீடு அல்ல.
        `;
      }

      // 3. Hindi Query Support
      if (q.includes("hindi") || q.includes("हिन्दी")) {
        return `
          <strong>शैक्षिक सहायता मार्गदर्शन (Hindi Explanation):</strong><br><br>
          LearnEase आपके बच्चे के बुनियादी पठन और स्मृति कौशल को समझकर व्यक्तिगत अभ्यास गतिविधियां प्रदान करता है।<br><br>
          • <strong>सुझाया गया अभ्यास:</strong> वर्ण ध्वनि पहचान (Sound Match) और दृश्य स्मृति (Memory Match) का प्रतिदिन 10-15 मिनट अभ्यास करें (${name} - ${score}%)।<br>
          • <strong>अभिभावक सुझाव:</strong> बच्चे को छोटे-छोटे वाक्यों में आत्मविश्वास के साथ पढ़ने के लिए प्रोत्साहित करें।<br>
          • <strong>सूचना:</strong> यह केवल एक सहायक शैक्षिक साधन है, चिकित्सीय निदान नहीं।
        `;
      }

      // 4. Screening result explanation
      if (q.includes("what does this screening result mean") || q.includes("result mean") || q.includes("screening") || q.includes("score mean")) {
        return `
          Based on the screening assessment, <strong>${name}</strong> (${grade}) achieved an overall index of <strong>${score}%</strong>.<br><br>
          • <strong>Identified Strengths:</strong> Solid auditory recognition, keen focus, and engagement with interactive sound tasks.<br>
          • <strong>Focus Areas:</strong> Working memory retention across 3–4 items and rapid visual sequencing patterns.<br><br>
          <em>Important:</em> This screening evaluates foundational cognitive and literacy processing. It is not a clinical or medical diagnosis. If you have persistent developmental concerns, we recommend consulting a qualified educational psychologist or developmental pediatrician.
        `;
      }

      // 5. Why Memory Match was recommended
      if (q.includes("why was memory match recommended") || q.includes("memory match")) {
        return `
          <strong>Memory Match</strong> was recommended because the screening detected slight latency during multi-item recall tasks for <strong>${name}</strong>.<br><br>
          Visual-spatial and auditory working memory are fundamental building blocks for decoding written words. Memory Match uses low-stress, incremental sequence lengths (starting with 2–3 items) to build working memory pathways naturally without cognitive overload.
        `;
      }

      // 6. Practice today / 15-minute daily plan
      if (q.includes("practice today") || q.includes("what should we practice") || q.includes("daily plan") || q.includes("routine")) {
        let noteRec = lastNote ? ` (reinforcing teacher observation: <em>"${lastNote.homePractice}"</em>)` : "";
        return `
          Here is the recommended <strong>15-Minute Daily Routine</strong> for ${name} today${noteRec}:<br><br>
          1. <strong>Warm-up (5 mins):</strong> Sound Match — Practice 5 rounds of phoneme segmentation.<br>
          2. <strong>Targeted Focus (5 mins):</strong> Memory Match — Level 2 working memory rehearsal.<br>
          3. <strong>Shared Reading (5 mins):</strong> Read a short story together, encouraging ${name} to track words with a finger.<br><br>
          Consistent short practice is significantly more effective than long, stressful sessions!
        `;
      }

      // 7. Home support strategies
      if ((q.includes("support") && (q.includes("home") || q.includes("parent"))) || q.includes("at home")) {
        return `
          Here are four practical, low-pressure home strategies to support <strong>${name}</strong>:<br><br>
          • <strong>Paired Shared Reading:</strong> Read along together for 10–15 minutes daily. Let ${name} read words they feel confident with while you support difficult ones.<br>
          • <strong>Everyday Memory Games:</strong> Practice recalling 3 everyday items (e.g., "spoon, cup, napkin") before setting the table.<br>
          • <strong>Multi-Sensory Tracing:</strong> Use sand trays, clay, or finger tracing on textured surfaces to anchor tricky letter shapes.<br>
          • <strong>Praise the Effort:</strong> Emphasize persistence and curiosity rather than speed or perfect scores.
        `;
      }

      // 8. Teacher session plan
      if (q.includes("session plan") || q.includes("lesson plan") || q.includes("teacher plan")) {
        return `
          <strong>Structured 30-Minute 1-on-1 Specialist Session Plan for ${name}:</strong><br><br>
          • <strong>Phase 1 (0–5 min): Rapport & Check-in</strong> — Review daily mood and complete 1 quick warm-up round in Sound Match.<br>
          • <strong>Phase 2 (5–15 min): Core Scaffolding</strong> — Focus on Working Memory and Sequencing using interactive cards in the Virtual Learning Room.<br>
          • <strong>Phase 3 (15–25 min): Multi-Sensory Phonics Practice</strong> — Syllable segmentation and word building with immediate positive reinforcement.<br>
          • <strong>Phase 4 (25–30 min): Reflection & Home Goal</strong> — Document qualitative observations in Teacher Notes and assign 1 home activity.
        `;
      }

      // 9. Working Memory
      if (q.includes("working memory")) {
        return `
          For <strong>Working Memory</strong> support in ${name}'s learning journey:<br><br>
          • <strong>Primary Activity:</strong> <em>Memory Match</em> — Start with 2-symbol sequences, increasing gradually to 4 items.<br>
          • <strong>Secondary Activity:</strong> <em>Sequence Challenge</em> — Practice ordinal ordering and pattern completion.<br>
          • <strong>Classroom/Home Tip:</strong> Break multi-step instructions into single visual chunks (e.g., "Open book" -> "Find page 12").
        `;
      }

      // Fallback helpful response
      return `
        Thank you for asking! For <strong>${name}</strong> (${grade}), our adaptive educational engine recommends consistent, low-stress practice focusing on phonological awareness and working memory.<br><br>
        • Would you like to try <strong>Memory Match</strong> or <strong>Sound Match</strong> now?<br>
        • You can also schedule a virtual 1-on-1 session with a certified specialist like <strong>Ananya Rao</strong> under the Specialists tab.<br><br>
        <em>Reminder:</em> LearnEase provides supportive educational tools and does not provide formal medical diagnoses.
      `;
    }

    function handleAIQuery(prompt) {
      // Append user message
      const userMsg = document.createElement("div");
      userMsg.className = "ai-message user";
      userMsg.innerHTML = `<div class="msg-bubble"><p>${prompt}</p></div>`;
      aiMessagesContainer?.appendChild(userMsg);

      // Context
      const ctx = {
        profile: getChildProfile(),
        screening: getScreeningResult(),
        progress: getProgressData()
      };

      // Show typing indicator
      const assistantMsg = document.createElement("div");
      assistantMsg.className = "ai-message assistant";
      assistantMsg.innerHTML = `
        <div class="msg-bubble">
          <p style="color: #9CA3AF;">Analyzing learner profile & screening context...</p>
        </div>
      `;
      aiMessagesContainer?.appendChild(assistantMsg);
      aiMessagesContainer.scrollTop = aiMessagesContainer.scrollHeight;

      setTimeout(async () => {
        const reply = await queryLearnEaseAI(prompt, ctx);
        assistantMsg.innerHTML = `
          <div class="msg-bubble">
            <p>${reply}</p>
            <p class="ai-safety-note">Safe educational guidance &bull; Non-diagnostic support</p>
          </div>
        `;
        aiMessagesContainer.scrollTop = aiMessagesContainer.scrollHeight;
      }, 400);
    }

    // Switch view on load based on hash
    const initialHash = window.location.hash.replace('#', '') || 'home';
    switchView(initialHash);
  });

  // ============================================================
  // LEARNEASE MEGA UPGRADE — NEW FEATURE MODULES
  // ============================================================

  // ============================================================
  // MODULE A: AUTHENTICATION
  // ============================================================
  function getCurrentUser() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER)); } catch { return null; }
  }
  function saveCurrentUser(user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  }
  function getUserAccounts() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_ACCOUNTS)) || []; } catch { return []; }
  }
  function saveUserAccounts(accounts) {
    localStorage.setItem(STORAGE_KEYS.USER_ACCOUNTS, JSON.stringify(accounts));
  }

  function registerUser(data) {
    const accounts = getUserAccounts();
    const existing = accounts.find(a => a.email === data.email);
    if (existing) return { success: false, error: 'An account with this email already exists.' };
    const user = { id: Date.now().toString(), ...data, createdAt: new Date().toISOString() };
    accounts.push(user);
    saveUserAccounts(accounts);
    saveCurrentUser(user);
    updateNavForUser(user);
    return { success: true, user };
  }

  function loginUser(emailOrName, password) {
    // Demo mode: also allow demo login
    if ((emailOrName === 'aarav' || emailOrName === 'demo' || emailOrName === 'aarav@example.com') && password === 'demo123') {
      const demoUser = {
        id: 'demo-aarav', name: 'Aarav', grade: 'Grade 6', school: 'City Public School',
        age: 11, email: 'aarav@example.com', parentName: 'Priya Kumar', whatsapp: '+91 98765 43210',
        homeLang: 'ta', schoolLang: 'en', assessDay: 'saturday', assessTime: '10:00',
        difficulties: ['spelling', 'phonology']
      };
      saveCurrentUser(demoUser);
      updateNavForUser(demoUser);
      return { success: true, user: demoUser };
    }
    const accounts = getUserAccounts();
    const user = accounts.find(a => (a.email === emailOrName || a.name.toLowerCase() === emailOrName.toLowerCase()) && a.password === password);
    if (!user) return { success: false, error: 'Invalid credentials. Try email: aarav@example.com / password: demo123' };
    saveCurrentUser(user);
    updateNavForUser(user);
    return { success: true, user };
  }

  function logoutUser() {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    updateNavForUser(null);
    showToast('You have been logged out.');
    switchView('home');
  }

  function updateNavForUser(user) {
    const label = document.getElementById('user-auth-label');
    const btn = document.getElementById('btn-user-auth');
    if (!label || !btn) return;
    if (user) {
      const initials = (user.name || 'U').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
      label.textContent = initials;
      btn.title = `Logged in as ${user.name} — click for profile`;
      btn.setAttribute('aria-label', 'View profile');
      btn.dataset.mode = 'profile';
      btn.style.background = 'rgba(37,99,235,.15)';
      btn.style.color = '#60A5FA';
      btn.style.fontWeight = '700';
    } else {
      label.textContent = 'Login';
      btn.title = 'Login or create account';
      btn.setAttribute('aria-label', 'Login or create account');
      btn.dataset.mode = 'login';
      btn.style.background = '';
      btn.style.color = '';
      btn.style.fontWeight = '';
    }
  }

  function renderAuthView() {
    // Auth tabs wiring
    document.querySelectorAll('[data-auth-tab]').forEach(el => {
      el.addEventListener('click', () => switchAuthTab(el.dataset.authTab));
    });
    // Form submissions
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');
    const formForgot = document.getElementById('form-forgot');
    if (formLogin && !formLogin.dataset.wired) {
      formLogin.dataset.wired = '1';
      formLogin.addEventListener('submit', e => {
        e.preventDefault();
        const email = document.getElementById('login-email').value.trim();
        const pass = document.getElementById('login-password').value;
        const result = loginUser(email, pass);
        if (result.success) {
          showToast(`Welcome back, ${result.user.name}!`);
          switchView('profile');
        } else {
          showToast(result.error);
        }
      });
    }
    if (formRegister && !formRegister.dataset.wired) {
      formRegister.dataset.wired = '1';
      formRegister.addEventListener('submit', e => {
        e.preventDefault();
        const difficulties = [...document.querySelectorAll('[name="difficulties"]:checked')].map(c => c.value);
        const data = {
          name: document.getElementById('reg-name').value.trim(),
          age: document.getElementById('reg-age').value,
          grade: document.getElementById('reg-grade').value.trim(),
          school: document.getElementById('reg-school').value.trim(),
          parentName: document.getElementById('reg-parent-name').value.trim(),
          whatsapp: document.getElementById('reg-whatsapp').value.trim(),
          homeLang: document.getElementById('reg-home-lang').value,
          schoolLang: document.getElementById('reg-school-lang').value,
          assessDay: document.getElementById('reg-assess-day').value,
          assessTime: document.getElementById('reg-assess-time').value,
          email: document.getElementById('reg-email').value.trim(),
          password: document.getElementById('reg-password').value,
          difficulties
        };
        if (!data.name || !data.email || !data.password) {
          showToast('Please fill in required fields (Name, Email, Password).');
          return;
        }
        const result = registerUser(data);
        if (result.success) {
          showToast(`Account created! Welcome, ${result.user.name}!`);
          switchView('profile');
        } else {
          showToast(result.error);
        }
      });
    }
    if (formForgot && !formForgot.dataset.wired) {
      formForgot.dataset.wired = '1';
      formForgot.addEventListener('submit', e => {
        e.preventDefault();
        showToast('Demo mode: password reset is simulated. Please use demo credentials.');
      });
    }
  }

  function switchAuthTab(tabName) {
    document.querySelectorAll('.auth-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.authTab === tabName);
      t.setAttribute('aria-selected', t.dataset.authTab === tabName ? 'true' : 'false');
    });
    document.querySelectorAll('.auth-panel').forEach(p => {
      p.classList.toggle('active', p.id === `auth-panel-${tabName}`);
    });
  }

  // ============================================================
  // MODULE B: LEARNING FINGERPRINT / PROFILE
  // ============================================================
  const DEMO_FINGERPRINT = {
    reading: 72, spelling: 54, phonology: 48, wordRecognition: 65, memory: 81, attention: 73, writing: 61
  };
  const SKILL_LABELS = {
    reading: 'Reading', spelling: 'Spelling', phonology: 'Phonological Awareness',
    wordRecognition: 'Word Recognition', memory: 'Memory', attention: 'Attention', writing: 'Writing'
  };

  function getLearningFingerprint() {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LEARNING_FINGERPRINT);
      if (stored) return JSON.parse(stored);
    } catch {}
    return { ...DEMO_FINGERPRINT };
  }

  function renderProfileView() {
    const user = getCurrentUser();
    const fp = getLearningFingerprint();
    if (user) {
      const el = document.getElementById('profile-user-name');
      if (el) el.textContent = user.name + (user.grade ? '' : '');
      const initEl = document.getElementById('profile-avatar-initials');
      if (initEl) initEl.textContent = (user.name || 'U').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
      const gradeEl = document.getElementById('profile-grade-chip');
      if (gradeEl && user.grade) gradeEl.textContent = user.grade;
      const schoolEl = document.getElementById('profile-school-chip');
      if (schoolEl && user.school) schoolEl.textContent = user.school;
      const homeLangEl = document.getElementById('profile-home-lang');
      if (homeLangEl) homeLangEl.textContent = { ta: 'Tamil', hi: 'Hindi', en: 'English', te: 'Telugu', kn: 'Kannada', bn: 'Bengali' }[user.homeLang] || user.homeLang || 'Tamil';
      const schoolLangEl = document.getElementById('profile-school-lang');
      if (schoolLangEl) schoolLangEl.textContent = { en: 'English', ta: 'Tamil', hi: 'Hindi' }[user.schoolLang] || user.schoolLang || 'English';
      const schedEl = document.getElementById('profile-assess-schedule');
      if (schedEl) schedEl.textContent = (user.assessDay ? user.assessDay.charAt(0).toUpperCase() + user.assessDay.slice(1) : 'Saturday') + ', ' + (user.assessTime || '10:00') + (parseInt((user.assessTime || '10').split(':')[0]) < 12 ? ' AM' : ' PM');
    }

    // Render fingerprint bars
    const container = document.getElementById('fingerprint-bars');
    if (container) {
      container.innerHTML = Object.entries(SKILL_LABELS).map(([key, label]) => {
        const val = fp[key] || 0;
        const barColor = val >= 70 ? 'var(--primary-blue)' : val >= 50 ? '#FACC15' : '#EF4444';
        return `<div class="fp-bar-row">
          <span class="fp-bar-label">${label}</span>
          <div class="fp-bar-track"><div class="fp-bar-fill" style="width:${val}%;background:${barColor}"></div></div>
          <span class="fp-bar-val">${val}%</span>
        </div>`;
      }).join('');
    }

    // AI Insights
    const insightsEl = document.getElementById('profile-ai-insights');
    if (insightsEl) {
      insightsEl.innerHTML = generateAIInsights(fp).map(insight => `
        <div class="ai-insight-item">
          <svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="#2563EB" stroke-width="1.8"><path d="M10 2L12 7L17 9L12 11L10 16L8 11L3 9L8 7L10 2Z"/></svg>
          <span>${insight}</span>
        </div>`).join('');
    }

    // Early Support Alert
    const lowestSkill = Object.entries(fp).sort((a, b) => a[1] - b[1])[0];
    const supportAlert = document.getElementById('early-support-alert');
    if (supportAlert && lowestSkill && lowestSkill[1] < 55) {
      supportAlert.classList.remove('hidden');
      const alertText = document.getElementById('support-alert-text');
      if (alertText) alertText.textContent = `Repeated difficulty has been observed in ${SKILL_LABELS[lowestSkill[0]].toLowerCase()} across recent sessions. We recommend continued targeted practice. If concerns persist, consider support from a qualified specialist.`;
    }

    // Wiring
    document.getElementById('btn-logout')?.addEventListener('click', logoutUser);
    document.getElementById('btn-connect-specialist')?.addEventListener('click', () => switchView('specialists'));
    document.getElementById('btn-support-practice')?.addEventListener('click', () => switchView('daily-plan'));
    document.getElementById('btn-edit-learning-profile')?.addEventListener('click', () => showToast('Profile editing available after account creation.'));
  }

  function generateAIInsights(fp) {
    const insights = [];
    const sorted = Object.entries(fp).sort((a, b) => b[1] - a[1]);
    const strongest = sorted[0];
    const weakest = sorted[sorted.length - 1];
    insights.push(`Your strongest practice area is ${SKILL_LABELS[strongest[0]]} at ${strongest[1]}%.`);
    if (weakest[1] < 60) insights.push(`${SKILL_LABELS[weakest[0]]} (${weakest[1]}%) would benefit from focused daily practice.`);
    const improving = Object.entries(fp).filter(([, v]) => v >= 65 && v < 80);
    if (improving.length) insights.push(`${SKILL_LABELS[improving[0][0]]} is showing steady progress — keep it up!`);
    return insights;
  }

  // ============================================================
  // MODULE C: DAILY LEARNING PLAN
  // ============================================================
  const DAILY_ACTIVITIES = [
    { id: 'sound-letters', title: 'Sound & Letter Practice', skill: 'Phonological Awareness', minutes: 5, gameKey: 'sound-match' },
    { id: 'word-recognition', title: 'Word Recognition', skill: 'Reading', minutes: 5, gameKey: 'letter-hunt' },
    { id: 'reading-practice', title: 'Reading Practice', skill: 'Reading Fluency', minutes: 5, gameKey: 'word-builder' },
    { id: 'memory-challenge', title: 'Memory Challenge', skill: 'Working Memory', minutes: 3, gameKey: 'memory-match' }
  ];

  let planCompletionState = {};
  let currentPlanActivity = null;

  function renderDailyPlanView() {
    const readinessOverlay = document.getElementById('readiness-overlay');
    const planContent = document.getElementById('daily-plan-content');
    const savedReadiness = sessionStorage.getItem('learnease_readiness_today');
    if (savedReadiness) {
      readinessOverlay?.classList.add('hidden');
      planContent?.classList.remove('hidden');
      renderPlanActivities(savedReadiness);
    } else {
      readinessOverlay?.classList.remove('hidden');
      planContent?.classList.add('hidden');
    }

    // Wire readiness buttons
    document.querySelectorAll('.readiness-btn').forEach(btn => {
      if (!btn.dataset.wired) {
        btn.dataset.wired = '1';
        btn.addEventListener('click', () => handleReadinessResponse(btn.dataset.mood));
      }
    });

    // Wire close arena
    const closeArena = document.getElementById('btn-close-plan-arena');
    if (closeArena && !closeArena.dataset.wired) {
      closeArena.dataset.wired = '1';
      closeArena.addEventListener('click', () => {
        document.getElementById('plan-arena')?.classList.add('hidden');
        currentPlanActivity = null;
      });
    }

    // Wire why-difficult
    document.getElementById('btn-why-difficult')?.addEventListener('click', () => {
      document.getElementById('why-difficult-panel')?.classList.remove('hidden');
    });
    document.getElementById('btn-try-again')?.addEventListener('click', () => {
      document.getElementById('wrong-answer-feedback')?.classList.add('hidden');
      document.getElementById('why-difficult-panel')?.classList.add('hidden');
    });
    document.getElementById('btn-why-try-again')?.addEventListener('click', () => {
      document.getElementById('wrong-answer-feedback')?.classList.add('hidden');
      document.getElementById('why-difficult-panel')?.classList.add('hidden');
    });
  }

  function handleReadinessResponse(mood) {
    sessionStorage.setItem('learnease_readiness_today', mood);
    const readinessOverlay = document.getElementById('readiness-overlay');
    const planContent = document.getElementById('daily-plan-content');
    readinessOverlay?.classList.add('hidden');
    planContent?.classList.remove('hidden');

    const subtitle = document.getElementById('daily-plan-subtitle');
    const reasonText = document.getElementById('adaptive-reason-text');
    if (mood === 'tired') {
      if (subtitle) subtitle.textContent = "Let's keep today's session short and comfortable. You've got this.";
      if (reasonText) reasonText.textContent = "You said you're feeling tired today, so we've made today's plan shorter and focused on your strongest area — Memory.";
    } else if (mood === 'confused') {
      if (subtitle) subtitle.textContent = "That's okay — confusion is part of learning. Let's start with something familiar.";
      if (reasonText) reasonText.textContent = "We've started with your strongest activity today to help build confidence before moving to more challenging areas.";
    } else if (mood === 'okay') {
      if (subtitle) subtitle.textContent = "Good — let's work through today's plan at a comfortable pace.";
    } else {
      if (subtitle) subtitle.textContent = "Excellent — let's make the most of today's learning session!";
    }
    renderPlanActivities(mood);
  }

  function renderPlanActivities(mood) {
    const list = document.getElementById('plan-activities-list');
    if (!list) return;
    const activities = mood === 'tired' ? DAILY_ACTIVITIES.slice(0, 2) : DAILY_ACTIVITIES;
    const fp = getLearningFingerprint();
    const totalMins = activities.reduce((s, a) => s + a.minutes, 0);
    document.getElementById('plan-total-time').textContent = totalMins + ' min';
    const done = Object.values(planCompletionState).filter(Boolean).length;
    document.getElementById('plan-completion-count').textContent = `${done} / ${activities.length} done`;

    list.innerHTML = activities.map((act, i) => {
      const completed = planCompletionState[act.id];
      const progress = completed ? 100 : 0;
      return `<div class="plan-activity-card ${completed ? 'completed' : ''}" data-activity-id="${act.id}">
        <div class="plan-activity-left">
          <div class="plan-activity-num">Activity ${i + 1} of ${activities.length}</div>
          <div class="plan-activity-title">${completed ? '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="#22C55E" stroke-width="2"><polyline points="2 6 5 9 10 3"/></svg> ' : ''}${act.title}</div>
          <div class="plan-activity-meta">
            <span class="plan-activity-skill">${act.skill}</span>
            <span class="plan-activity-time">${act.minutes} min</span>
          </div>
          <div class="plan-activity-progress">
            <div class="plan-progress-bar"><div class="plan-progress-fill" style="width:${progress}%"></div></div>
          </div>
        </div>
        <button type="button" class="btn btn-primary btn-sm plan-start-btn" data-activity-id="${act.id}" data-game="${act.gameKey}" ${completed ? 'disabled' : ''}>
          ${completed ? 'Done' : 'Start'}
        </button>
      </div>`;
    }).join('');

    list.querySelectorAll('.plan-start-btn').forEach(btn => {
      btn.addEventListener('click', () => launchPlanActivity(btn.dataset.activityId, btn.dataset.game));
    });
  }

  function launchPlanActivity(activityId, gameKey) {
    currentPlanActivity = activityId;
    const arena = document.getElementById('plan-arena');
    const title = document.getElementById('plan-arena-title');
    const stage = document.getElementById('plan-arena-stage');
    const act = DAILY_ACTIVITIES.find(a => a.id === activityId);
    if (!arena || !title || !stage || !act) return;
    title.textContent = act.title;
    arena.classList.remove('hidden');
    renderPlanArenaActivity(stage, gameKey, activityId);
    arena.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderPlanArenaActivity(stage, gameKey, activityId) {
    const wordSets = {
      'sound-match': [
        { word: 'cat', sounds: ['c', 'a', 't'], options: ['c-a-t', 'c-t-a', 'a-c-t', 't-a-c'] },
        { word: 'dog', sounds: ['d', 'o', 'g'], options: ['d-o-g', 'd-g-o', 'o-d-g', 'g-o-d'] },
        { word: 'sun', sounds: ['s', 'u', 'n'], options: ['s-u-n', 's-n-u', 'u-s-n', 'n-u-s'] }
      ],
      'letter-hunt': [
        { question: 'Which letter is different from b?', options: ['d', 'b', 'b', 'b'], correct: 'd' },
        { question: 'Find the letter p:', options: ['q', 'p', 'd', 'b'], correct: 'p' }
      ],
      'word-builder': [
        { letters: ['C', 'A', 'T'], answer: 'CAT' },
        { letters: ['D', 'O', 'G'], answer: 'DOG' }
      ],
      'memory-match': [
        { sequence: ['B', '4', 'K'], instruction: 'Remember this sequence:' }
      ]
    };

    const data = wordSets[gameKey] || wordSets['sound-match'];
    const item = data[Math.floor(Math.random() * data.length)];

    if (gameKey === 'sound-match') {
      stage.innerHTML = `
        <div style="text-align:center;padding:1.5rem">
          <div style="font-size:2rem;font-weight:800;color:var(--text-primary);margin-bottom:.5rem">${item.word.toUpperCase()}</div>
          <p style="color:var(--text-muted);font-size:.85rem;margin-bottom:1.5rem">Choose how to break this word into its sounds:</p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;max-width:360px;margin:0 auto">
            ${item.options.map((opt, i) => `
              <button class="plan-answer-btn" data-correct="${i === 0}" style="background:var(--bg-surface);border:2px solid var(--border);border-radius:10px;padding:.9rem;color:var(--text-primary);font-size:.9rem;font-weight:500;cursor:pointer">
                ${opt}
              </button>`).join('')}
          </div>
        </div>`;
    } else if (gameKey === 'letter-hunt') {
      stage.innerHTML = `
        <div style="text-align:center;padding:1.5rem">
          <p style="color:var(--text-secondary);font-size:.95rem;margin-bottom:1.5rem;font-weight:500">${item.question}</p>
          <div style="display:flex;justify-content:center;gap:1rem">
            ${item.options.map((opt, i) => `
              <button class="plan-answer-btn" data-correct="${opt === item.correct}" style="width:60px;height:60px;background:var(--bg-surface);border:2px solid var(--border);border-radius:12px;font-size:1.4rem;font-weight:700;color:var(--text-primary);cursor:pointer">
                ${opt}
              </button>`).join('')}
          </div>
        </div>`;
    } else {
      stage.innerHTML = `
        <div style="text-align:center;padding:1.5rem">
          <p style="color:var(--text-muted);font-size:.85rem;margin-bottom:1rem">Activity loaded. Click Start in the main Learn section for full interactivity.</p>
          <button class="plan-answer-btn" data-correct="true" style="background:var(--primary-blue);border:none;border-radius:10px;padding:.85rem 2rem;color:#fff;font-size:.9rem;font-weight:600;cursor:pointer">Mark Complete</button>
        </div>`;
    }

    stage.querySelectorAll('.plan-answer-btn').forEach(btn => {
      btn.addEventListener('click', () => handlePlanAnswer(btn, activityId, btn.dataset.correct === 'true'));
    });
  }

  function handlePlanAnswer(btn, activityId, isCorrect) {
    const wrongFeedback = document.getElementById('wrong-answer-feedback');
    const whyPanel = document.getElementById('why-difficult-panel');
    if (isCorrect) {
      btn.style.borderColor = '#22C55E';
      btn.style.background = 'rgba(34,197,94,.1)';
      planCompletionState[activityId] = true;
      setTimeout(() => {
        document.getElementById('plan-arena')?.classList.add('hidden');
        showToast('Activity complete! Well done.');
        renderPlanActivities(sessionStorage.getItem('learnease_readiness_today') || 'ready');
      }, 800);
    } else {
      btn.style.borderColor = '#EF4444';
      btn.style.background = 'rgba(239,68,68,.08)';
      if (wrongFeedback) {
        wrongFeedback.classList.remove('hidden');
        const explain = document.getElementById('wrong-feedback-explain');
        if (explain) explain.textContent = 'You chose a different sound order. Try saying the word slowly and listen for each individual sound.';
      }
      const whyText = document.getElementById('why-difficult-text');
      if (whyPanel && whyText) {
        whyPanel.classList.add('hidden');
        whyText.textContent = 'Breaking words into sounds can feel tricky at first. The key is to say the word very slowly and pay attention to each separate sound you hear.';
      }
    }
  }

  // ============================================================
  // MODULE D: WEEKLY ASSESSMENT
  // ============================================================
  const ASSESSMENT_QUESTIONS = [
    { category: 'READING', q: 'Which word would come FIRST in a dictionary?', options: ['Zebra', 'Apple', 'Mango', 'Tiger'], correct: 1 },
    { category: 'SPELLING', q: 'Choose the correctly spelled word:', options: ['Frend', 'Friend', 'Freind', 'Friand'], correct: 1 },
    { category: 'WORD RECOGNITION', q: 'Which word means "happy"?', options: ['Sad', 'Angry', 'Joyful', 'Tired'], correct: 2 },
    { category: 'PHONOLOGICAL', q: 'How many syllables in the word "ELEPHANT"?', options: ['2', '3', '4', '1'], correct: 1 },
    { category: 'MEMORY', q: 'Earlier you saw: B-4-K. What was the MIDDLE item?', options: ['B', '4', 'K', '3'], correct: 1 },
    { category: 'READING', q: 'Which pair of words rhymes?', options: ['Cat / Dog', 'Sun / Run', 'Book / Desk', 'Fish / Bird'], correct: 1 },
    { category: 'SPELLING', q: 'Find the correctly spelled word:', options: ['Becaus', 'Because', 'Becuase', 'Becausee'], correct: 1 },
    { category: 'WORD RECOGNITION', q: 'What does "beneath" mean?', options: ['Above', 'Beside', 'Under', 'Between'], correct: 2 },
    { category: 'PHONOLOGICAL', q: 'Which word starts with the SAME sound as "phone"?', options: ['Piano', 'Fish', 'Boat', 'Door'], correct: 1 },
    { category: 'READING', q: 'Arrange into a sentence: "school / goes / to / she"', options: ['She goes to school', 'Goes she school to', 'To school she goes', 'School goes to she'], correct: 0 }
  ];

  let assessmentState = { active: false, currentQ: 0, answers: [], timerInterval: null, seconds: 0 };

  function renderWeeklyCheckView() {
    const user = getCurrentUser();
    if (user) {
      const schedEl = document.getElementById('assess-schedule-display');
      if (schedEl) {
        const day = user.assessDay ? user.assessDay.charAt(0).toUpperCase() + user.assessDay.slice(1) : 'Saturday';
        const time = user.assessTime || '10:00';
        schedEl.innerHTML = `<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="#60A5FA" stroke-width="1.8"><rect x="1" y="3" width="14" height="11" rx="1.5"/><path d="M5 1v3M11 1v3M1 8h14"/></svg>Your scheduled check: <strong>${day}, ${time} ${parseInt(time) < 12 ? 'AM' : 'PM'}</strong>`;
      }
    }
    const startBtn = document.getElementById('btn-start-assessment');
    if (startBtn && !startBtn.dataset.wired) {
      startBtn.dataset.wired = '1';
      startBtn.addEventListener('click', startWeeklyAssessment);
    }
    document.getElementById('btn-view-journey')?.addEventListener('click', () => switchView('progress'));
    document.getElementById('btn-after-assess-continue')?.addEventListener('click', () => switchView('daily-plan'));
  }

  function startWeeklyAssessment() {
    // Hide AI button during assessment
    const aiBtn = document.getElementById('btn-header-ai');
    if (aiBtn) { aiBtn.style.opacity = '.3'; aiBtn.style.pointerEvents = 'none'; aiBtn.title = 'AI paused during assessment'; }

    assessmentState = { active: true, currentQ: 0, answers: [], seconds: 0 };
    document.getElementById('assessment-landing')?.classList.add('hidden');
    document.getElementById('assessment-active')?.classList.remove('hidden');
    document.getElementById('assessment-results')?.classList.add('hidden');

    // Start timer
    assessmentState.timerInterval = setInterval(() => {
      assessmentState.seconds++;
      const m = String(Math.floor(assessmentState.seconds / 60)).padStart(2, '0');
      const s = String(assessmentState.seconds % 60).padStart(2, '0');
      const timerEl = document.getElementById('assess-timer-display');
      if (timerEl) timerEl.textContent = `${m}:${s}`;
    }, 1000);

    renderAssessmentQuestion();
  }

  function renderAssessmentQuestion() {
    const q = ASSESSMENT_QUESTIONS[assessmentState.currentQ];
    if (!q) { endWeeklyAssessment(); return; }

    const counter = document.getElementById('assess-q-counter');
    if (counter) counter.textContent = `Question ${assessmentState.currentQ + 1} / ${ASSESSMENT_QUESTIONS.length}`;
    const fill = document.getElementById('assess-progress-fill');
    if (fill) fill.style.width = `${((assessmentState.currentQ + 1) / ASSESSMENT_QUESTIONS.length) * 100}%`;
    const catEl = document.getElementById('assess-category-label');
    if (catEl) catEl.textContent = q.category;
    const promptEl = document.getElementById('assess-question-prompt');
    if (promptEl) promptEl.textContent = q.q;

    const optionsEl = document.getElementById('assess-options-grid');
    if (optionsEl) {
      optionsEl.innerHTML = q.options.map((opt, i) => `
        <button type="button" class="assess-option-btn" data-index="${i}">${opt}</button>
      `).join('');
      optionsEl.querySelectorAll('.assess-option-btn').forEach(btn => {
        btn.addEventListener('click', () => handleAssessmentAnswer(parseInt(btn.dataset.index)));
      });
    }
  }

  function handleAssessmentAnswer(selectedIdx) {
    const q = ASSESSMENT_QUESTIONS[assessmentState.currentQ];
    const isCorrect = selectedIdx === q.correct;
    assessmentState.answers.push({ questionIdx: assessmentState.currentQ, selected: selectedIdx, correct: isCorrect });

    // Brief visual feedback
    const optionsEl = document.getElementById('assess-options-grid');
    optionsEl?.querySelectorAll('.assess-option-btn').forEach((btn, i) => {
      btn.disabled = true;
      if (i === q.correct) btn.classList.add('correct');
      else if (i === selectedIdx && !isCorrect) btn.classList.add('incorrect');
    });

    setTimeout(() => {
      assessmentState.currentQ++;
      if (assessmentState.currentQ >= ASSESSMENT_QUESTIONS.length) {
        endWeeklyAssessment();
      } else {
        renderAssessmentQuestion();
      }
    }, 600);
  }

  function endWeeklyAssessment() {
    if (assessmentState.timerInterval) clearInterval(assessmentState.timerInterval);
    assessmentState.active = false;

    // Re-enable AI
    const aiBtn = document.getElementById('btn-header-ai');
    if (aiBtn) { aiBtn.style.opacity = ''; aiBtn.style.pointerEvents = ''; aiBtn.title = 'Open AI Assistant'; }

    // Calculate scores
    const correct = assessmentState.answers.filter(a => a.correct).length;
    const overallPct = Math.round((correct / ASSESSMENT_QUESTIONS.length) * 100);

    // Category scores
    const categoryScores = {};
    assessmentState.answers.forEach(a => {
      const q = ASSESSMENT_QUESTIONS[a.questionIdx];
      if (!categoryScores[q.category]) categoryScores[q.category] = { total: 0, correct: 0 };
      categoryScores[q.category].total++;
      if (a.correct) categoryScores[q.category].correct++;
    });

    // Save to storage
    const history = JSON.parse(localStorage.getItem(STORAGE_KEYS.WEEKLY_ASSESSMENT) || '[]');
    const result = { date: new Date().toISOString(), overallPct, categoryScores, timeSeconds: assessmentState.seconds };
    const prevResult = history[history.length - 1];
    history.push(result);
    localStorage.setItem(STORAGE_KEYS.WEEKLY_ASSESSMENT, JSON.stringify(history));

    // Render results
    document.getElementById('assessment-active')?.classList.add('hidden');
    document.getElementById('assessment-results')?.classList.remove('hidden');

    const overallEl = document.getElementById('assess-overall-score');
    if (overallEl) overallEl.textContent = overallPct + '%';

    const improvPill = document.getElementById('assess-improvement-pill');
    if (improvPill && prevResult) {
      const delta = overallPct - prevResult.overallPct;
      improvPill.innerHTML = `<svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><path d="${delta >= 0 ? 'M6 10V2M2 6l4-4 4 4' : 'M6 2v8M2 6l4 4 4-4'}"/></svg>${delta >= 0 ? '+' : ''}${delta.toFixed(1)}% vs last week`;
      improvPill.style.color = delta >= 0 ? '#22C55E' : '#EF4444';
    } else if (improvPill) {
      improvPill.textContent = 'First assessment completed';
    }

    const areaGrid = document.getElementById('assess-area-grid');
    if (areaGrid) {
      areaGrid.innerHTML = Object.entries(categoryScores).map(([cat, scores]) => {
        const pct = Math.round((scores.correct / scores.total) * 100);
        return `<div class="assess-area-card">
          <div class="assess-area-skill">${cat}</div>
          <div class="assess-area-score">${pct}%</div>
          <div class="assess-area-delta">${pct >= 70 ? 'Strong' : pct >= 50 ? 'Developing' : 'Needs Practice'}</div>
        </div>`;
      }).join('');
    }
  }

  // ============================================================
  // MODULE E: PARENT DASHBOARD
  // ============================================================
  function renderParentDashboard() {
    const fp = getLearningFingerprint();
    const user = getCurrentUser();

    if (user) {
      const avatarEl = document.getElementById('parent-avatar');
      const nameEl = document.getElementById('parent-child-name');
      const gradeEl = document.getElementById('parent-child-grade');
      if (avatarEl) avatarEl.textContent = (user.name || 'A').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
      if (nameEl) nameEl.textContent = user.name + ' ' + (user.school ? '' : '');
      if (gradeEl && user.grade) gradeEl.textContent = `${user.grade} · ${user.school || 'School not set'}`;
    }

    // Parent tab wiring
    document.querySelectorAll('[data-parent-tab]').forEach(btn => {
      if (!btn.dataset.wired) {
        btn.dataset.wired = '1';
        btn.addEventListener('click', () => {
          document.querySelectorAll('.parent-tab').forEach(t => t.classList.remove('active'));
          document.querySelectorAll('.parent-panel').forEach(p => p.classList.remove('active'));
          btn.classList.add('active');
          document.getElementById(`parent-panel-${btn.dataset.parentTab}`)?.classList.add('active');
        });
      }
    });

    // WhatsApp share
    const waBtn = document.getElementById('btn-share-whatsapp');
    if (waBtn && !waBtn.dataset.wired) {
      waBtn.dataset.wired = '1';
      waBtn.addEventListener('click', () => {
        const u = getCurrentUser() || { name: 'Aarav' };
        const reportText = `*LearnEase Weekly Report*\nStudent: ${u.name}\nOverall Improvement: +8.4%\nActivities: 24 | Practice Time: 2h 35m\nStrongest: Reading | Focus: Spelling\nWeekly Assessment: Completed\nHome Practice: 10 min/day\n\nLearnEase — Screen Early. Learn Better. Grow Confidently.`;
        window.open(`https://wa.me/?text=${encodeURIComponent(reportText)}`, '_blank');
      });
    }

    // Explain progress
    const explainBtn = document.getElementById('btn-explain-progress');
    if (explainBtn && !explainBtn.dataset.wired) {
      explainBtn.dataset.wired = '1';
      explainBtn.addEventListener('click', () => {
        showToast('AI is converting technical data to plain language...');
        setTimeout(() => {
          const insightsEl = document.getElementById('parent-ai-insights');
          if (insightsEl) {
            insightsEl.innerHTML = `
              <div class="parent-insight-item"><svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="#2563EB" stroke-width="1.8"><polyline points="2 6 5 9 10 3"/></svg><span>Your child is reading better — they can now recognise more words quickly. This means they are spending less energy decoding and more energy understanding what they read.</span></div>
              <div class="parent-insight-item"><svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="#FACC15" stroke-width="1.8"><circle cx="6" cy="6" r="5"/><path d="M6 4v3M6 9h.01"/></svg><span>Spelling is an area where your child is still building skills. This is completely normal and improves with regular short practice — just 10 minutes a day makes a real difference.</span></div>
              <div class="parent-insight-item"><svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="#2563EB" stroke-width="1.8"><polyline points="2 6 5 9 10 3"/></svg><span>Memory is a strong area. Your child remembers things well, which will help with learning new words and following multi-step instructions.</span></div>`;
          }
        }, 800);
      });
    }

    document.getElementById('btn-parent-find-specialist')?.addEventListener('click', () => switchView('specialists'));
    document.getElementById('btn-generate-report')?.addEventListener('click', () => showToast('Report refreshed with latest data.'));
    document.getElementById('btn-save-parent-settings')?.addEventListener('click', () => showToast('Settings saved.'));

    // Render upcoming specialist sessions in Parent Dashboard
    const parentSessionsList = document.getElementById("parent-upcoming-sessions-list");
    if (parentSessionsList) {
      const sessions = getStoredSessions();
      if (!sessions || sessions.length === 0) {
        parentSessionsList.innerHTML = `
          <div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
            No upcoming 1-on-1 specialist sessions scheduled yet. Click &ldquo;Connect with Specialist&rdquo; to book a session.
          </div>
        `;
      } else {
        parentSessionsList.innerHTML = sessions.map(s => {
          const specName = s.teacherName || s.specialistName || "Certified Specialist";
          const dateStr = s.sessionDate || "Scheduled";
          const timeStr = s.sessionTime || s.time || "10:30 AM";
          const childName = s.childName || "Aarav Patel";
          const focus = s.focusAreas || s.focus || "Personalized Intervention";
          const status = s.status || "Confirmed";

          return `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 14px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; margin-bottom: 8px;">
              <div>
                <div style="font-weight: 700; color: #FFFFFF; font-size: 0.95rem;">${specName}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">
                  📅 ${dateStr} at ${timeStr} • <strong>${childName}</strong> (${focus})
                </div>
              </div>
              <div style="display: flex; gap: 8px; align-items: center;">
                <span class="status-pill confirmed" style="font-size: 0.75rem;">${status}</span>
                <button type="button" class="btn btn-primary btn-sm btn-join-room-parent" onclick="switchView('virtual-room')">Join Room</button>
              </div>
            </div>
          `;
        }).join("");
      }
    }

    // Update report date
    const reportDate = document.getElementById('report-date');
    if (reportDate) reportDate.textContent = `Week of ${new Date(Date.now() - 7 * 86400000).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}`;
  }

  // ============================================================
  // MODULE F: ADMIN PANEL
  // ============================================================
  const DEMO_TEACHERS_FOR_ADMIN = [
    { id: 'a1', name: 'Dr. Meera Sharma', qualification: 'M.Ed, Special Education', specialization: 'Learning Difficulties', status: 'approved' },
    { id: 'a2', name: 'Rajesh Nair', qualification: 'B.Ed, Dyslexia Practitioner', specialization: 'Phonological Awareness', status: 'pending' },
    { id: 'a3', name: 'Priyanka Iyer', qualification: 'M.Phil, Child Psychology', specialization: 'Attention & Memory', status: 'pending' },
    { id: 'a4', name: 'Suresh Kumar', qualification: 'B.Sc, Special Educator', specialization: 'Reading Remediation', status: 'rejected' }
  ];

  function renderAdminPanel() {
    renderVerificationTable();
  }

  function renderVerificationTable() {
    const tbody = document.getElementById('verification-table-body');
    if (!tbody) return;
    let teachers = [...DEMO_TEACHERS_FOR_ADMIN];
    try {
      const stored = JSON.parse(localStorage.getItem('learnease_admin_verification') || '[]');
      if (stored.length) teachers = stored;
    } catch {}

    tbody.innerHTML = teachers.map(t => {
      const statusClass = t.status === 'approved' ? 'approved' : t.status === 'rejected' ? 'rejected' : 'pending';
      const statusLabel = t.status === 'approved' ? 'Verified' : t.status === 'rejected' ? 'Rejected' : 'Pending Review';
      return `<tr>
        <td><strong style="color:var(--text-primary)">${t.name}</strong></td>
        <td>${t.qualification}</td>
        <td>${t.specialization}</td>
        <td><span class="verify-status-badge ${statusClass}">${statusLabel}</span></td>
        <td>
          <div class="verify-actions">
            ${t.status !== 'approved' ? `<button type="button" class="btn btn-primary btn-sm admin-approve-btn" data-id="${t.id}" style="font-size:.75rem;padding:.3rem .65rem">Approve</button>` : ''}
            ${t.status !== 'rejected' ? `<button type="button" class="btn btn-ghost btn-sm admin-reject-btn" data-id="${t.id}" style="font-size:.75rem;padding:.3rem .65rem">Reject</button>` : ''}
          </div>
        </td>
      </tr>`;
    }).join('');

    tbody.querySelectorAll('.admin-approve-btn').forEach(btn => {
      btn.addEventListener('click', () => { adminUpdateTeacher(btn.dataset.id, 'approved'); showToast('Teacher approved as Verified Specialist.'); });
    });
    tbody.querySelectorAll('.admin-reject-btn').forEach(btn => {
      btn.addEventListener('click', () => { adminUpdateTeacher(btn.dataset.id, 'rejected'); showToast('Verification rejected.'); });
    });

    // Update stats
    const pending = teachers.filter(t => t.status === 'pending').length;
    document.getElementById('admin-pending-verify').textContent = pending;
  }

  function adminUpdateTeacher(id, status) {
    let teachers = [...DEMO_TEACHERS_FOR_ADMIN];
    try { const s = JSON.parse(localStorage.getItem('learnease_admin_verification')); if (s) teachers = s; } catch {}
    teachers = teachers.map(t => t.id === id ? { ...t, status } : t);
    localStorage.setItem('learnease_admin_verification', JSON.stringify(teachers));
    renderVerificationTable();
  }

  // ============================================================
  // MODULE G: ACCESSIBILITY
  // ============================================================
  const FONT_LEVELS = ['font-sm', 'font-normal', 'font-lg', 'font-xl'];
  const FONT_LABELS = ['Small', 'Normal', 'Large', 'Extra Large'];
  let a11ySettings = { dyslexiaFont: false, fontLevel: 1, lineSpacing: false, highContrast: false, reducedMotion: false, tts: false };

  function initAccessibilityPanel() {
    const saved = localStorage.getItem(STORAGE_KEYS.ACCESSIBILITY);
    if (saved) { try { a11ySettings = JSON.parse(saved); } catch {} }
    applyAccessibilitySettings();

    const toggleBtn = document.getElementById('btn-accessibility-toggle');
    const panel = document.getElementById('a11y-panel');
    const closeBtn = document.getElementById('btn-close-a11y');
    const resetBtn = document.getElementById('btn-a11y-reset');

    toggleBtn?.addEventListener('click', () => panel?.classList.toggle('hidden'));
    closeBtn?.addEventListener('click', () => panel?.classList.add('hidden'));
    resetBtn?.addEventListener('click', () => {
      a11ySettings = { dyslexiaFont: false, fontLevel: 1, lineSpacing: false, highContrast: false, reducedMotion: false, tts: false };
      applyAccessibilitySettings();
      syncA11yUI();
      localStorage.setItem(STORAGE_KEYS.ACCESSIBILITY, JSON.stringify(a11ySettings));
      showToast('Accessibility settings reset to defaults.');
    });

    document.getElementById('a11y-dyslexia-font')?.addEventListener('change', e => {
      a11ySettings.dyslexiaFont = e.target.checked;
      applyAccessibilitySettings(); saveA11y();
    });
    document.getElementById('a11y-line-spacing')?.addEventListener('change', e => {
      a11ySettings.lineSpacing = e.target.checked;
      applyAccessibilitySettings(); saveA11y();
    });
    document.getElementById('a11y-high-contrast')?.addEventListener('change', e => {
      a11ySettings.highContrast = e.target.checked;
      applyAccessibilitySettings(); saveA11y();
    });
    document.getElementById('a11y-reduced-motion')?.addEventListener('change', e => {
      a11ySettings.reducedMotion = e.target.checked;
      applyAccessibilitySettings(); saveA11y();
    });
    document.getElementById('a11y-tts')?.addEventListener('change', e => {
      a11ySettings.tts = e.target.checked; saveA11y();
    });
    document.getElementById('btn-font-increase')?.addEventListener('click', () => {
      if (a11ySettings.fontLevel < FONT_LEVELS.length - 1) { a11ySettings.fontLevel++; applyAccessibilitySettings(); syncA11yUI(); saveA11y(); }
    });
    document.getElementById('btn-font-decrease')?.addEventListener('click', () => {
      if (a11ySettings.fontLevel > 0) { a11ySettings.fontLevel--; applyAccessibilitySettings(); syncA11yUI(); saveA11y(); }
    });

    syncA11yUI();
  }

  function applyAccessibilitySettings() {
    const body = document.body;
    body.classList.toggle('dyslexia-font', a11ySettings.dyslexiaFont);
    body.classList.toggle('line-spacing', a11ySettings.lineSpacing);
    body.classList.toggle('high-contrast', a11ySettings.highContrast);
    body.classList.toggle('reduced-motion', a11ySettings.reducedMotion);
    FONT_LEVELS.forEach(cls => body.classList.remove(cls));
    body.classList.add(FONT_LEVELS[a11ySettings.fontLevel]);
  }

  function syncA11yUI() {
    const df = document.getElementById('a11y-dyslexia-font');
    if (df) df.checked = a11ySettings.dyslexiaFont;
    const ls = document.getElementById('a11y-line-spacing');
    if (ls) ls.checked = a11ySettings.lineSpacing;
    const hc = document.getElementById('a11y-high-contrast');
    if (hc) hc.checked = a11ySettings.highContrast;
    const rm = document.getElementById('a11y-reduced-motion');
    if (rm) rm.checked = a11ySettings.reducedMotion;
    const lbl = document.getElementById('font-size-label');
    if (lbl) lbl.textContent = FONT_LABELS[a11ySettings.fontLevel];
  }

  function saveA11y() { localStorage.setItem(STORAGE_KEYS.ACCESSIBILITY, JSON.stringify(a11ySettings)); }

  // ============================================================
  // MODULE H: DEMO / HACKATHON MODE
  // ============================================================
  const DEMO_STEPS = [
    { action: 'toast', msg: 'Step 1/10: Loading demo student profile — Aarav, Grade 6' },
    { action: 'switchView', view: 'auth' },
    { action: 'toast', msg: 'Step 2/10: Logging in as demo student Aarav...' },
    { action: 'loginDemo' },
    { action: 'switchView', view: 'profile' },
    { action: 'toast', msg: 'Step 3/10: Viewing Learning Fingerprint — Reading 72%, Spelling 54%, Phonology 48%' },
    { action: 'switchView', view: 'daily-plan' },
    { action: 'toast', msg: 'Step 4/10: Starting Daily Learning Plan — Readiness Check' },
    { action: 'simulateReadiness' },
    { action: 'toast', msg: 'Step 5/10: Plan personalised — adaptive reason shown' },
    { action: 'switchView', view: 'weekly-check' },
    { action: 'toast', msg: 'Step 6/10: Weekly Learning Check — AI disabled during assessment' },
    { action: 'switchView', view: 'progress' },
    { action: 'toast', msg: 'Step 7/10: Viewing longitudinal progress and AI insights' },
    { action: 'switchView', view: 'parent' },
    { action: 'toast', msg: 'Step 8/10: Parent Dashboard — weekly report with WhatsApp share' },
    { action: 'switchView', view: 'teacher' },
    { action: 'toast', msg: 'Step 9/10: Teacher Portal — Dr. Meera Sharma, Verified Specialist' },
    { action: 'switchView', view: 'admin' },
    { action: 'toast', msg: 'Step 10/10: Admin Panel — teacher verification queue. Demo complete!' }
  ];

  let demoStepIndex = 0;
  let demoRunning = false;

  function initDemoMode() {
    const pill = document.getElementById('demo-mode-pill');
    const runBtn = document.getElementById('btn-run-demo');
    if (pill) pill.style.display = 'flex';
    runBtn?.addEventListener('click', () => {
      if (demoRunning) return;
      demoStepIndex = 0;
      demoRunning = true;
      runBtn.textContent = 'Running...';
      runBtn.disabled = true;
      executeDemoStep();
    });
  }

  function executeDemoStep() {
    if (demoStepIndex >= DEMO_STEPS.length) {
      demoRunning = false;
      const btn = document.getElementById('btn-run-demo');
      if (btn) { btn.textContent = 'Load Demo Scenario'; btn.disabled = false; }
      showToast('Demo complete! All 10 steps demonstrated.');
      return;
    }
    const step = DEMO_STEPS[demoStepIndex++];
    if (step.action === 'toast') showToast(step.msg);
    else if (step.action === 'switchView') switchView(step.view);
    else if (step.action === 'loginDemo') {
      loginUser('aarav@example.com', 'demo123');
    } else if (step.action === 'simulateReadiness') {
      sessionStorage.setItem('learnease_readiness_today', 'ready');
    }
    setTimeout(executeDemoStep, 2200);
  }

  // ============================================================
  // MODULE I: JOURNEY TAB (Progress view upgrade)
  // ============================================================
  function initJourneyTab() {
    const progressView = document.getElementById('view-progress');
    if (!progressView) return;

    // Add tabs above existing content
    const existingHeader = progressView.querySelector('.progress-header-row');
    if (existingHeader && !progressView.querySelector('.progress-view-tabs')) {
      const tabsHtml = `<div class="progress-view-tabs">
        <button type="button" class="progress-view-tab active" data-ptab="dashboard">Progress Dashboard</button>
        <button type="button" class="progress-view-tab" data-ptab="journey">My Learning Journey</button>
      </div>
      <div class="journey-section" id="journey-section">
        <div class="journey-header-stats">
          <div class="journey-stat-card"><div class="journey-stat-val" id="js-streak">7</div><div class="journey-stat-lbl">Day Streak</div></div>
          <div class="journey-stat-card"><div class="journey-stat-val" id="js-activities">24</div><div class="journey-stat-lbl">Activities Done</div></div>
          <div class="journey-stat-card"><div class="journey-stat-val text-blue" id="js-improvement">+14%</div><div class="journey-stat-lbl">4-Week Growth</div></div>
        </div>
        <div class="journey-week-chart">
          <div class="week-chart-title">Weekly Performance — Last 4 Weeks</div>
          <div class="week-bars-row">
            <div class="week-bar-col"><div class="week-bar-val">51%</div><div class="week-bar-fill" style="height:51px"></div><div class="week-bar-label">Wk 1</div></div>
            <div class="week-bar-col"><div class="week-bar-val">59%</div><div class="week-bar-fill" style="height:59px"></div><div class="week-bar-label">Wk 2</div></div>
            <div class="week-bar-col"><div class="week-bar-val">67%</div><div class="week-bar-fill" style="height:67px"></div><div class="week-bar-label">Wk 3</div></div>
            <div class="week-bar-col"><div class="week-bar-val" style="color:#22C55E">75%</div><div class="week-bar-fill" style="height:75px;background:#22C55E"></div><div class="week-bar-label">Wk 4</div></div>
          </div>
        </div>
        <div class="journey-ai-insights">
          <div class="journey-insights-title">
            <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="#2563EB" stroke-width="1.8"><path d="M8 1l2 3.5L14 5.5l-3 3 .7 4.5L8 11l-3.7 2 .7-4.5-3-3 4-.5L8 1z"/></svg>
            AI Learning Insights
          </div>
          <div id="journey-ai-insights-list"></div>
        </div>
      </div>`;
      existingHeader.insertAdjacentHTML('beforebegin', tabsHtml);

      // Wrap existing dashboard content in dashboard section
      const container = progressView.querySelector('.container');
      if (container) {
        const tabsEl = container.querySelector('.progress-view-tabs');
        if (tabsEl) {
          // Wire tab switching
          container.querySelectorAll('[data-ptab]').forEach(btn => {
            btn.addEventListener('click', () => {
              container.querySelectorAll('[data-ptab]').forEach(b => b.classList.remove('active'));
              btn.classList.add('active');
              const dashSections = container.querySelectorAll('.progress-header-row, .stat-metric-grid, .dashboard-charts-row, .history-section, .next-steps-section, .empty-state-section, .child-profile-section');
              const journeySection = container.querySelector('#journey-section');
              const showJourney = btn.dataset.ptab === 'journey';
              dashSections.forEach(s => { if (s) s.style.display = showJourney ? 'none' : ''; });
              if (journeySection) journeySection.classList.toggle('active', showJourney);
            });
          });
        }
      }

      // Populate journey AI insights
      const fp = getLearningFingerprint();
      const insightsList = document.getElementById('journey-ai-insights-list');
      if (insightsList) {
        insightsList.innerHTML = generateAIInsights(fp).concat([
          'Your learning streak of 7 days is building great habits.',
          'Tomorrow\'s plan has been adjusted to include additional spelling practice based on this week\'s results.'
        ]).map(i => `<div class="parent-insight-item"><svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="#2563EB" stroke-width="1.8"><polyline points="2 6 5 9 10 3"/></svg><span>${i}</span></div>`).join('');
      }
    }
  }

  // ============================================================
  // MODULE J: USER AUTH BUTTON WIRING
  // ============================================================
  function initUserAuthButton() {
    const btn = document.getElementById('btn-user-auth');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const user = getCurrentUser();
      if (user && btn.dataset.mode === 'profile') {
        switchView('profile');
      } else {
        switchView('auth');
        if (typeof renderAuthView === 'function') renderAuthView();
      }
    });
    // Init state on load
    const user = getCurrentUser();
    if (user) updateNavForUser(user);
  }

  // ============================================================
  // UPGRADE: AI COMPANION — Assessment Awareness
  // ============================================================
  // Patch generateContextualAIResponse to know about assessment mode
  const _origGenAI = typeof generateContextualAIResponse === 'function' ? generateContextualAIResponse : null;
  window._learnEaseAIOverride = function(query, ctx) {
    if (assessmentState && assessmentState.active) {
      return 'Assessment Mode is active. AI assistance is paused so you can demonstrate your independent progress. Keep going — you are doing great!';
    }
    const q = query.toLowerCase();
    const user = getCurrentUser();
    const homeLang = user?.homeLang;
    if (q.includes('tired') || q.includes('break')) return 'Let\'s take a short 2-minute break, then we will continue with an easier activity. Rest is an important part of learning.';
    if (q.includes('don\'t understand') || q.includes('help') && q.includes('word')) return 'That\'s okay! Let\'s break the word into smaller sounds together. Say it slowly and listen for each individual sound.';
    if (homeLang && homeLang !== 'en' && (q.includes('difficult') || q.includes('hard'))) {
      return `Some difficulty with English words may also be related to the difference between your home language and school language — this is a language context challenge, not necessarily a learning difficulty. Keep practising!`;
    }
    if (q.includes('spelling')) return `Spelling in English can be challenging. Try breaking the word into sounds: say it slowly, then write what you hear. Short daily practice (10 minutes) makes a big difference.`;
    if (q.includes('daily plan') || q.includes('today')) return `Your daily plan has 4 activities personalised for your current skill profile. Start with the first one and work through at your own pace.`;
    if (q.includes('weekly check') || q.includes('assessment')) return `Your Weekly Learning Check covers Reading, Spelling, Word Recognition, Phonological Awareness, and Memory. It helps us understand how you are progressing independently.`;
    return null; // Fall through to original
  };

  // ============================================================
  // INITIALIZATION — Run on DOMContentLoaded
  // ============================================================
  document.addEventListener('DOMContentLoaded', function() {
    initUserAuthButton();
    initAccessibilityPanel();
    initDemoMode();
    // Init journey tab when progress view is rendered
    const origSwitch = window.switchView || function(){};
    // Patch: after progress renders, add journey tab
    setTimeout(() => {
      if (document.getElementById('view-progress')?.classList.contains('active')) {
        initJourneyTab();
      }
    }, 500);
  });

  // ============================================================
  // MODULE K: ALL ACTIVITIES TOOLBAR (SEARCH & FILTERS)
  // ============================================================
  function initActivitiesToolbar() {
    const searchInput = document.getElementById('all-activities-search');
    const clearBtn = document.getElementById('btn-clear-activities-search');
    const filterBtns = document.querySelectorAll('.act-filter-btn');
    const cards = document.querySelectorAll('.game-library-card');

    let currentFilter = 'all';
    let searchQuery = '';

    function filterCards() {
      cards.forEach(card => {
        const cat = (card.dataset.category || '').toLowerCase();
        const diff = (card.dataset.difficulty || '').toLowerCase();
        const isRec = card.dataset.recommended === 'true';
        const skill = (card.dataset.skill || '').toLowerCase();
        const title = (card.querySelector('.game-title')?.textContent || '').toLowerCase();
        const desc = (card.querySelector('.game-desc')?.textContent || '').toLowerCase();

        // Check filter pill
        let matchFilter = true;
        if (currentFilter === 'recommended') matchFilter = isRec;
        else if (currentFilter === 'beginner') matchFilter = diff === 'beginner' || diff === 'easy';
        else if (currentFilter === 'intermediate') matchFilter = diff === 'intermediate' || diff === 'medium';
        else if (currentFilter === 'advanced') matchFilter = diff === 'advanced' || diff === 'hard';
        else if (currentFilter === 'completed') matchFilter = true; // demo: all shown as active
        
        // Check search query
        let matchSearch = true;
        if (searchQuery) {
          matchSearch = title.includes(searchQuery) || desc.includes(searchQuery) || skill.includes(searchQuery) || cat.includes(searchQuery);
        }

        if (matchFilter && matchSearch) {
          card.style.display = '';
        } else {
          card.style.display = 'none';
        }
      });
    }

    if (searchInput && !searchInput.dataset.wired) {
      searchInput.dataset.wired = '1';
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.trim().toLowerCase();
        if (clearBtn) clearBtn.classList.toggle('hidden', !searchQuery);
        filterCards();
      });
    }

    if (clearBtn && !clearBtn.dataset.wired) {
      clearBtn.dataset.wired = '1';
      clearBtn.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        searchQuery = '';
        clearBtn.classList.add('hidden');
        filterCards();
      });
    }

    filterBtns.forEach(btn => {
      if (!btn.dataset.wired) {
        btn.dataset.wired = '1';
        btn.addEventListener('click', () => {
          filterBtns.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          currentFilter = btn.dataset.actFilter;
          filterCards();
        });
      }
    });

    // Wire any new play buttons
    document.querySelectorAll('.btn-play-game').forEach(btn => {
      if (!btn.dataset.wired) {
        btn.dataset.wired = '1';
        btn.addEventListener('click', () => {
          launchGame(btn.dataset.game);
        });
      }
    });
  }

  // ============================================================
  // MODULE L: ROLE-BASED PORTAL VIEW
  // ============================================================
  function renderPortalView() {
    const roleTabs = document.querySelectorAll('[data-portal-role]');
    roleTabs.forEach(tab => {
      if (!tab.dataset.wired) {
        tab.dataset.wired = '1';
        tab.addEventListener('click', () => {
          const role = tab.dataset.portalRole;
          roleTabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
          document.querySelectorAll('.portal-role-panel').forEach(p => p.classList.remove('active'));
          document.getElementById(`portal-panel-${role}`)?.classList.add('active');
        });
      }
    });
  }

  // Expose switchView to window for external/inline navigators
  window.switchView = switchView;

})();
